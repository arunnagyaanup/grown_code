<?php 
/* Template Name: User-profile-Custom */ 

$user_info = get_user_meta(get_current_user_id());
$user_info1 = get_userdata(get_current_user_id());
$header_image =  get_user_meta(get_current_user_id(),'header_image',true);
$profile_pic =  get_user_meta(get_current_user_id(),'profile_pic',true);
$profile_pic_img = wp_get_attachment_image_src( $profile_pic, '' );
$image = wp_get_attachment_image_src( $header_image, '' );

$user = wp_get_current_user();
?>
<!DOCTYPE html>

<html lang="en">




<head>

  <!-- Required Meta Tags Always Come First -->

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



  <!-- Title -->

  <title>Account Settings | Grown</title>



  <!-- Favicon -->

  <link rel="shortcut icon" type="image/jpg" href="http://grown.technoart.org/wp-content/uploads/2022/02/Fav-icon-black-no-bg.png"/>



  <!-- Font -->

  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&amp;display=swap" rel="stylesheet">



  <!-- CSS Implementing Plugins -->

  <link rel="stylesheet" href="http://grown.technoart.org/dashboard/assets/css/vendor.min.css">



  <!-- CSS grown Template -->

  <link rel="stylesheet" href="http://grown.technoart.org/dashboard/assets/css/theme.minc619.css?v=1.0">



  <link rel="preload" href="http://grown.technoart.org/dashboard/assets/css/theme.min.css" data-hs-appearance="default" as="style">

  <link rel="preload" href="http://grown.technoart.org/dashboard/assets/css/theme-dark.min.css" data-hs-appearance="dark" as="style">
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">


  <style data-hs-appearance-onload-styles>

    *

    {

      transition: unset !important;

    }



    body

    {

      opacity: 0;

    }
	
	.error {
    color: red !important;
}


  </style>



  <!-- ONLY DEV -->



  <style>

    body

    {

      opacity: 0;

    }
.error {
    color: red !important;
}


  </style>



  <!-- END ONLY DEV -->



  <script>

            window.hs_config = {"autopath":"@@autopath","deleteLine":"hs-builder:delete","deleteLine:build":"hs-builder:build-delete","deleteLine:dist":"hs-builder:dist-delete","previewMode":false,"startPath":"/index.html","vars":{"themeFont":"https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap","version":"?v=1.0"},"layoutBuilder":{"extend":{"switcherSupport":true},"header":{"layoutMode":"default","containerMode":"container-fluid"},"sidebarLayout":"default"},"themeAppearance":{"layoutSkin":"default","sidebarSkin":"default","styles":{"colors":{"primary":"#377dff","transparent":"transparent","white":"#fff","dark":"132144","gray":{"100":"#f9fafc","900":"#1e2022"}},"font":"Inter"}},"languageDirection":{"lang":"en"},"skipFilesFromBundle":{"dist":["assets/js/hs.theme-appearance.js","assets/js/hs.theme-appearance-charts.js","assets/js/demo.js"],"build":["assets/css/theme.css","assets/vendor/hs-navbar-vertical-aside/dist/hs-navbar-vertical-aside-mini-cache.js","assets/js/demo.js","assets/css/theme-dark.html","assets/css/docs.css","assets/vendor/icon-set/style.html","assets/js/hs.theme-appearance.js","assets/js/hs.theme-appearance-charts.js","node_modules/chartjs-plugin-datalabels/dist/chartjs-plugin-datalabels.min.html","assets/js/demo.js"]},"minifyCSSFiles":["assets/css/theme.css","assets/css/theme-dark.css"],"copyDependencies":{"dist":{"*assets/js/theme-custom.js":""},"build":{"*assets/js/theme-custom.js":"","node_modules/bootstrap-icons/font/*fonts/**":"assets/css"}},"buildFolder":"","replacePathsToCDN":{},"directoryNames":{"src":"./src","dist":"./dist","build":"./build"},"fileNames":{"dist":{"js":"theme.min.js","css":"theme.min.css"},"build":{"css":"theme.min.css","js":"theme.min.js","vendorCSS":"vendor.min.css","vendorJS":"vendor.min.js"}},"fileTypes":"jpg|png|svg|mp4|webm|ogv|json"}

            window.hs_config.gulpRGBA = (p1) => {

  const options = p1.split(',')

  const hex = options[0].toString()

  const transparent = options[1].toString()



  var c;

  if(/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)){

    c= hex.substring(1).split('');

    if(c.length== 3){

      c= [c[0], c[0], c[1], c[1], c[2], c[2]];

    }

    c= '0x'+c.join('');

    return 'rgba('+[(c>>16)&255, (c>>8)&255, c&255].join(',')+',' + transparent + ')';

  }

  throw new Error('Bad Hex');

}

            window.hs_config.gulpDarken = (p1) => {

  const options = p1.split(',')



  let col = options[0].toString()

  let amt = -parseInt(options[1])

  var usePound = false



  if (col[0] == "#") {

    col = col.slice(1)

    usePound = true

  }

  var num = parseInt(col, 16)

  var r = (num >> 16) + amt

  if (r > 255) {

    r = 255

  } else if (r < 0) {

    r = 0

  }

  var b = ((num >> 8) & 0x00FF) + amt

  if (b > 255) {

    b = 255

  } else if (b < 0) {

    b = 0

  }

  var g = (num & 0x0000FF) + amt

  if (g > 255) {

    g = 255

  } else if (g < 0) {

    g = 0

  }

  return (usePound ? "#" : "") + (g | (b << 8) | (r << 16)).toString(16)

}

            window.hs_config.gulpLighten = (p1) => {

  const options = p1.split(',')



  let col = options[0].toString()

  let amt = parseInt(options[1])

  var usePound = false



  if (col[0] == "#") {

    col = col.slice(1)

    usePound = true

  }

  var num = parseInt(col, 16)

  var r = (num >> 16) + amt

  if (r > 255) {

    r = 255

  } else if (r < 0) {

    r = 0

  }

  var b = ((num >> 8) & 0x00FF) + amt

  if (b > 255) {

    b = 255

  } else if (b < 0) {

    b = 0

  }

  var g = (num & 0x0000FF) + amt

  if (g > 255) {

    g = 255

  } else if (g < 0) {

    g = 0

  }

  return (usePound ? "#" : "") + (g | (b << 8) | (r << 16)).toString(16)

}

            </script>

</head>



<body class="has-navbar-vertical-aside navbar-vertical-aside-show-xl   footer-offset">



  <script src="http://grown.technoart.org/dashboard/assets/js/hs.theme-appearance.js"></script>



  <script src="http://grown.technoart.org/dashboard/assets/vendor/hs-navbar-vertical-aside/dist/hs-navbar-vertical-aside-mini-cache.js"></script>



  <!-- ========== HEADER ========== -->



  <header id="header" class="navbar navbar-expand-lg navbar-fixed navbar-height navbar-container navbar-bordered bg-white">

    <div class="navbar-nav-wrap">

      <!-- Logo -->

      <a class="navbar-brand" href="index.html" aria-label="grown">

        <img class="navbar-brand-logo" src="http://grown.technoart.org/dashboard/assets/svg/logos/logo.svg" alt="Logo" data-hs-theme-appearance="default">

        <img class="navbar-brand-logo" src="http://grown.technoart.org/dashboard/assets/svg/logos-light/logo.svg" alt="Logo" data-hs-theme-appearance="dark">

        <img class="navbar-brand-logo-mini" src="http://grown.technoart.org/dashboard/assets/svg/logos/logo-short.svg" alt="Logo" data-hs-theme-appearance="default">

        <img class="navbar-brand-logo-mini" src="http://grown.technoart.org/dashboard/assets/svg/logos-light/logo-short.svg" alt="Logo" data-hs-theme-appearance="dark">

      </a>

      <!-- End Logo -->



      <div class="navbar-nav-wrap-content-start">

        <!-- Navbar Vertical Toggle -->

        <button type="button" class="js-navbar-vertical-aside-toggle-invoker navbar-aside-toggler">

          <i class="bi-arrow-bar-left navbar-toggler-short-align" data-bs-template='<div class="tooltip d-none d-md-block" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>' data-bs-toggle="tooltip" data-bs-placement="right" title="Collapse"></i>

          <i class="bi-arrow-bar-right navbar-toggler-full-align" data-bs-template='<div class="tooltip d-none d-md-block" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>' data-bs-toggle="tooltip" data-bs-placement="right" title="Expand"></i>

        </button>



        <!-- End Navbar Vertical Toggle -->



        <!-- Search Form -->

        <div class="dropdown ms-2">

          <!-- Input Group -->

          <div class="d-none d-lg-block">

            <div class="input-group input-group-merge input-group-borderless input-group-hover-light navbar-input-group">

              <div class="input-group-prepend input-group-text">

                <i class="bi-search"></i>

              </div>



              <input type="search" class="js-form-search form-control" placeholder="Search in Grown" aria-label="Search in grown" data-hs-form-search-options='{

                       "clearIcon": "#clearSearchResultsIcon",

                       "dropMenuElement": "#searchDropdownMenu",

                       "dropMenuOffset": 20,

                       "toggleIconOnFocus": true,

                       "activeClass": "focus"

                     }'>

              <a class="input-group-append input-group-text" href="javascript:;">

                <i id="clearSearchResultsIcon" class="bi-x-lg" style="display: none;"></i>

              </a>

            </div>

          </div>



          <button class="js-form-search js-form-search-mobile-toggle btn btn-ghost-secondary btn-icon rounded-circle d-lg-none" type="button" data-hs-form-search-options='{

                       "clearIcon": "#clearSearchResultsIcon",

                       "dropMenuElement": "#searchDropdownMenu",

                       "dropMenuOffset": 20,

                       "toggleIconOnFocus": true,

                       "activeClass": "focus"

                     }'>

            <i class="bi-search"></i>

          </button>

          <!-- End Input Group -->



          <!-- Card Search Content -->

          <div id="searchDropdownMenu" class="hs-form-search-menu-content dropdown-menu dropdown-menu-form-search navbar-dropdown-menu-borderless">

            <!-- Body -->

            <div class="card-body-height">

              <div class="d-lg-none">

                <div class="input-group input-group-merge navbar-input-group mb-5">

                  <div class="input-group-prepend input-group-text">

                    <i class="bi-search"></i>

                  </div>



                  <input type="search" class="form-control" placeholder="Search in Grown" aria-label="Search in grown">

                  <a class="input-group-append input-group-text" href="javascript:;">

                    <i class="bi-x-lg"></i>

                  </a>

                </div>

              </div>



              <span class="dropdown-header">Recent searches</span>



              <div class="dropdown-item bg-transparent text-wrap">

                <a class="btn btn-soft-dark btn-xs rounded-pill" href="index.html">

                  Gulp <i class="bi-search ms-1"></i>

                </a>

                <a class="btn btn-soft-dark btn-xs rounded-pill" href="index.html">

                  Notification panel <i class="bi-search ms-1"></i>

                </a>

              </div>



              <div class="dropdown-divider"></div>



              <span class="dropdown-header">Tutorials</span>



              <a class="dropdown-item" href="index.html">

                <div class="d-flex align-items-center">

                  <div class="flex-shrink-0">

                    <span class="icon icon-soft-dark icon-xs icon-circle">

                      <i class="bi-sliders"></i>

                    </span>

                  </div>



                  <div class="flex-grow-1 text-truncate ms-2">

                    <span>How to set up Gulp?</span>

                  </div>

                </div>

              </a>



              <a class="dropdown-item" href="index.html">

                <div class="d-flex align-items-center">

                  <div class="flex-shrink-0">

                    <span class="icon icon-soft-dark icon-xs icon-circle">

                      <i class="bi-paint-bucket"></i>

                    </span>

                  </div>



                  <div class="flex-grow-1 text-truncate ms-2">

                    <span>How to change theme color?</span>

                  </div>

                </div>

              </a>



              <div class="dropdown-divider"></div>



              <span class="dropdown-header">Members</span>



              <a class="dropdown-item" href="index.html">

                <div class="d-flex align-items-center">

                  <div class="flex-shrink-0">

                    <img class="avatar avatar-xs avatar-circle" src="http://grown.technoart.org/dashboard/assets/img/160x160/img10.jpg" alt="Image Description">

                  </div>

                  <div class="flex-grow-1 text-truncate ms-2">

                    <span>Amanda Harvey <i class="tio-verified text-primary" data-toggle="tooltip" data-placement="top" title="Top endorsed"></i></span>

                  </div>

                </div>

              </a>



              <a class="dropdown-item" href="index.html">

                <div class="d-flex align-items-center">

                  <div class="flex-shrink-0">

                    <img class="avatar avatar-xs avatar-circle" src="http://grown.technoart.org/dashboard/assets/img/160x160/img3.jpg" alt="Image Description">

                  </div>

                  <div class="flex-grow-1 text-truncate ms-2">

                    <span>David Harrison</span>

                  </div>

                </div>

              </a>



              <a class="dropdown-item" href="index.html">

                <div class="d-flex align-items-center">

                  <div class="flex-shrink-0">

                    <div class="avatar avatar-xs avatar-soft-info avatar-circle">

                      <span class="avatar-initials">A</span>

                    </div>

                  </div>

                  <div class="flex-grow-1 text-truncate ms-2">

                    <span>Anne Richard</span>

                  </div>

                </div>

              </a>

            </div>

            <!-- End Body -->



            <!-- Footer -->

            <a class="card-footer text-center" href="index.html">

              See all results <i class="bi-chevron-right small"></i>

            </a>

            <!-- End Footer -->

          </div>

          <!-- End Card Search Content -->



        </div>



        <!-- End Search Form -->

      </div>



      <div class="navbar-nav-wrap-content-end">

        <!-- Navbar -->

        <ul class="navbar-nav">

          <li class="nav-item d-none d-sm-inline-block">

            <!-- Notification -->

            <div class="dropdown">

              <button type="button" class="btn btn-ghost-secondary btn-icon rounded-circle" id="navbarNotificationsDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside" data-bs-dropdown-animation>

                <i class="bi-bell"></i>

                <span class="btn-status btn-sm-status btn-status-danger"></span>

              </button>



              <div class="dropdown-menu dropdown-menu-end dropdown-card navbar-dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="navbarNotificationsDropdown" style="width: 25rem;">

                <!-- Header -->

                <div class="card-header card-header-content-between">

                  <h4 class="card-title mb-0">Notifications</h4>



                  <!-- Unfold -->

                  <div class="dropdown">

                    <button type="button" class="btn btn-icon btn-sm btn-ghost-secondary rounded-circle" id="navbarNotificationsDropdownSettings" data-bs-toggle="dropdown" aria-expanded="false">

                      <i class="bi-three-dots-vertical"></i>

                    </button>



                    <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="navbarNotificationsDropdownSettings">

                      <span class="dropdown-header">Settings</span>

                      <a class="dropdown-item" href="#">

                        <i class="bi-archive dropdown-item-icon"></i> Archive all

                      </a>

                      <a class="dropdown-item" href="#">

                        <i class="bi-check2-all dropdown-item-icon"></i> Mark all as read

                      </a>

                      <a class="dropdown-item" href="#">

                        <i class="bi-toggle-off dropdown-item-icon"></i> Disable notifications

                      </a>

                      <a class="dropdown-item" href="#">

                        <i class="bi-gift dropdown-item-icon"></i> What's new?

                      </a>

                      <div class="dropdown-divider"></div>

                      <span class="dropdown-header">Feedback</span>

                      <a class="dropdown-item" href="#">

                        <i class="bi-chat-left-dots dropdown-item-icon"></i> Report

                      </a>

                    </div>

                  </div>

                  <!-- End Unfold -->

                </div>

                <!-- End Header -->



                <!-- Nav -->

                <ul class="nav nav-tabs nav-justified" id="notificationTab" role="tablist">

                  <li class="nav-item">

                    <a class="nav-link active" href="#notificationNavOne" id="notificationNavOne-tab" data-bs-toggle="tab" data-bs-target="#notificationNavOne" role="tab" aria-controls="notificationNavOne" aria-selected="true">Messages (3)</a>

                  </li>

                  <li class="nav-item">

                    <a class="nav-link" href="#notificationNavTwo" id="notificationNavTwo-tab" data-bs-toggle="tab" data-bs-target="#notificationNavTwo" role="tab" aria-controls="notificationNavTwo" aria-selected="false">Archived</a>

                  </li>

                </ul>

                <!-- End Nav -->



                <!-- Body -->

                <div class="card-body-height">

                  <!-- Tab Content -->

                  <div class="tab-content" id="notificationTabContent">

                    <div class="tab-pane fade show active" id="notificationNavOne" role="tabpanel" aria-labelledby="notificationNavOne-tab">

                      <!-- List Group -->

                      <ul class="list-group list-group-flush navbar-card-list-group">

                        <!-- Item -->

                        <li class="list-group-item form-check-select">

                          <div class="row">

                            <div class="col-auto">

                              <div class="d-flex align-items-center">

                                <div class="form-check">

                                  <input class="form-check-input" type="checkbox" value="" id="notificationCheck1" checked>

                                  <label class="form-check-label" for="notificationCheck1"></label>

                                  <span class="form-check-stretched-bg"></span>

                                </div>

                                <img class="avatar avatar-sm avatar-circle" src="http://grown.technoart.org/dashboard/assets/img/160x160/img3.jpg" alt="Image Description">

                              </div>

                            </div>

                            <!-- End Col -->



                            <div class="col ms-n2">

                              <h5 class="mb-1">Brian Warner</h5>

                              <p class="text-body fs-5">changed an issue from "In Progress" to <span class="badge bg-success">Review</span></p>

                            </div>

                            <!-- End Col -->



                            <small class="col-auto text-muted text-cap">2hr</small>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->



                          <a class="stretched-link" href="#"></a>

                        </li>

                        <!-- End Item -->



                        <!-- Item -->

                        <li class="list-group-item form-check-select">

                          <div class="row">

                            <div class="col-auto">

                              <div class="d-flex align-items-center">

                                <div class="form-check">

                                  <input class="form-check-input" type="checkbox" value="" id="notificationCheck2" checked>

                                  <label class="form-check-label" for="notificationCheck2"></label>

                                  <span class="form-check-stretched-bg"></span>

                                </div>

                                <div class="avatar avatar-sm avatar-soft-dark avatar-circle">

                                  <span class="avatar-initials">K</span>

                                </div>

                              </div>

                            </div>

                            <!-- End Col -->



                            <div class="col ms-n2">

                              <h5 class="mb-1">Klara Hampton</h5>

                              <p class="text-body fs-5">mentioned you in a comment</p>

                              <blockquote class="blockquote blockquote-sm">

                                Nice work, love! You really nailed it. Keep it up!

                              </blockquote>

                            </div>

                            <!-- End Col -->



                            <small class="col-auto text-muted text-cap">10hr</small>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->



                          <a class="stretched-link" href="#"></a>

                        </li>

                        <!-- End Item -->



                        <!-- Item -->

                        <li class="list-group-item form-check-select">

                          <div class="row">

                            <div class="col-auto">

                              <div class="d-flex align-items-center">

                                <div class="form-check">

                                  <input class="form-check-input" type="checkbox" value="" id="notificationCheck3" checked>

                                  <label class="form-check-label" for="notificationCheck3"></label>

                                  <span class="form-check-stretched-bg"></span>

                                </div>

                                <div class="avatar avatar-sm avatar-circle">

                                  <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img10.jpg" alt="Image Description">

                                </div>

                              </div>

                            </div>

                            <!-- End Col -->



                            <div class="col ms-n2">

                              <h5 class="mb-1">Ruby Walter</h5>

                              <p class="text-body fs-5">joined the Slack group HS Team</p>

                            </div>

                            <!-- End Col -->



                            <small class="col-auto text-muted text-cap">3dy</small>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->



                          <a class="stretched-link" href="#"></a>

                        </li>

                        <!-- End Item -->



                        <!-- Item -->

                        <li class="list-group-item form-check-select">

                          <div class="row">

                            <div class="col-auto">

                              <div class="d-flex align-items-center">

                                <div class="form-check">

                                  <input class="form-check-input" type="checkbox" value="" id="notificationCheck4">

                                  <label class="form-check-label" for="notificationCheck4"></label>

                                  <span class="form-check-stretched-bg"></span>

                                </div>

                                <div class="avatar avatar-sm avatar-circle">

                                  <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/svg/brands/google-icon.svg" alt="Image Description">

                                </div>

                              </div>

                            </div>

                            <!-- End Col -->



                            <div class="col ms-n2">

                              <h5 class="mb-1">from Google</h5>

                              <p class="text-body fs-5">Start using forms to capture the information of prospects visiting your Google website</p>

                            </div>

                            <!-- End Col -->



                            <small class="col-auto text-muted text-cap">17dy</small>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->



                          <a class="stretched-link" href="#"></a>

                        </li>

                        <!-- End Item -->



                        <!-- Item -->

                        <li class="list-group-item form-check-select">

                          <div class="row">

                            <div class="col-auto">

                              <div class="d-flex align-items-center">

                                <div class="form-check">

                                  <input class="form-check-input" type="checkbox" value="" id="notificationCheck5">

                                  <label class="form-check-label" for="notificationCheck5"></label>

                                  <span class="form-check-stretched-bg"></span>

                                </div>

                                <div class="avatar avatar-sm avatar-circle">

                                  <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img7.jpg" alt="Image Description">

                                </div>

                              </div>

                            </div>

                            <!-- End Col -->



                            <div class="col ms-n2">

                              <h5 class="mb-1">Sara Villar</h5>

                              <p class="text-body fs-5">completed <i class="bi-journal-bookmark-fill text-primary"></i> FD-7 task</p>

                            </div>

                            <!-- End Col -->



                            <small class="col-auto text-muted text-cap">2mn</small>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->



                          <a class="stretched-link" href="#"></a>

                        </li>

                        <!-- End Item -->

                      </ul>

                      <!-- End List Group -->

                    </div>



                    <div class="tab-pane fade" id="notificationNavTwo" role="tabpanel" aria-labelledby="notificationNavTwo-tab">

                      <!-- List Group -->

                      <ul class="list-group list-group-flush navbar-card-list-group">

                        <!-- Item -->

                        <li class="list-group-item form-check-select">

                          <div class="row">

                            <div class="col-auto">

                              <div class="d-flex align-items-center">

                                <div class="form-check">

                                  <input class="form-check-input" type="checkbox" value="" id="notificationCheck6">

                                  <label class="form-check-label" for="notificationCheck6"></label>

                                  <span class="form-check-stretched-bg"></span>

                                </div>

                                <div class="avatar avatar-sm avatar-soft-dark avatar-circle">

                                  <span class="avatar-initials">A</span>

                                </div>

                              </div>

                            </div>

                            <!-- End Col -->



                            <div class="col ms-n2">

                              <h5 class="mb-1">Anne Richard</h5>

                              <p class="text-body fs-5">accepted your invitation to join Notion</p>

                            </div>

                            <!-- End Col -->



                            <small class="col-auto text-muted text-cap">1dy</small>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->



                          <a class="stretched-link" href="#"></a>

                        </li>

                        <!-- End Item -->



                        <!-- Item -->

                        <li class="list-group-item form-check-select">

                          <div class="row">

                            <div class="col-auto">

                              <div class="d-flex align-items-center">

                                <div class="form-check">

                                  <input class="form-check-input" type="checkbox" value="" id="notificationCheck7">

                                  <label class="form-check-label" for="notificationCheck7"></label>

                                  <span class="form-check-stretched-bg"></span>

                                </div>

                                <div class="avatar avatar-sm avatar-circle">

                                  <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img5.jpg" alt="Image Description">

                                </div>

                              </div>

                            </div>

                            <!-- End Col -->



                            <div class="col ms-n2">

                              <h5 class="mb-1">Finch Hoot</h5>

                              <p class="text-body fs-5">left Slack group HS projects</p>

                            </div>

                            <!-- End Col -->



                            <small class="col-auto text-muted text-cap">1dy</small>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->



                          <a class="stretched-link" href="#"></a>

                        </li>

                        <!-- End Item -->



                        <!-- Item -->

                        <li class="list-group-item form-check-select">

                          <div class="row">

                            <div class="col-auto">

                              <div class="d-flex align-items-center">

                                <div class="form-check">

                                  <input class="form-check-input" type="checkbox" value="" id="notificationCheck8">

                                  <label class="form-check-label" for="notificationCheck8"></label>

                                  <span class="form-check-stretched-bg"></span>

                                </div>

                                <div class="avatar avatar-sm avatar-dark avatar-circle">

                                  <span class="avatar-initials">HS</span>

                                </div>

                              </div>

                            </div>

                            <!-- End Col -->



                            <div class="col ms-n2">

                              <h5 class="mb-1">Htmlstream</h5>

                              <p class="text-body fs-5">you earned a "Top endorsed" <i class="bi-patch-check-fill text-primary"></i> badge</p>

                            </div>

                            <!-- End Col -->



                            <small class="col-auto text-muted text-cap">6dy</small>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->



                          <a class="stretched-link" href="#"></a>

                        </li>

                        <!-- End Item -->



                        <!-- Item -->

                        <li class="list-group-item form-check-select">

                          <div class="row">

                            <div class="col-auto">

                              <div class="d-flex align-items-center">

                                <div class="form-check">

                                  <input class="form-check-input" type="checkbox" value="" id="notificationCheck9">

                                  <label class="form-check-label" for="notificationCheck9"></label>

                                  <span class="form-check-stretched-bg"></span>

                                </div>

                                <div class="avatar avatar-sm avatar-circle">

                                  <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img8.jpg" alt="Image Description">

                                </div>

                              </div>

                            </div>

                            <!-- End Col -->



                            <div class="col ms-n2">

                              <h5 class="mb-1">Linda Bates</h5>

                              <p class="text-body fs-5">Accepted your connection</p>

                            </div>

                            <!-- End Col -->



                            <small class="col-auto text-muted text-cap">17dy</small>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->



                          <a class="stretched-link" href="#"></a>

                        </li>

                        <!-- End Item -->



                        <!-- Item -->

                        <li class="list-group-item form-check-select">

                          <div class="row">

                            <div class="col-auto">

                              <div class="d-flex align-items-center">

                                <div class="form-check">

                                  <input class="form-check-input" type="checkbox" value="" id="notificationCheck10">

                                  <label class="form-check-label" for="notificationCheck10"></label>

                                  <span class="form-check-stretched-bg"></span>

                                </div>

                                <div class="avatar avatar-sm avatar-soft-dark avatar-circle">

                                  <span class="avatar-initials">L</span>

                                </div>

                              </div>

                            </div>

                            <!-- End Col -->



                            <div class="col ms-n2">

                              <h5 class="mb-1">Lewis Clarke</h5>

                              <p class="text-body fs-5">completed <i class="bi-journal-bookmark-fill text-primary"></i> FD-134 task</p>

                            </div>

                            <!-- End Col -->



                            <small class="col-auto text-muted text-cap">2mts</small>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->



                          <a class="stretched-link" href="#"></a>

                        </li>

                        <!-- End Item -->

                      </ul>

                      <!-- End List Group -->

                    </div>

                  </div>

                  <!-- End Tab Content -->

                </div>

                <!-- End Body -->



                <!-- Card Footer -->

                <a class="card-footer text-center" href="#">

                  View all notifications <i class="bi-chevron-right"></i>

                </a>

                <!-- End Card Footer -->

              </div>

            </div>

            <!-- End Notification -->

          </li>



          <li class="nav-item d-none d-sm-inline-block">

            <!-- Apps -->

            <div class="dropdown">

              <button type="button" class="btn btn-icon btn-ghost-secondary rounded-circle" id="navbarAppsDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-dropdown-animation>

                <i class="bi-app-indicator"></i>

              </button>



              <div class="dropdown-menu dropdown-menu-end dropdown-card navbar-dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="navbarAppsDropdown" style="width: 25rem;">

                <!-- Header -->

                <div class="card-header">

                  <h4 class="card-title">Web apps &amp; services</h4>

                </div>

                <!-- End Header -->



                <!-- Body -->

                <div class="card-body card-body-height">

                  <a class="dropdown-item" href="#">

                    <div class="d-flex align-items-center">

                      <div class="flex-shrink-0">

                        <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/brands/atlassian-icon.svg" alt="Image Description">

                      </div>

                      <div class="flex-grow-1 text-truncate ms-3">

                        <h5 class="mb-0">Atlassian</h5>

                        <p class="card-text text-body">Security and control across Cloud</p>

                      </div>

                    </div>

                  </a>



                  <a class="dropdown-item" href="#">

                    <div class="d-flex align-items-center">

                      <div class="flex-shrink-0">

                        <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/brands/slack-icon.svg" alt="Image Description">

                      </div>

                      <div class="flex-grow-1 text-truncate ms-3">

                        <h5 class="mb-0">Slack <span class="badge bg-primary rounded-pill text-uppercase ms-1">Try</span></h5>

                        <p class="card-text text-body">Email collaboration software</p>

                      </div>

                    </div>

                  </a>



                  <a class="dropdown-item" href="#">

                    <div class="d-flex align-items-center">

                      <div class="flex-shrink-0">

                        <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/brands/google-webdev-icon.svg" alt="Image Description">

                      </div>

                      <div class="flex-grow-1 text-truncate ms-3">

                        <h5 class="mb-0">Google webdev</h5>

                        <p class="card-text text-body">Work involved in developing a website</p>

                      </div>

                    </div>

                  </a>



                  <a class="dropdown-item" href="#">

                    <div class="d-flex align-items-center">

                      <div class="flex-shrink-0">

                        <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/brands/grownapp-icon.svg" alt="Image Description">

                      </div>

                      <div class="flex-grow-1 text-truncate ms-3">

                        <h5 class="mb-0">grownapp</h5>

                        <p class="card-text text-body">The inbox for teams</p>

                      </div>

                    </div>

                  </a>



                  <a class="dropdown-item" href="#">

                    <div class="d-flex align-items-center">

                      <div class="flex-shrink-0">

                        <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/illustrations/review-rating-shield.svg" alt="Image Description">

                      </div>

                      <div class="flex-grow-1 text-truncate ms-3">

                        <h5 class="mb-0">HS Support</h5>

                        <p class="card-text text-body">Customer service and support</p>

                      </div>

                    </div>

                  </a>



                  <a class="dropdown-item" href="#">

                    <div class="d-flex align-items-center">

                      <div class="flex-shrink-0">

                        <div class="avatar avatar-sm avatar-soft-dark">

                          <span class="avatar-initials"><i class="bi-grid"></i></span>

                        </div>

                      </div>

                      <div class="flex-grow-1 text-truncate ms-3">

                        <h5 class="mb-0">More grown products</h5>

                        <p class="card-text text-body">Check out more HS products</p>

                      </div>

                    </div>

                  </a>

                </div>

                <!-- End Body -->



                <!-- Footer -->

                <a class="card-footer text-center" href="#">

                  View all apps <i class="bi-chevron-right"></i>

                </a>

                <!-- End Footer -->

              </div>

            </div>

            <!-- End Apps -->

          </li>



          <li class="nav-item d-none d-sm-inline-block">

            <!-- Activity -->

            <button class="btn btn-ghost-secondary btn-icon rounded-circle" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasActivityStream" aria-controls="offcanvasActivityStream">

              <i class="bi-x-diamond"></i>

            </button>

            <!-- Activity -->

          </li>



          <li class="nav-item">

            <!-- Account -->

            <div class="dropdown">

              <a class="navbar-dropdown-account-wrapper" href="javascript:;" id="accountNavbarDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside" data-bs-dropdown-animation>

                <div class="avatar avatar-sm avatar-circle">

                  <img class="avatar-img" src="<?php echo esc_url( get_avatar_url( $user->ID ) ); ?>" alt="Image Description">

                  <span class="avatar-status avatar-sm-status avatar-status-success"></span>

                </div>

              </a>



              <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless navbar-dropdown-account" aria-labelledby="accountNavbarDropdown" style="width: 16rem;">

                <div class="dropdown-item-text">

                  <div class="d-flex align-items-center">

                    <div class="avatar avatar-sm avatar-circle">

                      <img class="avatar-img" src="<?php echo esc_url( get_avatar_url( $user->ID ) ); ?>" alt="Image Description">

                    </div>

                    <div class="flex-grow-1 ms-3">

                      <h5 class="mb-0">Mark Williams</h5>

                      <p class="card-text text-body">mark@site.com</p>

                    </div>

                  </div>

                </div>



                <div class="dropdown-divider"></div>



                <!-- Dropdown -->

                <div class="dropdown">

                  <a class="navbar-dropdown-submenu-item dropdown-item dropdown-toggle" href="javascript:;" id="navSubmenuPagesAccountDropdown1" data-bs-toggle="dropdown" aria-expanded="false">Set status</a>



                  <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless navbar-dropdown-sub-menu" aria-labelledby="navSubmenuPagesAccountDropdown1">

                    <a class="dropdown-item" href="#">

                      <span class="legend-indicator bg-success me-1"></span> Available

                    </a>

                    <a class="dropdown-item" href="#">

                      <span class="legend-indicator bg-danger me-1"></span> Busy

                    </a>

                    <a class="dropdown-item" href="#">

                      <span class="legend-indicator bg-warning me-1"></span> Away

                    </a>

                    <div class="dropdown-divider"></div>

                    <a class="dropdown-item" href="#"> Reset status

                    </a>

                  </div>

                </div>

                <!-- End Dropdown -->



                <a class="dropdown-item" href="#">Profile &amp; account</a>

                <a class="dropdown-item" href="#">Settings</a>



                <div class="dropdown-divider"></div>





                <a class="dropdown-item" href="#">Manage team</a>



                <div class="dropdown-divider"></div>



                <a class="dropdown-item" href="#">Sign out</a>

              </div>

            </div>

            <!-- End Account -->

          </li>

        </ul>

        <!-- End Navbar -->

      </div>

    </div>

  </header>



  <!-- ========== END HEADER ========== -->



  <!-- ========== MAIN CONTENT ========== -->

  <!-- Navbar Vertical -->



  <aside class="js-navbar-vertical-aside navbar navbar-vertical-aside navbar-vertical navbar-vertical-fixed navbar-expand-xl navbar-bordered bg-white  ">

    <div class="navbar-vertical-container">

      <div class="navbar-vertical-footer-offset">

        <!-- Logo -->



        <a class="navbar-brand" href="http://grown.technoart.org/" aria-label="grown">

            <img class="navbar-brand-logo" src="http://grown.technoart.org/wp-content/uploads/2022/01/preview-centered-logo-experience-1-copy.jpg" alt="Logo" data-hs-theme-appearance="default">

            <img class="navbar-brand-logo" src="http://grown.technoart.org/wp-content/uploads/2022/01/preview-centered-logo-experience-1-copy.jpg" alt="Logo" data-hs-theme-appearance="dark">

            <img class="navbar-brand-logo-mini" src="http://grown.technoart.org/wp-content/uploads/2022/01/preview-centered-logo-experience-1-copy.jpg" alt="Logo" data-hs-theme-appearance="default">

            <img class="navbar-brand-logo-mini" src="http://grown.technoart.org/wp-content/uploads/2022/01/preview-centered-logo-experience-1-copy.jpg" alt="Logo" data-hs-theme-appearance="dark">

          </a>

  

          <!-- End Logo -->



        <!-- Navbar Vertical Toggle -->

        <button type="button" class="js-navbar-vertical-aside-toggle-invoker navbar-aside-toggler">

          <i class="bi-arrow-bar-left navbar-toggler-short-align" data-bs-template='<div class="tooltip d-none d-md-block" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>' data-bs-toggle="tooltip" data-bs-placement="right" title="Collapse"></i>

          <i class="bi-arrow-bar-right navbar-toggler-full-align" data-bs-template='<div class="tooltip d-none d-md-block" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>' data-bs-toggle="tooltip" data-bs-placement="right" title="Expand"></i>

        </button>



        <!-- End Navbar Vertical Toggle -->



        <!-- Content -->

        <div class="navbar-vertical-content">

          <div id="navbarVerticalMenu" class="nav nav-pills nav-vertical card-navbar-nav">

            <!-- Collapse -->

            <div class="nav-item">

                <span class="nav-link-title"><a class="nav-link" href="index.html">Dashboards</a></span>



              <div id="navbarVerticalMenuDashboards" class="nav-collapse collapse show" data-bs-parent="#navbarVerticalMenu">

                <a class="nav-link active" href="index.html">Default</a>

                <a class="nav-link " href="dashboard-alternative.html">Alternative</a>

              </div>

            </div>

            <!-- End Collapse -->



            <span class="dropdown-header mt-4">Pages</span>

            <small class="bi-three-dots nav-subtitle-replacer"></small>



            <!-- Collapse -->

            <div class="navbar-nav nav-compact">



            </div>

            <div id="navbarVerticalMenuPagesMenu">

                <!-- Collapse -->

                <div class="nav-item">

                  <a class="nav-link dropdown-toggle " href="#navbarVerticalMenuPagesUsersMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesUsersMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesUsersMenu">

                    <i class="bi-people nav-icon"></i>

                    <span class="nav-link-title">Members</span>

                  </a>

  

                  <div id="navbarVerticalMenuPagesUsersMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenu">

                    <a class="nav-link " href="users.html">Grown</a>

                    <a class="nav-link " href="users.html">Born</a>

                    <a class="nav-link " href="users.html">Investors</a>

                    <a class="nav-link " href="users.html">Mentors</a>

                  </div>

                </div>

                <!-- End Collapse -->

  

                <!-- Collapse -->

                <div class="nav-item">

                  <a class="nav-link dropdown-toggle " href="#navbarVerticalMenuPagesUserProfileMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesUserProfileMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesUserProfileMenu">

                    <i class="bi-person nav-icon"></i>

                    <span class="nav-link-title">Member Profile <span class="badge bg-primary rounded-pill ms-1">5</span></span>

                  </a>

  

                  <div id="navbarVerticalMenuPagesUserProfileMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenu">

                    <a class="nav-link " href="user-profile.html">Profile</a>

                  </div>

                </div>

                <!-- End Collapse -->

  

                <!-- Collapse -->

                <div class="nav-item">

                  <a class="nav-link dropdown-toggle " href="#navbarVerticalMenuPagesAccountMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesAccountMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesAccountMenu">

                    <i class="bi-person-badge nav-icon"></i>

                    <span class="nav-link-title">Account</span>

                  </a>

  

                  <div id="navbarVerticalMenuPagesAccountMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenu">

                    <a class="nav-link " href="account-settings.html">Settings</a>

                    <a class="nav-link " href="account-billing.html">Billing</a>

                    <a class="nav-link " href="account-invoice.html">Invoice</a>

                  </div>

                </div>

                <!-- End Collapse -->

  

                <!-- Collapse -->

                <div class="nav-item">

                  <a class="nav-link dropdown-toggle " href="#navbarVerticalMenuPagesEcommerceMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesEcommerceMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesEcommerceMenu">

                    <i class="bi-basket nav-icon"></i>

                    <span class="nav-link-title">Courses</span>

                  </a>

  

                  <div id="navbarVerticalMenuPagesEcommerceMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenu">

                    <a class="nav-link " href="ecommerce.html">Overview</a>

  

                    <div id="navbarVerticalMenuPagesMenuEcommerce">

                      <!-- Collapse -->

                      <div class="nav-item">

                        <a class="nav-link dropdown-toggle" href="#navbarVerticalMenuPagesEcommerceProductsMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesEcommerceProductsMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesEcommerceProductsMenu">

                          Products

                        </a>

  

                        <div id="navbarVerticalMenuPagesEcommerceProductsMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenuEcommerce">

                          <a class="nav-link " href="ecommerce-products.html">Products</a>

                          <a class="nav-link " href="ecommerce-product-details.html">Product Details</a>

                          <a class="nav-link " href="ecommerce-add-product.html">Add Product</a>

                        </div>

                      </div>

                      <!-- End Collapse -->

  

                      <!-- Collapse -->

                      <div class="nav-item">

                        <a class="nav-link dropdown-toggle" href="#navbarVerticalMenuPagesEcommerceOrdersMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesEcommerceOrdersMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesEcommerceOrdersMenu">

                          Orders

                        </a>

  

                        <div id="navbarVerticalMenuPagesEcommerceOrdersMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenuEcommerce">

                          <a class="nav-link " href="ecommerce-orders.html">Orders</a>

                          <a class="nav-link " href="ecommerce-order-details.html">Order Details</a>

                        </div>

                      </div>

                      <!-- End Collapse -->

  

                      <!-- Collapse -->

                      <div class="nav-item">

                        <a class="nav-link dropdown-toggle" href="#navbarVerticalMenuPagesEcommerceCustomersMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesEcommerceCustomersMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesEcommerceCustomersMenu">

                          Customers

                        </a>

  

                        <div id="navbarVerticalMenuPagesEcommerceCustomersMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenuEcommerce">

                          <a class="nav-link " href="ecommerce-customers.html">Customers</a>

                          <a class="nav-link " href="ecommerce-customer-details.html">Customer Details</a>

                          <a class="nav-link " href="ecommerce-add-customers.html">Add Customers</a>

                        </div>

                      </div>

                      <!-- End Collapse -->

                    </div>

  

                    <a class="nav-link " href="ecommerce-referrals.html">Referrals</a>

                    <a class="nav-link " href="ecommerce-manage-reviews.html">Manage Reviews</a>

                    <a class="nav-link " href="ecommerce-checkout.html">Checkout</a>

                  </div>

                </div>

                <!-- End Collapse -->

  

                <!-- Collapse -->

                <div class="nav-item">

                  <a class="nav-link dropdown-toggle " href="#navbarVerticalMenuPagesEcommerceMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesEcommerceMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesEcommerceMenu">

                    <i class="bi-basket nav-icon"></i>

                    <span class="nav-link-title">Out of the Box</span>

                  </a>

  

                  <div id="navbarVerticalMenuPagesEcommerceMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenu">

                    <a class="nav-link " href="ecommerce.html">Overview</a>

  

                    <div id="navbarVerticalMenuPagesMenuEcommerce">

                      <!-- Collapse -->

                      <div class="nav-item">

                        <a class="nav-link dropdown-toggle" href="#navbarVerticalMenuPagesEcommerceProductsMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesEcommerceProductsMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesEcommerceProductsMenu">

                          Products

                        </a>

  

                        <div id="navbarVerticalMenuPagesEcommerceProductsMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenuEcommerce">

                          <a class="nav-link " href="ecommerce-products.html">Products</a>

                          <a class="nav-link " href="ecommerce-product-details.html">Product Details</a>

                          <a class="nav-link " href="ecommerce-add-product.html">Add Product</a>

                        </div>

                      </div>

                      <!-- End Collapse -->

  

                      <!-- Collapse -->

                      <div class="nav-item">

                        <a class="nav-link dropdown-toggle" href="#navbarVerticalMenuPagesEcommerceOrdersMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesEcommerceOrdersMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesEcommerceOrdersMenu">

                          Orders

                        </a>

  

                        <div id="navbarVerticalMenuPagesEcommerceOrdersMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenuEcommerce">

                          <a class="nav-link " href="ecommerce-orders.html">Orders</a>

                          <a class="nav-link " href="ecommerce-order-details.html">Order Details</a>

                        </div>

                      </div>

                      <!-- End Collapse -->

  

                      <!-- Collapse -->

                      <div class="nav-item">

                        <a class="nav-link dropdown-toggle" href="#navbarVerticalMenuPagesEcommerceCustomersMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesEcommerceCustomersMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesEcommerceCustomersMenu">

                          Customers

                        </a>

  

                        <div id="navbarVerticalMenuPagesEcommerceCustomersMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenuEcommerce">

                          <a class="nav-link " href="ecommerce-customers.html">Customers</a>

                          <a class="nav-link " href="ecommerce-customer-details.html">Customer Details</a>

                          <a class="nav-link " href="ecommerce-add-customers.html">Add Customers</a>

                        </div>

                      </div>

                      <!-- End Collapse -->

                    </div>

  

                    <a class="nav-link " href="ecommerce-referrals.html">Referrals</a>

                    <a class="nav-link " href="ecommerce-manage-reviews.html">Manage Reviews</a>

                    <a class="nav-link " href="ecommerce-checkout.html">Checkout</a>

                  </div>

                </div>

                <!-- End Collapse -->

  

                <!-- Collapse -->

                <div class="nav-item">

                  <a class="nav-link dropdown-toggle " href="#navbarVerticalMenuPagesProjectsMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesProjectsMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesProjectsMenu">

                    <i class="bi-stickies nav-icon"></i>

                    <span class="nav-link-title">Program</span>

                  </a>

  

                  <div id="navbarVerticalMenuPagesProjectsMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenu">

                    <a class="nav-link " href="projects.html">Overview</a>

                    <a class="nav-link " href="projects-timeline.html">Timeline</a>

                  </div>

                </div>

                <!-- End Collapse -->

  

                <!-- Collapse -->

                <div class="nav-item">

                  <a class="nav-link dropdown-toggle " href="#navbarVerticalMenuPagesProjectMenu" role="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalMenuPagesProjectMenu" aria-expanded="false" aria-controls="navbarVerticalMenuPagesProjectMenu">

                    <i class="bi-briefcase nav-icon"></i>

                    <span class="nav-link-title">Startups</span>

                  </a>

  

                  <div id="navbarVerticalMenuPagesProjectMenu" class="nav-collapse collapse " data-bs-parent="#navbarVerticalMenuPagesMenu">

                    <a class="nav-link " href="project.html">Overview</a>

                    <a class="nav-link " href="project-files.html">Files</a>

                    <a class="nav-link " href="project-activity.html">Activity</a>

                    <a class="nav-link " href="project-teams.html">Teams</a>

                    <a class="nav-link " href="project-settings.html">Settings</a>

                  </div>

                </div>

                <!-- End Collapse -->

  

  

          </div>

        <!-- End Content -->



        <!-- Footer -->

        <div class="navbar-vertical-footer">

          <ul class="navbar-vertical-footer-list">

            <li class="navbar-vertical-footer-list-item">

              <!-- Style Switcher -->

              <div class="dropdown dropup">

                <button type="button" class="btn btn-ghost-secondary btn-icon rounded-circle" id="selectThemeDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-dropdown-animation>



                </button>



                <div class="dropdown-menu navbar-dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="selectThemeDropdown">

                  <a class="dropdown-item" href="#" data-icon="bi-moon-stars" data-value="auto">

                    <i class="bi-moon-stars me-2"></i>

                    <span class="text-truncate" title="Auto (system default)">Auto (system default)</span>

                  </a>

                  <a class="dropdown-item" href="#" data-icon="bi-brightness-high" data-value="default">

                    <i class="bi-brightness-high me-2"></i>

                    <span class="text-truncate" title="Default (light mode)">Default (light mode)</span>

                  </a>

                  <a class="dropdown-item active" href="#" data-icon="bi-moon" data-value="dark">

                    <i class="bi-moon me-2"></i>

                    <span class="text-truncate" title="Dark">Dark</span>

                  </a>

                </div>

              </div>



              <!-- End Style Switcher -->

            </li>



            <li class="navbar-vertical-footer-list-item">

              <!-- Other Links -->

              <div class="dropdown dropup">

                <button type="button" class="btn btn-ghost-secondary btn-icon rounded-circle" id="otherLinksDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-dropdown-animation>

                  <i class="bi-info-circle"></i>

                </button>



                <div class="dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="otherLinksDropdown">

                  <span class="dropdown-header">Help</span>

                  <a class="dropdown-item" href="#">

                    <i class="bi-journals dropdown-item-icon"></i>

                    <span class="text-truncate" title="Resources &amp; tutorials">Resources &amp; tutorials</span>

                  </a>

                  <a class="dropdown-item" href="#">

                    <i class="bi-command dropdown-item-icon"></i>

                    <span class="text-truncate" title="Keyboard shortcuts">Keyboard shortcuts</span>

                  </a>

                  <a class="dropdown-item" href="#">

                    <i class="bi-alt dropdown-item-icon"></i>

                    <span class="text-truncate" title="Connect other apps">Connect other apps</span>

                  </a>

                  <a class="dropdown-item" href="#">

                    <i class="bi-gift dropdown-item-icon"></i>

                    <span class="text-truncate" title="What's new?">What's new?</span>

                  </a>

                  <div class="dropdown-divider"></div>

                  <span class="dropdown-header">Contacts</span>

                  <a class="dropdown-item" href="#">

                    <i class="bi-chat-left-dots dropdown-item-icon"></i>

                    <span class="text-truncate" title="Contact support">Contact support</span>

                  </a>

                </div>

              </div>

              <!-- End Other Links -->

            </li>



            <li class="navbar-vertical-footer-list-item">

              <!-- Language -->

              <div class="dropdown dropup">

                <button type="button" class="btn btn-ghost-secondary btn-icon rounded-circle" id="selectLanguageDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-dropdown-animation>

                  <img class="avatar avatar-xss avatar-circle" src="http://grown.technoart.org/dashboard/assets/vendor/flag-icon-css/flags/1x1/us.svg" alt="United States Flag">

                </button>



                <div class="dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="selectLanguageDropdown">

                  <span class="dropdown-header">Select language</span>

                  <a class="dropdown-item" href="#">

                    <img class="avatar avatar-xss avatar-circle me-2" src="http://grown.technoart.org/dashboard/assets/vendor/flag-icon-css/flags/1x1/us.svg" alt="Flag">

                    <span class="text-truncate" title="English">English (US)</span>

                  </a>

                  <a class="dropdown-item" href="#">

                    <img class="avatar avatar-xss avatar-circle me-2" src="http://grown.technoart.org/dashboard/assets/vendor/flag-icon-css/flags/1x1/gb.svg" alt="Flag">

                    <span class="text-truncate" title="English">English (UK)</span>

                  </a>

                  <a class="dropdown-item" href="#">

                    <img class="avatar avatar-xss avatar-circle me-2" src="http://grown.technoart.org/dashboard/assets/vendor/flag-icon-css/flags/1x1/de.svg" alt="Flag">

                    <span class="text-truncate" title="Deutsch">Deutsch</span>

                  </a>

                  <a class="dropdown-item" href="#">

                    <img class="avatar avatar-xss avatar-circle me-2" src="http://grown.technoart.org/dashboard/assets/vendor/flag-icon-css/flags/1x1/dk.svg" alt="Flag">

                    <span class="text-truncate" title="Dansk">Dansk</span>

                  </a>

                  <a class="dropdown-item" href="#">

                    <img class="avatar avatar-xss avatar-circle me-2" src="http://grown.technoart.org/dashboard/assets/vendor/flag-icon-css/flags/1x1/it.svg" alt="Flag">

                    <span class="text-truncate" title="Italiano">Italiano</span>

                  </a>

                  <a class="dropdown-item" href="#">

                    <img class="avatar avatar-xss avatar-circle me-2" src="http://grown.technoart.org/dashboard/assets/vendor/flag-icon-css/flags/1x1/cn.svg" alt="Flag">

                    <span class="text-truncate" title="中文 (繁體)">中文 (繁體)</span>

                  </a>

                </div>

              </div>



              <!-- End Language -->

            </li>

          </ul>

        </div>

        <!-- End Footer -->

      </div>

    </div>

  </aside>



  <main id="content" role="main" class="main">

    <!-- Content -->

    <div class="content container-fluid">

      <!-- Page Header -->

      <div class="page-header">

        <div class="row align-items-end">

          <div class="col-sm mb-2 mb-sm-0">

            <nav aria-label="breadcrumb">

              <ol class="breadcrumb breadcrumb-no-gutter">

                <li class="breadcrumb-item"><a class="breadcrumb-link" href="javascript:;">Pages</a></li>

                <li class="breadcrumb-item"><a class="breadcrumb-link" href="javascript:;">Account</a></li>

                <li class="breadcrumb-item active" aria-current="page">Settings</li>

              </ol>

            </nav>



            <h1 class="page-header-title">Settings</h1>

          </div>

          <!-- End Col -->



          <div class="col-sm-auto">

            <a class="btn btn-primary" href="user-profile-my-profile.html">

              <i class="bi-person-fill me-1"></i> My profile

            </a>

          </div>

          <!-- End Col -->

        </div>

        <!-- End Row -->

      </div>

      <!-- End Page Header -->



      <div class="row">

        <div class="col-lg-3">

          <!-- Navbar -->

          <div class="navbar-expand-lg navbar-vertical mb-3 mb-lg-5">

            <!-- Navbar Toggle -->

            <!-- Navbar Toggle -->

            <div class="d-grid">

              <button type="button" class="navbar-toggler btn btn-white mb-3" data-bs-toggle="collapse" data-bs-target="#navbarVerticalNavMenu" aria-label="Toggle navigation" aria-expanded="false" aria-controls="navbarVerticalNavMenu">

                <span class="d-flex justify-content-between align-items-center">

                  <span class="text-dark">Menu</span>



                  <span class="navbar-toggler-default">

                    <i class="bi-list"></i>

                  </span>



                  <span class="navbar-toggler-toggled">

                    <i class="bi-x"></i>

                  </span>

                </span>

              </button>

            </div>

            <!-- End Navbar Toggle -->

            <!-- End Navbar Toggle -->



            <!-- Navbar Collapse -->

            <div id="navbarVerticalNavMenu" class="collapse navbar-collapse">

              <ul id="navbarSettings" class="js-sticky-block js-scrollspy card card-navbar-nav nav nav-tabs nav-lg nav-vertical" data-hs-sticky-block-options='{

                     "parentSelector": "#navbarVerticalNavMenu",

                     "targetSelector": "#header",

                     "breakpoint": "lg",

                     "startPoint": "#navbarVerticalNavMenu",

                     "endPoint": "#stickyBlockEndPoint",

                     "stickyOffsetTop": 20

                   }'>

                <li class="nav-item">

                  <a class="nav-link active" href="#content">

                    <i class="bi-person nav-icon"></i> Basic information

                  </a>

                </li>

                <li class="nav-item">

                  <a class="nav-link" href="#emailSection">

                    <i class="bi-at nav-icon"></i> Email

                  </a>

                </li>

                <li class="nav-item">

                  <a class="nav-link" href="#passwordSection">

                    <i class="bi-key nav-icon"></i> Password

                  </a>

                </li>

                <li class="nav-item">

                  <a class="nav-link" href="#preferencesSection">

                    <i class="bi-gear nav-icon"></i> Preferences

                  </a>

                </li>

                <li class="nav-item">

                  <a class="nav-link" href="#twoStepVerificationSection">

                    <i class="bi-shield-lock nav-icon"></i> Two-step verification

                  </a>

                </li>

                <li class="nav-item">

                  <a class="nav-link" href="#recentDevicesSection">

                    <i class="bi-phone nav-icon"></i> Recent devices

                  </a>

                </li>

                <li class="nav-item">

                  <a class="nav-link" href="#notificationsSection">

                    <i class="bi-bell nav-icon"></i> Notifications

                  </a>

                </li>

                <li class="nav-item">

                  <a class="nav-link" href="#connectedAccountsSection">

                    <i class="bi-diagram-3 nav-icon"></i> Connected accounts

                  </a>

                </li>

                <li class="nav-item">

                  <a class="nav-link" href="#socialAccountsSection">

                    <i class="bi-instagram nav-icon"></i> Social accounts

                  </a>

                </li>

                <li class="nav-item">

                  <a class="nav-link" href="#deleteAccountSection">

                    <i class="bi-trash nav-icon"></i> Delete account

                  </a>

                </li>

              </ul>

            </div>

            <!-- End Navbar Collapse -->

          </div>

          <!-- End Navbar -->

        </div>



        <div class="col-lg-9">

          <div class="d-grid gap-3 gap-lg-5">

            <!-- Card -->

            <div class="card">

              <!-- Profile Cover -->

              <div class="profile-cover">

                <div class="profile-cover-img-wrapper">

                  <img id="profileCoverImg" class="profile-cover-img" src="<?php  echo $image[0]; ?>" alt="Image Description">



                  <!-- Custom File Cover -->

                  <div class="profile-cover-content profile-cover-uploader p-3">
				  
				<form method="POST" enctype="multipart/form-data" name="header_pic_form">
                <input onchange="previewFile1(this);" type="file" class="js-file-attach avatar-uploader-input" name="header_pic" id="header_pic" >
				<input type="hidden" name="action" value="header_pic_action">
				</form>
				

                    <label onclick="open_file('header_pic');"  class="profile-cover-uploader-label btn btn-sm btn-white" for="profileCoverUplaoder">

                      <i class="bi-camera-fill"></i>

                      <span class="d-none d-sm-inline-block ms-1">Upload header</span>

                    </label>

                  </div>

                  <!-- End Custom File Cover -->

                </div>

              </div>

              <!-- End Profile Cover -->



              <!-- Avatar -->

              <label class="avatar avatar-xxl avatar-circle avatar-uploader profile-cover-avatar" for="editAvatarUploaderModal">

                <img id="profile_pic_img" class="avatar-img" src="<?php echo $profile_pic_img[0]; ?>" alt="Image Description" onclick="open_file('profile_pic');">


			<form method="POST" enctype="multipart/form-data" name="profile_pic_form">
                <input onchange="previewFile(this);" type="file" class="js-file-attach avatar-uploader-input" name="profile_pic" id="profile_pic" >
				<input type="hidden" name="action" value="profile_pic_action">
				</form>


                <span class="avatar-uploader-trigger">

                  <i onclick="open_file('profile_pic');" class="bi-pencil-fill avatar-uploader-icon shadow-sm"></i>

                </span>

              </label>

              <!-- End Avatar -->



              <!-- Body -->
<div class="card-body">
                <div class="row">
                  <div class="col-sm-5">
                    <span class="d-block fs-5 mb-2">Member Type</span>
					<?php $member_type = get_user_meta(get_current_user_id(),'member_type',true);  ?>
					<?php $terms_and_conditions = get_user_meta(get_current_user_id(),'terms_and_conditions',true);  ?>
                    <!-- Select -->
                    <div class="tom-select-custom">
                      <select onchange="member_type();" class="js-select form-select tomselected" id="member_type" tabindex="-1" hidden="hidden">
					  <option value="Community Member" <?php if($member_type == "Community Member") { echo 'selected';}   ?>>Community Member</option>
                        
                        <option value="Grown Member" <?php if($member_type == "Grown Member") { echo 'selected';}   ?>>Grown Member</option>
                        <option value="Born Member" <?php if($member_type == "Born Member") { echo 'selected';}   ?>>Born Member</option>
                        <option value="Born Member" <?php if($member_type == "Investor") { echo 'selected';}   ?>>Investor</option>
                        <option value="Mentor" <?php if($member_type == "Mentor") { echo 'selected';}   ?>>Mentor</option>  
                        <option value="Partner" <?php if($member_type == "Partner") { echo 'selected';}   ?>>Partner</option>  
                      </select>
                      <input onchange="term_change();" type="checkbox" id="terms" name="terms" value="terms" class="terms-condition-checkbox" value="Yes" <?php if($terms_and_conditions == "Yes") { echo 'checked'; }   ?>>
                        <label for="terms"> I agree to the <a href="#">Terms and Conditions</a></label>
                    </div>
                    <!-- End Select -->
                  </div>
                  <!-- End Col -->
                </div>
                <!-- End Row -->
              </div>
            <?php /*  <div class="card-body">

                <div class="row">

                  <div class="col-sm-5">

                    <span class="d-block fs-5 mb-2">Who can see your profile photo? <i class="bi-question-circle" data-bs-toggle="tooltip" data-bs-placement="top" title="Your visibility setting only applies to your profile photo. Your header image is always visible to anyone."></i></span>



                    <!-- Select -->

                    <div class="tom-select-custom">

                      <select class="js-select form-select" data-hs-tom-select-options='{

                                "searchInDropdown": false,

                                "dropdownWidth": "auto"

                              }'>

                        <option value="privacy1" data-option-template='<div class="d-flex align-items-start"><div class="flex-shrink-0"><i class="bi-globe"></i></div><div class="flex-grow-1 ms-2"><span class="d-block fw-semi-bold">Anyone</span><span class="tom-select-custom-hide small">Visible to anyone who can view your content. Accessible by installed apps.</span></div></div>'>Anyone</option>

                        <option value="privacy2" data-option-template='<div class="d-flex align-items-start"><div class="flex-shrink-0"><i class="bi-lock"></i></div><div class="flex-grow-1 ms-2"><span class="d-block fw-semi-bold">Only you</span><span class="tom-select-custom-hide small">Only visible to you.</span></div></div>'>Only you</option>

                      </select>

                    </div>

                    <!-- End Select -->

                  </div>

                  <!-- End Col -->

                </div>

                <!-- End Row -->

              </div> */ ?>

              <!-- End Body -->

            </div>

            <!-- End Card -->



            <!-- Card -->

            <div class="card">

              <div class="card-header">

                <h2 class="card-title h4">Basic information</h2>

              </div>



              <!-- Body -->

              <div class="card-body">

                <!-- Form -->

                <form method="POST" name="basic_information">

                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="firstName" class="col-sm-3 col-form-label form-label">Full name <i class="bi-question-circle text-body ms-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Displayed on public forums, such as grown."></i></label>



                    <div class="col-sm-9">

                      <div class="input-group input-group-sm-vertical">

                        <input value="<?php echo get_user_meta(get_current_user_id(),'first_name',true); ?>" type="text" class="form-control" name="firstName" id="firstName" placeholder="Your first name" aria-label="Your first name" >

                        <input type="text" value="<?php echo get_user_meta(get_current_user_id(),'last_name',true); ?>" class="form-control" name="lastName" id="lastNameLabel" placeholder="Your last name" aria-label="Your last name" >

                      </div>

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="email" class="col-sm-3 col-form-label form-label">Email</label>



                    <div class="col-sm-9">

                      <input type="email" class="form-control" name="email" id="email" placeholder="Email" aria-label="Email" value="<?php  echo $current_user->data->user_email; ?>">

                    </div>

                  </div>

                  <!-- End Form -->



                  <div class="row mb-4">

                    <label for="selina_id" class="col-sm-3 col-form-label form-label">Selina ID</label>



                    <div class="col-sm-9">

                      <input type="number" value="<?php echo get_user_meta(get_current_user_id(),'selina_id',true); ?>" class="form-control" name="selina_id" id="selina_id" placeholder="Selina ID" aria-label="Email" >

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="phoneLabel" class="col-sm-3 col-form-label form-label">Phone <span class="form-label-secondary">(Optional)</span></label>



                    <div class="col-sm-9">

                      <input value="<?php echo get_user_meta(get_current_user_id(),'phone',true); ?>"  type="text" class="js-input-mask form-control" name="phone" id="phoneLabel" placeholder="+x(xxx)xxx-xx-xx" aria-label="+x(xxx)xxx-xx-xx" value="+1 (609) 972-22-22" data-hs-mask-options='{

                               "mask": "+0(000)000-00-00"

                             }'>

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="organization" class="col-sm-3 col-form-label form-label">Organization</label>



                    <div class="col-sm-9">

                      <input value="<?php echo get_user_meta(get_current_user_id(),'organization',true); ?>"  type="text" class="form-control" name="organization" id="organization" placeholder="Your organization" aria-label="Your organization" value="Htmlstream">

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="department" class="col-sm-3 col-form-label form-label">Department</label>



                    <div class="col-sm-9">

                      <input value="<?php echo get_user_meta(get_current_user_id(),'department',true); ?>"  type="text" class="form-control" name="department" id="department" placeholder="Your department" aria-label="Your department">

                    </div>

                  </div>

                  <!-- End Form -->


				
				
				
				<?php $account_type =  get_user_meta(get_current_user_id(),'account_type',true); ?>
                  <!-- Form -->

                  <div id="accountType" class="row mb-4">

                    <label class="col-sm-3 col-form-label form-label">Account type</label>



                    <div class="col-sm-9">

                      <div class="input-group input-group-sm-vertical">

                        <!-- Radio Check -->

                        <label class="form-control" for="userAccountTypeRadio1">

                          <span class="form-check">

                            <input <?php if($account_type == "Individual") { echo "checked"; }   ?> type="radio" class="form-check-input" value="Individual" name="userAccountTypeRadio" id="userAccountTypeRadio1" >

                            <span class="form-check-label">Individual</span>

                          </span>

                        </label>

                        <!-- End Radio Check -->



                        <!-- Radio Check -->

                        <label class="form-control" for="userAccountTypeRadio2">

                          <span class="form-check">

                            <input <?php if($account_type == "Company") { echo "checked"; }   ?> type="radio" class="form-check-input" name="userAccountTypeRadio" id="userAccountTypeRadio2" value="Company">

                            <span class="form-check-label">Company</span>

                          </span>

                        </label>

                        <!-- End Radio Check -->

                      </div>

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="country" class="col-sm-3 col-form-label form-label">Location</label>



                    <div class="col-sm-9">

                      <!-- Select -->
						<?php 
						$country =  get_user_meta(get_current_user_id(),'country',true);
						global $wpdb;
						$sql = "Select * from wp_country_data";
						$results = $wpdb->get_results($sql);
						 ?>
                      <div class="tom-select-custom mb-4">

                        <select class="js-select form-select" name="country" id="country">
							
							<?php  foreach($results as $result){ ?>
						 <option value="<?php echo $result->code;  ?>" <?php  if($country == $result->code) { echo 'selected'; } ?>  src="<?php echo $result->flag;  ?>" alt="<?php echo $result->name;  ?> Flag" /><span class="text-truncate"><?php echo $result->name;  ?></span></option>
						<?php  } ?>
							
							
                          


                         


                          

                        </select>
						<div class="location-checkbox">
                        <input type="checkbox" id="default_location" name="default_location" value="Yes">
                        <label for="default_location">Set my default location when i travel</label><br>
                        </div>

                      </div>

                      <!-- End Select -->



                      <div class="mb-3">

                        <input type="text"  class="form-control" name="city" id="city" placeholder="City" aria-label="City" value="<?php echo get_user_meta(get_current_user_id(),'city',true); ?>">

                      </div>



                      <input type="text" class="form-control" name="state" id="state" placeholder="State" aria-label="State" value="<?php echo get_user_meta(get_current_user_id(),'state',true); ?>">

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="addressLine1" class="col-sm-3 col-form-label form-label">Address line 1</label>



                    <div class="col-sm-9">

                      <input type="text" class="form-control" name="addressLine1" id="addressLine1" placeholder="Your address" aria-label="Your address" value="<?php echo get_user_meta(get_current_user_id(),'address_line_1',true); ?>">

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="addressLine2Label" class="col-sm-3 col-form-label form-label">Address line 2 <span class="form-label-secondary">(Optional)</span></label>



                    <div class="col-sm-9">

                      <input type="text" class="form-control" name="addressLine2" id="addressLine2Label" placeholder="Your address" aria-label="Your address" value="<?php echo get_user_meta(get_current_user_id(),'address_line_2',true); ?>">

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="zipCode" class="col-sm-3 col-form-label form-label">Zip code <i class="bi-question-circle text-body ms-1" data-bs-toggle="tooltip" data-bs-placement="top" title="You can find your code in a postal address."></i></label>



                    <div class="col-sm-9">

                      <input type="text" class="js-input-mask form-control" name="zipCode" id="zipCode" placeholder="Your zip code" aria-label="Your zip code" value="<?php echo get_user_meta(get_current_user_id(),'zip_code',true); ?>" data-hs-mask-options='{

                               "mask": "AA0 0AA"

                             }'>

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form -->

                 

                  <!-- End Form -->


				<input type="hidden" name="action" value="basic_form">
				<input type="hidden" name="pre_email" value="<?php  echo $current_user->data->user_email; ?>">
                  <div class="d-flex justify-content-end">

                    <button type="submit" class="btn btn-primary">Save changes <i style="display:none;" id="loader1" class="fas fa-spinner fa-spin"></i></button>

                  </div>
				<div id="baisc_form_alert"></div>
                </form>
		        <!-- End Form -->

              </div>

              <!-- End Body -->

            </div>

            <!-- End Card -->



            <!-- Card -->

            <div id="emailSection" class="card">

              <div class="card-header">

                <h4 class="card-title">Email</h4>

              </div>



              <!-- Body -->

              <div class="card-body">

                <p>Your current email address is <span class="fw-semi-bold"><?php  echo $current_user->data->user_email; ?></span></p>



                <!-- Form -->

                <form method="POST" name="email_form">

                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="email2" class="col-sm-3 col-form-label form-label">New email address</label>



                    <div class="col-sm-9">

                      <input type="email" class="form-control" name="email2" id="email2" placeholder="Enter new email address" aria-label="Enter new email address">

                    </div>

                  </div>

                  <!-- End Form -->



                  <div class="d-flex justify-content-end">
				<input type="hidden" name="action" value="email_form_action">
				<input type="hidden" name="pre_email2" value="<?php  echo $current_user->data->user_email; ?>">
                    <button type="submit" class="btn btn-primary">Save changes <i style="display:none;" id="loader2" class="fas fa-spinner fa-spin"></i></button>

                  </div>
				<div id="email_form_alert"></div>
                </form>

                <!-- End Form -->

              </div>

              <!-- End Body -->

            </div>

            <!-- End Card -->



            <!-- Card -->

            <div id="passwordSection" class="card">

              <div class="card-header">

                <h4 class="card-title">Change your password</h4>

              </div>



              <!-- Body -->

              <div class="card-body">

                <!-- Form -->

                <form id="changePasswordForm" method="POST" name="change_password_form">

                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="currentPassword" class="col-sm-3 col-form-label form-label">Current password</label>



                    <div class="col-sm-9">

                      <input type="password" class="form-control" name="currentPassword" id="currentPassword" placeholder="Enter current password" aria-label="Enter current password">

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="newPassword" class="col-sm-3 col-form-label form-label">New password</label>



                    <div class="col-sm-9">

                      <input type="password" class="form-control" name="newPassword" id="newPassword" placeholder="Enter new password" aria-label="Enter new password">

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="confirmNewPassword" class="col-sm-3 col-form-label form-label">Confirm new password</label>



                    <div class="col-sm-9">

                      <div class="mb-3">

                        <input type="password" class="form-control" name="confirmNewPassword" id="confirmNewPassword" placeholder="Confirm your new password" aria-label="Confirm your new password">

                      </div>



                      <h5>Password requirements:</h5>



                      <p class="fs-6 mb-2">Ensure that these requirements are met:</p>



                      <ul class="fs-6">

                        <li>Minimum 8 characters long - the more, the better</li>

                        <li>At least one lowercase character</li>

                        <li>At least one uppercase character</li>

                        <li>At least one number, symbol, or whitespace character</li>

                      </ul>

                    </div>

                  </div>

                  <!-- End Form -->
				  
				  <div class="d-flex justify-content-end">
				<input type="hidden" name="action" value="change_password_form_action">
				
                    <button type="submit" class="btn btn-primary">Save Changes <i style="display:none;" id="loader3" class="fas fa-spinner fa-spin"></i></button>

                  </div>
				  <div id="change_password_form_alert"></div>

                </form>

                <!-- End Form -->

              </div>

              <!-- End Body -->

            </div>

            <!-- End Card -->



            <!-- Card -->

            <div id="preferencesSection" class="card">

              <div class="card-header">

                <h4 class="card-title">Preferences</h4>

              </div>



              <!-- Body -->

              <div class="card-body">

                <!-- Form -->

                <form method="POST" name="preferences_form">

                  <!-- Form -->

                  <div class="row mb-4">
				<?php $language =  get_user_meta(get_current_user_id(),'language',true); ?>
                    <label for="language_option" class="col-sm-3 col-form-label form-label">Language</label>



                    <div class="col-sm-9">

                      <!-- Select -->

                      <div class="tom-select-custom">

                        <select class="js-select form-select" name="language_option" id="language_option" data-hs-tom-select-options='{

                                  "searchInDropdown": false

                                }'>

                          <option label="empty"></option>

                          <option <?php  if($language == "language1") { echo "selected"; }  ?>  value="language1" data-option-template='<span class="d-flex align-items-center"><img class="avatar avatar-xss avatar-circle me-2" src="http://grown.technoart.org/dashboard/assets/vendor/flag-icon-css/flags/1x1/us.svg" alt="Image description" width="16"/><span>English (US)</span></span>'>English (US)</option>

                          <option <?php  if($language == "language2") { echo "selected"; }  ?>  value="language2" selected data-option-template='<span class="d-flex align-items-center"><img class="avatar avatar-xss avatar-circle me-2" src="http://grown.technoart.org/dashboard/assets/vendor/flag-icon-css/flags/1x1/gb.svg" alt="Image description" width="16"/><span>English (UK)</span></span>'>English (UK)</option>

                        

                        </select>

                      </div>

                      <!-- End Select -->

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form -->

                  <div class="row mb-4">

                    <label for="time_zone" class="col-sm-3 col-form-label form-label">Time zone</label>



                    <div class="col-sm-9">

                      <input type="text" class="form-control" name="time_zone" id="time_zone" placeholder="Your time zone" aria-label="Your time zone" value="<?php echo get_user_meta(get_current_user_id(),'time_zone',true); ?>"  >

                    </div>

                  </div>

                  <!-- End Form -->



                  <!-- Form Switch -->
				<?php 
				$early_release = get_user_meta(get_current_user_id(),'early_release',true);
				$who_view_my_profile = get_user_meta(get_current_user_id(),'who_view_my_profile',true);
				?>
                  <label class="row form-check form-switch mb-4" for="early_release">

                    <span class="col-8 col-sm-9 ms-0">

                      <span class="d-block text-dark">Early release</span>

                      <span class="d-block fs-5">Get included on early releases for new grown features.</span>

                    </span>

                    <span class="col-4 col-sm-3 text-end">

                      <input value="Yes" type="checkbox" class="form-check-input" name="early_release" id="early_release" <?php if($early_release == 'Yes') { echo 'checked';} ?>>

                    </span>

                  </label>

                  <!-- End Form Switch -->



                  <!-- Form Switch -->

                  <label class="row form-check form-switch mb-4" for="accounrSettingsPreferencesSwitch2">

                    <span class="col-8 col-sm-9 ms-0">

                      <span class="d-block text-dark mb-1">See info about people who view my profile</span>

                      <span class="d-block fs-5 text-muted"><a class="link" href="#">More about viewer info</a>.</span>

                    </span>

                    <span class="col-4 col-sm-3 text-end">

                      <input value="Yes" type="checkbox" class="form-check-input" id="view_profile" name="view_profile" <?php if($who_view_my_profile == 'Yes') { echo 'checked';} ?>>

                    </span>

                  </label>

                  <!-- End Form Switch -->

				  
				  
				  


                  <div class="d-flex justify-content-end">
			<input type="hidden" name="action" value="preferences_form_action">
                    <button type="submit" class="btn btn-primary">Save Changes <i style="display:none;" id="loader4" class="fas fa-spinner fa-spin"></i></button>

                  </div>
			<div id="pre_form_alert"></div>
                </form>

                <!-- End Form -->

              </div>

              <!-- End Body -->

            </div>

            <!-- End Card -->



            



            <!-- Card -->
						<?php 
						
						global $wpdb;
						$wp_fa_user_logins = "Select * from wp_fa_user_logins where user_id=".get_current_user_id();
						$wp_fa_user_logins = $wpdb->get_results($wp_fa_user_logins);
						 ?>
            <div id="recentDevicesSection" class="card">

              <div class="card-header">

                <h4 class="card-title">Recent devices</h4>

              </div>



              <!-- Body -->

              <div class="card-body">

                <p class="card-text">View and manage devices where you're currently logged in.</p>

              </div>

              <!-- End Body -->



              <!-- Table -->

              <div class="table-responsive">

                <table class="table table-thead-bordered table-nowrap table-align-middle card-table">

                  <thead class="thead-light">

                    <tr>

                      <th>Browser</th>

                      <th>Device</th>

                      <th>Location</th>

                      <th>Most recent activity</th>

                    </tr>

                  </thead>



                  <tbody>
					<?php foreach($wp_fa_user_logins as $wp_fa_user_login) {  ?>
					<tr>

                      <td class="align-items-center">

                        <img class="avatar avatar-xss me-2" src="http://grown.technoart.org/dashboard/assets/svg/brands/chrome-icon.svg" alt="Image Description"> <?php echo $wp_fa_user_login->browser; ?>

                      </td>

                      <td><?php echo $wp_fa_user_login->operating_system; ?> </td>

                      <td><?php echo ip_info($wp_fa_user_login->ip_address, "Country"); ?></td>

                      <td><?php echo $wp_fa_user_login->time_login; ?></td>

                    </tr>
					<?php }  ?>
                   </tbody>

                </table>

              </div>

              <!-- End Table -->

            </div>

            <!-- End Card -->



            <!-- Card -->

            <div id="notificationsSection" class="card">

              <div class="card-header">

                <h4 class="card-title">Notifications</h4>

              </div>



              <!-- Alert -->

              <div class="alert alert-soft-dark card-alert text-center" role="alert">

                We need permission from your browser to show notifications. <a class="alert-link" href="#">Request permission</a>

              </div>

              <!-- End Alert -->



              <form method="POST" name="notifications_form">

                <!-- Table -->

                <div class="table-responsive datatable-custom">

                  <table class="table table-thead-bordered table-nowrap table-align-middle table-first-col-px-0">

                    <thead class="thead-light">

                      <tr>

                        <th>Type</th>

                        <th class="text-center">

                          <div class="mb-1">

                            <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/illustrations/oc-email-at.svg" alt="Image Description" data-hs-theme-appearance="default">

                            <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/illustrations-light/oc-email-at.svg" alt="Image Description" data-hs-theme-appearance="dark">

                          </div>

                          Email

                        </th>

                        <th class="text-center">

                          <div class="mb-1">

                            <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/illustrations/oc-globe.svg" alt="Image Description" data-hs-theme-appearance="default">

                            <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/illustrations-light/oc-globe.svg" alt="Image Description" data-hs-theme-appearance="dark">

                          </div>

                          Browser

                        </th>

                        <th class="text-center">

                          <div class="mb-1">

                            <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/illustrations/oc-phone.svg" alt="Image Description" data-hs-theme-appearance="default">

                            <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/illustrations-light/oc-phone.svg" alt="Image Description" data-hs-theme-appearance="dark">

                          </div>

                          App

                        </th>

                      </tr>

                    </thead>


<?php 
$new_for_you = get_user_meta(get_current_user_id(),'new_for_you',true);
$account_activity = get_user_meta(get_current_user_id(),'account_activity',true);
$a_new_browser_used_to_sign_in = get_user_meta(get_current_user_id(),'a_new_browser_used_to_sign_in',true);

 
?>
                    <tbody>

                      <tr>

                        <td>New for you</td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input class="form-check-input" type="checkbox" name="new_for_you[]" value="EMAIL" <?php  if (in_array("EMAIL", $new_for_you))  { echo 'checked'; } ?> id="editUserModalAlertsCheckbox1" >

                            <label class="form-check-label" for="editUserModalAlertsCheckbox1"></label>

                          </div>

                        </td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input class="form-check-input" type="checkbox" name="new_for_you[]" value="BROWSER" <?php  if (in_array("BROWSER", $new_for_you))  { echo 'checked'; } ?> id="editUserModalAlertsCheckbox2">

                            <label class="form-check-label" for="editUserModalAlertsCheckbox2"></label>

                          </div>

                        </td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input class="form-check-input" type="checkbox" name="new_for_you[]" value="APP" <?php  if (in_array("APP", $new_for_you))  { echo 'checked'; } ?> id="editUserModalAlertsCheckbox3">

                            <label class="form-check-label" for="editUserModalAlertsCheckbox3"></label>

                          </div>

                        </td>

                      </tr>



                      <tr>

                        <td>Account activity <i class="bi-question-circle text-body ms-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Get important notifications about you or activity you've missed"></i></td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input <?php  if (in_array("EMAIL", $account_activity))  { echo 'checked'; } ?> class="form-check-input" type="checkbox" name="account_activity[]" value="EMAIL" id="editUserModalAlertsCheckbox4">

                            <label class="form-check-label" for="editUserModalAlertsCheckbox4"></label>

                          </div>

                        </td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input <?php  if (in_array("BROWSER", $account_activity))  { echo 'checked'; } ?> class="form-check-input" type="checkbox" name="account_activity[]" value="BROWSER" id="editUserModalAlertsCheckbox5" >

                            <label class="form-check-label" for="editUserModalAlertsCheckbox5"></label>

                          </div>

                        </td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input <?php  if (in_array("APP", $account_activity))  { echo 'checked'; } ?> class="form-check-input" type="checkbox" name="account_activity[]" value="APP" id="editUserModalAlertsCheckbox6" >

                            <label class="form-check-label" for="editUserModalAlertsCheckbox6"></label>

                          </div>

                        </td>

                      </tr>



                      <tr>

                        <td>A new browser used to sign in</td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input <?php  if (in_array("EMAIL", $a_new_browser_used_to_sign_in))  { echo 'checked'; } ?> class="form-check-input" type="checkbox" name="new_browser[]" value="EMAIL" id="editUserModalAlertsCheckbox7" >

                            <label class="form-check-label" for="editUserModalAlertsCheckbox7"></label>

                          </div>

                        </td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input <?php  if (in_array("BROWSER", $a_new_browser_used_to_sign_in))  { echo 'checked'; } ?> class="form-check-input" type="checkbox" name="new_browser[]" value="BROWSER" id="editUserModalAlertsCheckbox8" >

                            <label class="form-check-label" for="editUserModalAlertsCheckbox8"></label>

                          </div>

                        </td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input <?php  if (in_array("APP", $a_new_browser_used_to_sign_in))  { echo 'checked'; } ?> class="form-check-input" type="checkbox" name="new_browser[]" value="APP" id="editUserModalAlertsCheckbox9" >

                            <label class="form-check-label" for="editUserModalAlertsCheckbox9"></label>

                          </div>

                        </td>

                      </tr>


<?php

$a_new_device_is_linked = get_user_meta(get_current_user_id(),'a_new_device_is_linked',true);
$a_new_device_connected = get_user_meta(get_current_user_id(),'a_new_device_connected',true);

 
?>
                      <tr>

                        <td>A new device is linked</td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input <?php  if (in_array("EMAIL", $a_new_device_is_linked))  { echo 'checked'; } ?> class="form-check-input" type="checkbox" name="device_linked[]" value="EMAIL" id="editUserModalAlertsCheckbox10">

                            <label class="form-check-label" for="editUserModalAlertsCheckbox10"></label>

                          </div>

                        </td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input <?php  if (in_array("BROWSER", $a_new_device_is_linked))  { echo 'checked'; } ?> class="form-check-input" type="checkbox" name="device_linked[]" value="BROWSER" id="editUserModalAlertsCheckbox11" >

                            <label class="form-check-label" for="editUserModalAlertsCheckbox11"></label>

                          </div>

                        </td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input <?php  if (in_array("APP", $a_new_device_is_linked))  { echo 'checked'; } ?> class="form-check-input" type="checkbox" name="device_linked[]" value="APP" id="editUserModalAlertsCheckbox12">

                            <label class="form-check-label" for="editUserModalAlertsCheckbox12"></label>

                          </div>

                        </td>

                      </tr>



                      <tr>

                        <td>A new device connected <i class="bi-question-circle text-body ms-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Email me when a new device connected"></i></td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input <?php  if (in_array("EMAIL", $a_new_device_connected))  { echo 'checked'; } ?> class="form-check-input" type="checkbox" name="device_connected[]" value="EMAIL" id="editUserModalAlertsCheckbox13">

                            <label class="form-check-label" for="editUserModalAlertsCheckbox13"></label>

                          </div>

                        </td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input <?php  if (in_array("BROWSER", $a_new_device_connected))  { echo 'checked'; } ?> class="form-check-input" type="checkbox" name="device_connected[]" value="BROWSER" id="editUserModalAlertsCheckbox14" >

                            <label class="form-check-label" for="editUserModalAlertsCheckbox14"></label>

                          </div>

                        </td>

                        <td class="text-center">

                          <div class="form-check form-check-inline">

                            <input <?php  if (in_array("APP", $a_new_device_connected))  { echo 'checked'; } ?> class="form-check-input" type="checkbox" name="device_connected[]" value="APP" id="editUserModalAlertsCheckbox15" >

                            <label class="form-check-label" for="editUserModalAlertsCheckbox15"></label>

                          </div>

                        </td>

                      </tr>

                    </tbody>

                  </table>

                </div>

                <!-- End Table -->

              



              <hr>

<?php


$when_should_we_send_you_notifications = get_user_meta(get_current_user_id(),'when_should_we_send_you_notifications',true);
$send_me_a_daily_summary_day = get_user_meta(get_current_user_id(),'send_me_a_daily_summary_day',true);
$send_me_a_daily_summary_time = get_user_meta(get_current_user_id(),'send_me_a_daily_summary_time',true);
 
?>

              <!-- Body -->

              <div class="card-body">

                <div class="row">

                  <div class="col-sm">

                    <!-- Form -->

                    <div class="mb-4">

                      <p class="card-text">When should we send you notifications?</p>



                      <!-- Select -->

                      <div class="tom-select-custom">

                        <select name="when_should_we_send_you_notifications" class="js-select form-select" autocomplete="off" data-hs-tom-select-options='{

                                    "searchInDropdown": false,

                                    "width": "15rem",

                                    "hideSearch": true

                                  }'>

                          <option <?php if($when_should_we_send_you_notifications == "Always") { echo 'selected';}   ?>   value="Always">Always</option>

                          <option <?php if($when_should_we_send_you_notifications == "Only when I'm online") { echo 'selected';}   ?> value="Only when I'm online">Only when I'm online</option>

                        </select>

                      </div>

                      <!-- End Select -->

                    </div>

                    <!-- End Form -->

                  </div>

                  <!-- End Col -->



                  <div class="col-sm">

                    <!-- Form -->

                    <div class="mb-4">

                      <p class="card-text">Send me a daily summary ("Daily Digest") of task activity.</p>



                      <div class="row">

                        <div class="col-auto mb-2">

                          <!-- Select -->

                          <div class="tom-select-custom">

                            <select name="send_me_a_daily_summary_day" class="js-select form-select" autocomplete="off" data-hs-tom-select-options='{

                                      "searchInDropdown": false,

                                      "hideSearch": true,

                                      "dropdownWidth": "10rem"

                                    }'>

                              <option <?php if($send_me_a_daily_summary_day == "Every day") { echo 'selected';} ?> value="Every day">Every day</option>

                              <option <?php if($send_me_a_daily_summary_day == "Weekdays") { echo 'selected';} ?> value="Weekdays" >Weekdays</option>

                              <option <?php if($send_me_a_daily_summary_day == "Never") { echo 'selected';} ?>  value="Never">Never</option>

                            </select>

                          </div>

                          <!-- End Select -->

                        </div>

                        <!-- End Col -->



                        <div class="col-auto mb-2">

                          <!-- Select -->

                          <div class="tom-select-custom">

                            <select name="send_me_a_daily_summary_time" class="js-select form-select" autocomplete="off" data-hs-tom-select-options='{

                                      "searchInDropdown": false,

                                      "hideSearch": true,

                                      "dropdownWidth": "10rem"

                                    }'>

                              <option <?php if($send_me_a_daily_summary_time == "at 12 AM") { echo 'selected';} ?> value="at 12 AM">at 12 AM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 1 AM") { echo 'selected';} ?> value="at 1 AM">at 1 AM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 2 AM") { echo 'selected';} ?> value="at 2 AM">at 2 AM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 3 AM") { echo 'selected';} ?> value="at 3 AM">at 3 AM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 4 AM") { echo 'selected';} ?> value="at 4 AM">at 4 AM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 5 AM") { echo 'selected';} ?> value="at 5 AM">at 5 AM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 6 AM") { echo 'selected';} ?> value="at 6 AM">at 6 AM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 7 AM") { echo 'selected';} ?> value="at 7 AM">at 7 AM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 8 AM") { echo 'selected';} ?> value="at 8 AM">at 8 AM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 9 AM") { echo 'selected';} ?> value="at 9 AM">at 9 AM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 10 AM") { echo 'selected';} ?> value="at 10 AM">at 10 AM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 11 AM") { echo 'selected';} ?> value="at 11 AM">at 11 AM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 12 AM") { echo 'selected';} ?>value="at 12 PM">at 12 PM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 1 PM") { echo 'selected';} ?>value="at 1 PM">at 1 PM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 2 PM") { echo 'selected';} ?>value="at 2 PM">at 2 PM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 3 PM") { echo 'selected';} ?>value="at 3 PM">at 3 PM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 4 PM") { echo 'selected';} ?>value="at 4 PM">at 4 PM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 5 PM") { echo 'selected';} ?>value="at 5 PM">at 5 PM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 6 PM") { echo 'selected';} ?>value="at 6 PM">at 6 PM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 7 PM") { echo 'selected';} ?>value="at 7 PM">at 7 PM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 8 PM") { echo 'selected';} ?>value="at 8 PM">at 8 PM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 9 PM") { echo 'selected';} ?>value="at 9 PM">at 9 PM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 10 PM") { echo 'selected';} ?>value="at 10 PM">at 10 PM</option>
                              <option <?php if($send_me_a_daily_summary_time == "at 11 PM") { echo 'selected';} ?>value="at 11 PM">at 11 PM</option>
                              

                              

                            </select>

                          </div>

                          <!-- End Select -->

                        </div>

                        <!-- End Col -->

                      </div>

                      <!-- End Row -->

                    </div>

                    <!-- End Form -->

                  </div>

                  <!-- End Col -->

                </div>

                <!-- End Row -->



                <p class="card-text">In order to cut back on noise, email notifications are grouped together and only sent when you're idle or offline.</p>



                <div class="d-flex justify-content-end">
				<input type="hidden" name="action" value="notifications_form_action">
                  <button type="submit" class="btn btn-primary">Save changes <i style="display:none;" id="loader5" class="fas fa-spinner fa-spin"></i></button>

                </div>
				<div id="notifications_form_alert"></div>

              </div>

              <!-- End Body -->
</form>
            </div>

            <!-- End Card -->



            <!-- Card -->

            <div id="connectedAccountsSection" class="card">

              <div class="card-header">

                <h4 class="card-title">Connected accounts</h4>

              </div>



              <!-- Body -->

              <div class="card-body">

                <p class="card-text">Integrated features from these accounts make it easier to collaborate with people you know on grown Dashboard.</p>



                <!-- Form -->

                <form method="POST" name="connected_accounts">

                  <div class="list-group list-group-lg list-group-flush list-group-no-gutters">

                    <!-- List Item -->

                    <div class="list-group-item">

                      <div class="d-flex">

                        <div class="flex-shrink-0">

                          <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/brands/google-icon.svg" alt="Image Description">

                        </div>



                        <div class="flex-grow-1 ms-3">

                          <div class="row align-items-center">

                            <div class="col">

                              <h4 class="mb-0">Google</h4>

                              <p class="fs-5 text-body mb-0">Calendar and contacts</p>

                            </div>

                            <!-- End Col -->


						<?php 
						$google =  get_user_meta(get_current_user_id(),'google',true);
						$selina =  get_user_meta(get_current_user_id(),'selina',true);
						$spec =  get_user_meta(get_current_user_id(),'spec',true);
						$slack =  get_user_meta(get_current_user_id(),'slack',true);
						$mailchimp =  get_user_meta(get_current_user_id(),'mailchimp',true);
						$google_webdev =  get_user_meta(get_current_user_id(),'google_webdev',true);
						?>
                            <div class="col-auto">

                              <!-- Form Switch -->

                              <div class="form-check form-switch">

                                <input onchange="run_connected('google_con');" value="Yes"  <?php if($google == 'Yes') { echo 'checked'; }  ?>  class="form-check-input" type="checkbox" id="google_con" name="google_con">
								
								

                                <label class="form-check-label" for="google_con"></label>

                              </div>

                              <!-- End Form Switch -->

                            </div>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->

                        </div>

                      </div>

                    </div>

                    <!-- End List Item -->





                                        <!-- List Item -->

                                        <div class="list-group-item">

                                            <div class="d-flex">

                                              <div class="flex-shrink-0">

                                                <img class="avatar avatar-xs" src="http://grown.technoart.org/wp-content/uploads/2022/03/selina_logo_black.b62a0982.svg" alt="Image Description">

                                              </div>

                      

                                              <div class="flex-grow-1 ms-3">

                                                <div class="row align-items-center">

                                                  <div class="col">

                                                    <h4 class="mb-0">Selina</h4>

                                                    <p class="fs-5 text-body mb-0">Account</p>

                                                  </div>

                                                  <!-- End Col -->

                      

                                                  <div class="col-auto">

                                                    <!-- Form Switch -->

                                                    <div class="form-check form-switch">

                                                      <input onchange="run_connected('selina_con');" value="Yes"  <?php if($selina == 'Yes') { echo 'checked'; }  ?>  class="form-check-input" type="checkbox" id="selina_con" name="selina_con">

                                                      <label class="form-check-label" for="selina_con"></label>

                                                    </div>

                                                    <!-- End Form Switch -->

                                                  </div>

                                                  <!-- End Col -->

                                                </div>

                                                <!-- End Row -->

                                              </div>

                                            </div>

                                          </div>

                                          <!-- End List Item -->



                    <!-- List Item -->

                    <div class="list-group-item">

                      <div class="d-flex">

                        <div class="flex-shrink-0">

                          <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/brands/spec-icon.svg" alt="Image Description">

                        </div>



                        <div class="flex-grow-1 ms-3">

                          <div class="row align-items-center">

                            <div class="col">

                              <h4 class="mb-0">Spec</h4>

                              <p class="fs-5 text-body mb-0">Project management</p>

                            </div>

                            <!-- End Col -->



                            <div class="col-auto">

                              <!-- Form Switch -->

                              <div class="form-check form-switch">

                                <input onchange="run_connected('spec_con');" value="Yes"  <?php if($spec == 'Yes') { echo 'checked'; }  ?>  class="form-check-input" type="checkbox" id="spec_con" name="spec_con">
                                <label class="form-check-label" for="spec_con"></label>

                              </div>

                              <!-- End Form Switch -->

                            </div>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->

                        </div>

                      </div>

                    </div>

                    <!-- End List Item -->



                    <!-- List Item -->

                    <div class="list-group-item">

                      <div class="d-flex">

                        <div class="flex-shrink-0">

                          <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/brands/slack-icon.svg" alt="Image Description">

                        </div>



                        <div class="flex-grow-1 ms-3">

                          <div class="row align-items-center">

                            <div class="col">

                              <h4 class="mb-0">Slack</h4>

                              <p class="fs-5 text-body mb-0">Communication <a class="link" href="#">Learn more</a></p>

                            </div>

                            <!-- End Col -->



                            <div class="col-auto">

                              <!-- Form Switch -->

                              <div class="form-check form-switch">

                               <input onchange="run_connected('slack_con');" value="Yes"  <?php if($slack == 'Yes') { echo 'checked'; }  ?>  class="form-check-input" type="checkbox" id="slack_con" name="slack_con">

                                <label class="form-check-label" for="slack_con"></label>

                              </div>

                              <!-- End Form Switch -->

                            </div>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->

                        </div>

                      </div>

                    </div>

                    <!-- End List Item -->



                    <!-- List Item -->

                    <div class="list-group-item">

                      <div class="d-flex">

                        <div class="flex-shrink-0">

                          <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/brands/mailchimp-icon.svg" alt="Image Description">

                        </div>



                        <div class="flex-grow-1 ms-3">

                          <div class="row align-items-center">

                            <div class="col">

                              <h4 class="mb-0">Mailchimp</h4>

                              <p class="fs-5 text-body mb-0">Email marketing service</p>

                            </div>

                            <!-- End Col -->



                            <div class="col-auto">

                              <!-- Form Switch -->

                              <div class="form-check form-switch">
							  
							<input onchange="run_connected('mailchimp');" value="Yes"  <?php if($mailchimp == 'Yes') { echo 'checked'; }  ?>  class="form-check-input" type="checkbox" id="mailchimp" name="mailchimp">
							
							
                                

                                <label class="form-check-label" for="mailchimp"></label>

                              </div>

                              <!-- End Form Switch -->

                            </div>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->

                        </div>

                      </div>

                    </div>

                    <!-- End List Item -->



                    <!-- List Item -->

                    <div class="list-group-item">

                      <div class="d-flex">

                        <div class="flex-shrink-0">

                          <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/brands/google-webdev-icon.svg" alt="Image Description">

                        </div>



                        <div class="flex-grow-1 ms-3">

                          <div class="row align-items-center">

                            <div class="col">

                              <h4 class="mb-0">Google Webdev</h4>

                              <p class="fs-5 text-body mb-0">Tools for Web Developers <a class="link" href="#">Learn more</a></p>

                            </div>

                            <!-- End Col -->



                            <div class="col-auto">

                              <!-- Form Switch -->

                              <div class="form-check form-switch">

                              <input onchange="run_connected('google_webdev');" value="Yes"  <?php if($google_webdev == 'Yes') { echo 'checked'; }  ?>  class="form-check-input" type="checkbox" id="google_webdev" name="google_webdev">
                                <label class="form-check-label" for="google_webdev"></label>

                              </div>

                              <!-- End Form Switch -->

                            </div>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->

                        </div>

                      </div>

                    </div>

                    <!-- End List Item -->

                  </div>

                </form>

                <!-- End Form -->

              </div>

              <!-- End Body -->

            </div>

            <!-- End Card -->



            <!-- Card -->

            <div id="socialAccountsSection" class="card">

              <div class="card-header">

                <h4 class="card-title">Social accounts</h4>

              </div>



              <!-- Body -->

              <div class="card-body">

                <form>

                  <div class="list-group list-group-lg list-group-flush list-group-no-gutters">

                    <!-- Item -->

                    <div class="list-group-item">

                      <div class="d-flex">

                        <div class="flex-shrink-0">

                          <i class="bi-twitter list-group-icon"></i>

                        </div>



                        <div class="flex-grow-1">

                          <div class="row align-items-center">

                            <div class="col-sm mb-2 mb-sm-0">

                              <h4 class="mb-0">Twitter</h4>

                              <a class="fs-5" href="#">www.twitter.com/htmlstream</a>

                            </div>

                            <!-- End Col -->



                            <div class="col-sm-auto">

                              <a class="btn btn-white btn-sm" href="javascript:;">Disconnect</a>

                            </div>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->

                        </div>

                      </div>

                    </div>

                    <!-- End Item -->



                    <!-- Item -->

                    <div class="list-group-item">

                      <div class="d-flex">

                        <div class="flex-shrink-0">

                          <i class="bi-facebook list-group-icon"></i>

                        </div>



                        <div class="flex-grow-1">

                          <div class="row align-items-center">

                            <div class="col-sm mb-2 mb-sm-0">

                              <h4 class="mb-0">Facebook</h4>

                              <a class="fs-5" href="#">www.facebook.com/htmlstream</a>

                            </div>

                            <!-- End Col -->



                            <div class="col-sm-auto">

                              <a class="btn btn-white btn-sm" href="javascript:;">Disconnect</a>

                            </div>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->

                        </div>

                      </div>

                    </div>

                    <!-- End Item -->



                    <!-- Item -->

                    <div class="list-group-item">

                      <div class="d-flex">

                        <div class="flex-shrink-0">

                          <i class="bi-slack list-group-icon"></i>

                        </div>



                        <div class="flex-grow-1">

                          <div class="row align-items-center">

                            <div class="col-sm mb-2 mb-sm-0">

                              <h4 class="mb-0">Slack</h4>

                              <p class="fs-5 text-body mb-0">Not connected</p>

                            </div>

                            <!-- End Col -->



                            <div class="col-sm-auto">

                              <a class="btn btn-white btn-sm" href="javascript:;">Connect</a>

                            </div>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->

                        </div>

                      </div>

                    </div>

                    <!-- End Item -->



                    <!-- Item -->

                    <div class="list-group-item">

                      <div class="d-flex">

                        <div class="flex-shrink-0">

                          <i class="bi-linkedin list-group-icon"></i>

                        </div>



                        <div class="flex-grow-1">

                          <div class="row align-items-center">

                            <div class="col-sm mb-2 mb-sm-0">

                              <h4 class="mb-0">Linkedin</h4>

                              <a class="fs-5" href="#">www.linkedin.com/htmlstream</a>

                            </div>

                            <!-- End Col -->



                            <div class="col-sm-auto">

                              <a class="btn btn-white btn-sm" href="javascript:;">Disconnect</a>

                            </div>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->

                        </div>

                      </div>

                    </div>

                    <!-- End Item -->



                    <!-- Item -->

                    <div class="list-group-item">

                      <div class="d-flex">

                        <div class="flex-shrink-0">

                          <i class="bi-google list-group-icon"></i>

                        </div>



                        <div class="flex-grow-1">

                          <div class="row align-items-center">

                            <div class="col-sm mb-2 mb-sm-0">

                              <h4 class="mb-0">Google</h4>

                              <p class="fs-5 text-body mb-0">Not connected</p>

                            </div>

                            <!-- End Col -->



                            <div class="col-sm-auto">

                              <a class="btn btn-white btn-sm" href="javascript:;">Connect</a>

                            </div>

                            <!-- End Col -->

                          </div>

                          <!-- End Row -->

                        </div>

                      </div>

                    </div>

                    <!-- End Item -->

                  </div>

                </form>

              </div>

              <!-- End Body -->

            </div>

            <!-- End Card -->



            <!-- Card -->

            <div id="deleteAccountSection" class="card">

              <div class="card-header">

                <h4 class="card-title">Delete your account</h4>

              </div>



              <!-- Body -->

              <div class="card-body">
<form method="POST" name="delete_account_form">
                <p class="card-text">When you delete your account, you lose access to grown account services, and we permanently delete your personal data. You can cancel the deletion for 14 days.</p>



                <div class="mb-4">

                  <!-- Form Check -->

                  <div class="form-check">

                    <input value="Yes" class="form-check-input" type="checkbox" value="" id="deleteAccountCheckbox" name="deleteAccountCheckbox">

                    <label class="form-check-label" for="deleteAccountCheckbox">

                      Confirm that I want to delete my account.

                    </label>

                  </div>

                  <!-- End Form Check -->

                </div>



                <div class="d-flex justify-content-end gap-3">
				<input type="hidden" name="action" value="delete_account_form_action">
                  <a class="btn btn-white" href="#">Learn more</a>

                  <button type="submit" class="btn btn-danger">Delete <i style="display:none;" id="loader6" class="fas fa-spinner fa-spin"></i></button>

                </div>
				<div id="delete_account_form_alert"></div>
</form>
              </div>

              <!-- End Body -->

            </div>

            <!-- End Card -->

          </div>



          <!-- Sticky Block End Point -->

          <div id="stickyBlockEndPoint"></div>

        </div>

      </div>

      <!-- End Row -->

    </div>

    <!-- End Content -->



    <!-- Footer -->



    <div class="footer">

      <div class="row justify-content-between align-items-center">

        <div class="col">

          <p class="fs-6 mb-0">&copy; grown. <span class="d-none d-sm-inline-block">2022 Htmlstream.</span></p>

        </div>

        <!-- End Col -->



        <div class="col-auto">

          <div class="d-flex justify-content-end">

            <!-- List Separator -->

            <ul class="list-inline list-separator">

              <li class="list-inline-item">

                <a class="list-separator-link" href="#">FAQ</a>

              </li>



              <li class="list-inline-item">

                <a class="list-separator-link" href="#">License</a>

              </li>



              <li class="list-inline-item">

                <!-- Keyboard Shortcuts Toggle -->

                <button class="btn btn-ghost-secondary btn btn-icon btn-ghost-secondary rounded-circle" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasKeyboardShortcuts" aria-controls="offcanvasKeyboardShortcuts">

                  <i class="bi-command"></i>

                </button>

                <!-- End Keyboard Shortcuts Toggle -->

              </li>

            </ul>

            <!-- End List Separator -->

          </div>

        </div>

        <!-- End Col -->

      </div>

      <!-- End Row -->

    </div>



    <!-- End Footer -->

  </main>

  <!-- ========== END MAIN CONTENT ========== -->



  <!-- ONLY DEV -->



  <!-- Builder -->

  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasBuilder" aria-labelledby="offcanvasBuilderLabel">

    <div class="offcanvas-header align-items-start">

      <div>

        <h3 id="offcanvasBuilderLabel">grown Builder</h3>

        <p class="mb-0">Customize the overview page layout.</p>

      </div>

      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>

    </div>



    <div class="offcanvas-body">

      <h4 class="mb-1">Theme Appearance Mode</h4>

      <p>Check out all <a href="documentation/layout.html">Layout Options here</a></p>



      <div class="row gx-3">

        <!-- Check -->

        <div class="col-6">

          <div class="form-check form-check-label-highlighter text-center">

            <input type="radio" class="form-check-input" name="layoutSkinsRadio" id="layoutSkinsRadio1" checked value="default">

            <label class="form-check-label mb-2" for="layoutSkinsRadio1">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/img/415x310/img1.jpg" alt="Image Description">

            </label>

            <span class="form-check-text">Default</span>

          </div>

        </div>

        <!-- End Check -->



        <!-- Check -->

        <div class="col-6">

          <div class="form-check form-check-label-highlighter text-center">

            <input type="radio" class="form-check-input" name="layoutSkinsRadio" id="layoutSkinsRadio2" value="dark">

            <label class="form-check-label mb-2" for="layoutSkinsRadio2">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/img/415x310/img2.jpg" alt="Image Description">

            </label>

            <span class="form-check-text">Dark Mode</span>

          </div>

        </div>

        <!-- End Check -->

      </div>

      <!-- End Row -->



      <hr>



      <div class="row gx-3">

        <!-- Check -->

        <div class="col-6">

          <div class="form-check form-check-label-highlighter text-center">

            <input type="radio" class="form-check-input" name="layout" id="navbarLayoutSkinsRadio1" checked value="default">

            <label class="form-check-label mb-2" for="navbarLayoutSkinsRadio1">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/svg/layouts-light/sidebar-default.svg" alt="Image Description" data-hs-theme-appearance="dark">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/svg/layouts/sidebar-default.svg" alt="Image Description" data-hs-theme-appearance="default">

            </label>

            <span class="form-check-text">Default</span>

          </div>

        </div>

        <!-- End Check -->



        <!-- Check -->

        <div class="col-6">

          <div class="form-check form-check-label-highlighter text-center">

            <input type="radio" class="form-check-input" name="layout" id="navbarLayoutSkinsRadio2" value="navbar-dark">

            <label class="form-check-label mb-2" for="navbarLayoutSkinsRadio2">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/svg/layouts-light/sidebar-dark.svg" alt="Image Description" data-hs-theme-appearance="dark">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/svg/layouts/sidebar-dark.svg" alt="Image Description" data-hs-theme-appearance="default">

            </label>

            <span class="form-check-text">Dark</span>

          </div>

        </div>

        <!-- End Check -->

      </div>

      <!-- End Row -->



      <hr>



      <h4 class="mb-1">Sidebar Nav</h4>

      <p>Check out all <a href="documentation/layout.html">Layout Options here</a></p>



      <div class="row gx-3">

        <!-- Check -->

        <div class="col-6">

          <div class="form-check form-check-label-highlighter text-center">

            <input type="radio" class="form-check-input" name="sidebarNavOptions" id="sidebarNavOptions1" value="pills" checked>

            <label class="form-check-label mb-2" for="sidebarNavOptions1">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/svg/layouts-light/demo-layouts-default-classic.svg" alt="Image Description" data-hs-theme-appearance="dark">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/svg/layouts/demo-layouts-default-classic.svg" alt="Image Description" data-hs-theme-appearance="default">

            </label>

            <span class="form-check-text">Pills</span>

          </div>

        </div>

        <!-- End Check -->



        <!-- Check -->

        <div class="col-6">

          <div class="form-check form-check-label-highlighter text-center">

            <input type="radio" class="form-check-input" name="sidebarNavOptions" id="sidebarNavOptions2" value="tabs">

            <label class="form-check-label mb-2" for="sidebarNavOptions2">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/svg/layouts-light/demo-layouts-nav-tabs.svg" alt="Image Description" data-hs-theme-appearance="dark">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/svg/layouts/demo-layouts-nav-tabs.svg" alt="Image Description" data-hs-theme-appearance="default">

            </label>

            <span class="form-check-text">Tabs</span>

          </div>

        </div>

        <!-- End Check -->

      </div>

      <!-- End Row -->



      <hr>



      <!-- Form Switch -->

      <label class="row form-check form-switch mb-3" for="builderFluidSwitch">

        <span class="col-10 ms-0">

          <span class="d-block h4 mb-1">Header Layout Options</span>

          <span class="d-block fs-5">Toggle to container-fluid layout</span>

        </span>

        <span class="col-2 text-end">

          <input type="checkbox" class="form-check-input" id="builderFluidSwitch">

        </span>

      </label>

      <!-- End Form Switch -->



      <div class="row gx-3">

        <!-- Check -->

        <div class="col-6">

          <div class="form-check form-check-label-highlighter text-center">

            <input type="radio" class="form-check-input" name="layout" id="headerLayoutOptions1" value="single-header">

            <label class="form-check-label mb-2" for="headerLayoutOptions1">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/svg/layouts/header-default-container.svg" alt="Image Description" data-hs-theme-appearance="default">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/svg/layouts-light/header-default-container.svg" alt="Image Description" data-hs-theme-appearance="dark">

            </label>

            <span class="form-check-text">Default</span>

          </div>

        </div>

        <!-- End Check -->



        <!-- Check -->

        <div class="col-6">

          <div class="form-check form-check-label-highlighter text-center">

            <input type="radio" class="form-check-input" name="layout" id="headerLayoutOptions2" value="double-header">

            <label class="form-check-label mb-2" for="headerLayoutOptions2">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/svg/layouts/header-double-line-container.svg" alt="Image Description" data-hs-theme-appearance="default">

              <img class="form-check-img" src="http://grown.technoart.org/dashboard/assets/svg/layouts-light/header-double-line-container.svg" alt="Image Description" data-hs-theme-appearance="dark">

            </label>

            <span class="form-check-text">Double line</span>

          </div>

        </div>

        <!-- End Check -->

      </div>

      <!-- End Row -->

    </div>



    <!-- Footer -->

    <div class="offcanvas-footer">

      <div class="row gx-3">

        <div class="col">

          <div class="d-grid">

            <button type="button" id="js-builder-reset" class="btn btn-white btn-lg">

              <i class="bi-arrow-counterclockwise"></i> Reset

            </button>

          </div>

        </div>

        <!-- End Col -->



        <div class="col">

          <div class="d-grid">

            <button type="button" id="js-builder-preview" class="btn btn-primary btn-lg">

              <i class="eye-visible"></i> Preview

            </button>

          </div>

        </div>

        <!-- End Col -->

      </div>

      <!-- End Row -->

    </div>

    <!-- End Footer -->

  </div>



  <!-- End Builder -->



  <!-- Builder Toggle -->

  <div id="builderOffcanvas" class="position-fixed bottom-0 end-0 me-5 mb-5" style="z-index: 3;" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBuilder" aria-controls="offcanvasBuilder">

    <a class="btn btn-dark btn-lg" href="javascript:;">

      <i class="bi-sliders fs-6 me-2"></i> Customize

    </a>

  </div>

  <!-- End Builder Toggle -->



  <div class="d-none js-build-layouts">

    <div class="js-build-layout-header-default">

      <!-- Single Header -->

      <header id="header" class="navbar navbar-expand-lg navbar-bordered bg-white  ">

        <div class="container">

          <nav class="js-mega-menu navbar-nav-wrap">

            <!-- Logo -->



            <a class="navbar-brand" href="index.html" aria-label="grown">

              <img class="navbar-brand-logo" src="http://grown.technoart.org/dashboard/assets/svg/logos/logo.svg" alt="Logo" data-hs-theme-appearance="default">

              <img class="navbar-brand-logo" src="http://grown.technoart.org/dashboard/assets/svg/logos-light/logo.svg" alt="Logo" data-hs-theme-appearance="dark">

            </a>



            <!-- End Logo -->



            <!-- Secondary Content -->

            <div class="navbar-nav-wrap-secondary-content">

              <!-- Navbar -->

              <ul class="navbar-nav">

                <li class="nav-item d-none d-md-inline-block">

                  <!-- Notification -->

                  <div class="dropdown">

                    <button type="button" class="btn btn-ghost-secondary btn-icon rounded-circle" id="navbarNotificationsDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside" data-bs-dropdown-animation>

                      <i class="bi-bell"></i>

                      <span class="btn-status btn-sm-status btn-status-danger"></span>

                    </button>



                    <div class="dropdown-menu dropdown-menu-end dropdown-card navbar-dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="navbarNotificationsDropdown" style="width: 25rem;">

                      <!-- Header -->

                      <div class="card-header card-header-content-between">

                        <h4 class="card-title mb-0">Notifications</h4>



                        <!-- Unfold -->

                        <div class="dropdown">

                          <button type="button" class="btn btn-icon btn-sm btn-ghost-secondary rounded-circle" id="navbarNotificationsDropdownSettings" data-bs-toggle="dropdown" aria-expanded="false">

                            <i class="bi-three-dots-vertical"></i>

                          </button>



                          <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="navbarNotificationsDropdownSettings">

                            <span class="dropdown-header">Settings</span>

                            <a class="dropdown-item" href="#">

                              <i class="bi-archive dropdown-item-icon"></i> Archive all

                            </a>

                            <a class="dropdown-item" href="#">

                              <i class="bi-check2-all dropdown-item-icon"></i> Mark all as read

                            </a>

                            <a class="dropdown-item" href="#">

                              <i class="bi-toggle-off dropdown-item-icon"></i> Disable notifications

                            </a>

                            <a class="dropdown-item" href="#">

                              <i class="bi-gift dropdown-item-icon"></i> What's new?

                            </a>

                            <div class="dropdown-divider"></div>

                            <span class="dropdown-header">Feedback</span>

                            <a class="dropdown-item" href="#">

                              <i class="bi-chat-left-dots dropdown-item-icon"></i> Report

                            </a>

                          </div>

                        </div>

                        <!-- End Unfold -->

                      </div>

                      <!-- End Header -->



                      <!-- Nav -->

                      <ul class="nav nav-tabs nav-justified" id="notificationTab" role="tablist">

                        <li class="nav-item">

                          <a class="nav-link active" href="#notificationNavOne" id="notificationNavOne-tab" data-bs-toggle="tab" data-bs-target="#notificationNavOne" role="tab" aria-controls="notificationNavOne" aria-selected="true">Messages (3)</a>

                        </li>

                        <li class="nav-item">

                          <a class="nav-link" href="#notificationNavTwo" id="notificationNavTwo-tab" data-bs-toggle="tab" data-bs-target="#notificationNavTwo" role="tab" aria-controls="notificationNavTwo" aria-selected="false">Archived</a>

                        </li>

                      </ul>

                      <!-- End Nav -->



                      <!-- Body -->

                      <div class="card-body-height">

                        <!-- Tab Content -->

                        <div class="tab-content" id="notificationTabContent">

                          <div class="tab-pane fade show active" id="notificationNavOne" role="tabpanel" aria-labelledby="notificationNavOne-tab">

                            <!-- List Group -->

                            <ul class="list-group list-group-flush navbar-card-list-group">

                              <!-- Item -->

                              <li class="list-group-item form-check-select">

                                <div class="row">

                                  <div class="col-auto">

                                    <div class="d-flex align-items-center">

                                      <div class="form-check">

                                        <input class="form-check-input" type="checkbox" value="" id="notificationCheck1" checked>

                                        <label class="form-check-label" for="notificationCheck1"></label>

                                        <span class="form-check-stretched-bg"></span>

                                      </div>

                                      <img class="avatar avatar-sm avatar-circle" src="http://grown.technoart.org/dashboard/assets/img/160x160/img3.jpg" alt="Image Description">

                                    </div>

                                  </div>

                                  <!-- End Col -->



                                  <div class="col ms-n2">

                                    <h5 class="mb-1">Brian Warner</h5>

                                    <p class="text-body fs-5">changed an issue from "In Progress" to <span class="badge bg-success">Review</span></p>

                                  </div>

                                  <!-- End Col -->



                                  <small class="col-auto text-muted text-cap">2hr</small>

                                  <!-- End Col -->

                                </div>

                                <!-- End Row -->



                                <a class="stretched-link" href="#"></a>

                              </li>

                              <!-- End Item -->



                              <!-- Item -->

                              <li class="list-group-item form-check-select">

                                <div class="row">

                                  <div class="col-auto">

                                    <div class="d-flex align-items-center">

                                      <div class="form-check">

                                        <input class="form-check-input" type="checkbox" value="" id="notificationCheck2" checked>

                                        <label class="form-check-label" for="notificationCheck2"></label>

                                        <span class="form-check-stretched-bg"></span>

                                      </div>

                                      <div class="avatar avatar-sm avatar-soft-dark avatar-circle">

                                        <span class="avatar-initials">K</span>

                                      </div>

                                    </div>

                                  </div>

                                  <!-- End Col -->



                                  <div class="col ms-n2">

                                    <h5 class="mb-1">Klara Hampton</h5>

                                    <p class="text-body fs-5">mentioned you in a comment</p>

                                    <blockquote class="blockquote blockquote-sm">

                                      Nice work, love! You really nailed it. Keep it up!

                                    </blockquote>

                                  </div>

                                  <!-- End Col -->



                                  <small class="col-auto text-muted text-cap">10hr</small>

                                  <!-- End Col -->

                                </div>

                                <!-- End Row -->



                                <a class="stretched-link" href="#"></a>

                              </li>

                              <!-- End Item -->



                              <!-- Item -->

                              <li class="list-group-item form-check-select">

                                <div class="row">

                                  <div class="col-auto">

                                    <div class="d-flex align-items-center">

                                      <div class="form-check">

                                        <input class="form-check-input" type="checkbox" value="" id="notificationCheck3" checked>

                                        <label class="form-check-label" for="notificationCheck3"></label>

                                        <span class="form-check-stretched-bg"></span>

                                      </div>

                                      <div class="avatar avatar-sm avatar-circle">

                                        <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img10.jpg" alt="Image Description">

                                      </div>

                                    </div>

                                  </div>

                                  <!-- End Col -->



                                  <div class="col ms-n2">

                                    <h5 class="mb-1">Ruby Walter</h5>

                                    <p class="text-body fs-5">joined the Slack group HS Team</p>

                                  </div>

                                  <!-- End Col -->



                                  <small class="col-auto text-muted text-cap">3dy</small>

                                  <!-- End Col -->

                                </div>

                                <!-- End Row -->



                                <a class="stretched-link" href="#"></a>

                              </li>

                              <!-- End Item -->



                              <!-- Item -->

                              <li class="list-group-item form-check-select">

                                <div class="row">

                                  <div class="col-auto">

                                    <div class="d-flex align-items-center">

                                      <div class="form-check">

                                        <input class="form-check-input" type="checkbox" value="" id="notificationCheck4">

                                        <label class="form-check-label" for="notificationCheck4"></label>

                                        <span class="form-check-stretched-bg"></span>

                                      </div>

                                      <div class="avatar avatar-sm avatar-circle">

                                        <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/svg/brands/google-icon.svg" alt="Image Description">

                                      </div>

                                    </div>

                                  </div>

                                  <!-- End Col -->



                                  <div class="col ms-n2">

                                    <h5 class="mb-1">from Google</h5>

                                    <p class="text-body fs-5">Start using forms to capture the information of prospects visiting your Google website</p>

                                  </div>

                                  <!-- End Col -->



                                  <small class="col-auto text-muted text-cap">17dy</small>

                                  <!-- End Col -->

                                </div>

                                <!-- End Row -->



                                <a class="stretched-link" href="#"></a>

                              </li>

                              <!-- End Item -->



                              <!-- Item -->

                              <li class="list-group-item form-check-select">

                                <div class="row">

                                  <div class="col-auto">

                                    <div class="d-flex align-items-center">

                                      <div class="form-check">

                                        <input class="form-check-input" type="checkbox" value="" id="notificationCheck5">

                                        <label class="form-check-label" for="notificationCheck5"></label>

                                        <span class="form-check-stretched-bg"></span>

                                      </div>

                                      <div class="avatar avatar-sm avatar-circle">

                                        <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img7.jpg" alt="Image Description">

                                      </div>

                                    </div>

                                  </div>

                                  <!-- End Col -->



                                  <div class="col ms-n2">

                                    <h5 class="mb-1">Sara Villar</h5>

                                    <p class="text-body fs-5">completed <i class="bi-journal-bookmark-fill text-primary"></i> FD-7 task</p>

                                  </div>

                                  <!-- End Col -->



                                  <small class="col-auto text-muted text-cap">2mn</small>

                                  <!-- End Col -->

                                </div>

                                <!-- End Row -->



                                <a class="stretched-link" href="#"></a>

                              </li>

                              <!-- End Item -->

                            </ul>

                            <!-- End List Group -->

                          </div>



                          <div class="tab-pane fade" id="notificationNavTwo" role="tabpanel" aria-labelledby="notificationNavTwo-tab">

                            <!-- List Group -->

                            <ul class="list-group list-group-flush navbar-card-list-group">

                              <!-- Item -->

                              <li class="list-group-item form-check-select">

                                <div class="row">

                                  <div class="col-auto">

                                    <div class="d-flex align-items-center">

                                      <div class="form-check">

                                        <input class="form-check-input" type="checkbox" value="" id="notificationCheck6">

                                        <label class="form-check-label" for="notificationCheck6"></label>

                                        <span class="form-check-stretched-bg"></span>

                                      </div>

                                      <div class="avatar avatar-sm avatar-soft-dark avatar-circle">

                                        <span class="avatar-initials">A</span>

                                      </div>

                                    </div>

                                  </div>

                                  <!-- End Col -->



                                  <div class="col ms-n2">

                                    <h5 class="mb-1">Anne Richard</h5>

                                    <p class="text-body fs-5">accepted your invitation to join Notion</p>

                                  </div>

                                  <!-- End Col -->



                                  <small class="col-auto text-muted text-cap">1dy</small>

                                  <!-- End Col -->

                                </div>

                                <!-- End Row -->



                                <a class="stretched-link" href="#"></a>

                              </li>

                              <!-- End Item -->



                              <!-- Item -->

                              <li class="list-group-item form-check-select">

                                <div class="row">

                                  <div class="col-auto">

                                    <div class="d-flex align-items-center">

                                      <div class="form-check">

                                        <input class="form-check-input" type="checkbox" value="" id="notificationCheck7">

                                        <label class="form-check-label" for="notificationCheck7"></label>

                                        <span class="form-check-stretched-bg"></span>

                                      </div>

                                      <div class="avatar avatar-sm avatar-circle">

                                        <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img5.jpg" alt="Image Description">

                                      </div>

                                    </div>

                                  </div>

                                  <!-- End Col -->



                                  <div class="col ms-n2">

                                    <h5 class="mb-1">Finch Hoot</h5>

                                    <p class="text-body fs-5">left Slack group HS projects</p>

                                  </div>

                                  <!-- End Col -->



                                  <small class="col-auto text-muted text-cap">1dy</small>

                                  <!-- End Col -->

                                </div>

                                <!-- End Row -->



                                <a class="stretched-link" href="#"></a>

                              </li>

                              <!-- End Item -->



                              <!-- Item -->

                              <li class="list-group-item form-check-select">

                                <div class="row">

                                  <div class="col-auto">

                                    <div class="d-flex align-items-center">

                                      <div class="form-check">

                                        <input class="form-check-input" type="checkbox" value="" id="notificationCheck8">

                                        <label class="form-check-label" for="notificationCheck8"></label>

                                        <span class="form-check-stretched-bg"></span>

                                      </div>

                                      <div class="avatar avatar-sm avatar-dark avatar-circle">

                                        <span class="avatar-initials">HS</span>

                                      </div>

                                    </div>

                                  </div>

                                  <!-- End Col -->



                                  <div class="col ms-n2">

                                    <h5 class="mb-1">Htmlstream</h5>

                                    <p class="text-body fs-5">you earned a "Top endorsed" <i class="bi-patch-check-fill text-primary"></i> badge</p>

                                  </div>

                                  <!-- End Col -->



                                  <small class="col-auto text-muted text-cap">6dy</small>

                                  <!-- End Col -->

                                </div>

                                <!-- End Row -->



                                <a class="stretched-link" href="#"></a>

                              </li>

                              <!-- End Item -->



                              <!-- Item -->

                              <li class="list-group-item form-check-select">

                                <div class="row">

                                  <div class="col-auto">

                                    <div class="d-flex align-items-center">

                                      <div class="form-check">

                                        <input class="form-check-input" type="checkbox" value="" id="notificationCheck9">

                                        <label class="form-check-label" for="notificationCheck9"></label>

                                        <span class="form-check-stretched-bg"></span>

                                      </div>

                                      <div class="avatar avatar-sm avatar-circle">

                                        <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img8.jpg" alt="Image Description">

                                      </div>

                                    </div>

                                  </div>

                                  <!-- End Col -->



                                  <div class="col ms-n2">

                                    <h5 class="mb-1">Linda Bates</h5>

                                    <p class="text-body fs-5">Accepted your connection</p>

                                  </div>

                                  <!-- End Col -->



                                  <small class="col-auto text-muted text-cap">17dy</small>

                                  <!-- End Col -->

                                </div>

                                <!-- End Row -->



                                <a class="stretched-link" href="#"></a>

                              </li>

                              <!-- End Item -->



                              <!-- Item -->

                              <li class="list-group-item form-check-select">

                                <div class="row">

                                  <div class="col-auto">

                                    <div class="d-flex align-items-center">

                                      <div class="form-check">

                                        <input class="form-check-input" type="checkbox" value="" id="notificationCheck10">

                                        <label class="form-check-label" for="notificationCheck10"></label>

                                        <span class="form-check-stretched-bg"></span>

                                      </div>

                                      <div class="avatar avatar-sm avatar-soft-dark avatar-circle">

                                        <span class="avatar-initials">L</span>

                                      </div>

                                    </div>

                                  </div>

                                  <!-- End Col -->



                                  <div class="col ms-n2">

                                    <h5 class="mb-1">Lewis Clarke</h5>

                                    <p class="text-body fs-5">completed <i class="bi-journal-bookmark-fill text-primary"></i> FD-134 task</p>

                                  </div>

                                  <!-- End Col -->



                                  <small class="col-auto text-muted text-cap">2mts</small>

                                  <!-- End Col -->

                                </div>

                                <!-- End Row -->



                                <a class="stretched-link" href="#"></a>

                              </li>

                              <!-- End Item -->

                            </ul>

                            <!-- End List Group -->

                          </div>

                        </div>

                        <!-- End Tab Content -->

                      </div>

                      <!-- End Body -->



                      <!-- Card Footer -->

                      <a class="card-footer text-center" href="#">

                        View all notifications <i class="bi-chevron-right"></i>

                      </a>

                      <!-- End Card Footer -->

                    </div>

                  </div>

                  <!-- End Notification -->

                </li>



                <li class="nav-item d-none d-sm-inline-block">

                  <!-- Apps -->

                  <div class="dropdown">

                    <button type="button" class="btn btn-icon btn-ghost-secondary rounded-circle" id="navbarAppsDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-dropdown-animation>

                      <i class="bi-app-indicator"></i>

                    </button>



                    <div class="dropdown-menu dropdown-menu-end dropdown-card navbar-dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="navbarAppsDropdown" style="width: 25rem;">

                      <!-- Header -->

                      <div class="card-header">

                        <h4 class="card-title">Web apps &amp; services</h4>

                      </div>

                      <!-- End Header -->



                      <!-- Body -->

                      <div class="card-body card-body-height">

                        <a class="dropdown-item" href="#">

                          <div class="d-flex align-items-center">

                            <div class="flex-shrink-0">

                              <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/brands/atlassian-icon.svg" alt="Image Description">

                            </div>

                            <div class="flex-grow-1 text-truncate ms-3">

                              <h5 class="mb-0">Atlassian</h5>

                              <p class="card-text text-body">Security and control across Cloud</p>

                            </div>

                          </div>

                        </a>



                        <a class="dropdown-item" href="#">

                          <div class="d-flex align-items-center">

                            <div class="flex-shrink-0">

                              <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/brands/slack-icon.svg" alt="Image Description">

                            </div>

                            <div class="flex-grow-1 text-truncate ms-3">

                              <h5 class="mb-0">Slack <span class="badge bg-primary rounded-pill text-uppercase ms-1">Try</span></h5>

                              <p class="card-text text-body">Email collaboration software</p>

                            </div>

                          </div>

                        </a>



                        <a class="dropdown-item" href="#">

                          <div class="d-flex align-items-center">

                            <div class="flex-shrink-0">

                              <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/brands/google-webdev-icon.svg" alt="Image Description">

                            </div>

                            <div class="flex-grow-1 text-truncate ms-3">

                              <h5 class="mb-0">Google webdev</h5>

                              <p class="card-text text-body">Work involved in developing a website</p>

                            </div>

                          </div>

                        </a>



                        <a class="dropdown-item" href="#">

                          <div class="d-flex align-items-center">

                            <div class="flex-shrink-0">

                              <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/brands/grownapp-icon.svg" alt="Image Description">

                            </div>

                            <div class="flex-grow-1 text-truncate ms-3">

                              <h5 class="mb-0">grownapp</h5>

                              <p class="card-text text-body">The inbox for teams</p>

                            </div>

                          </div>

                        </a>



                        <a class="dropdown-item" href="#">

                          <div class="d-flex align-items-center">

                            <div class="flex-shrink-0">

                              <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/illustrations/review-rating-shield.svg" alt="Image Description">

                            </div>

                            <div class="flex-grow-1 text-truncate ms-3">

                              <h5 class="mb-0">HS Support</h5>

                              <p class="card-text text-body">Customer service and support</p>

                            </div>

                          </div>

                        </a>



                        <a class="dropdown-item" href="#">

                          <div class="d-flex align-items-center">

                            <div class="flex-shrink-0">

                              <div class="avatar avatar-sm avatar-soft-dark">

                                <span class="avatar-initials"><i class="bi-grid"></i></span>

                              </div>

                            </div>

                            <div class="flex-grow-1 text-truncate ms-3">

                              <h5 class="mb-0">More grown products</h5>

                              <p class="card-text text-body">Check out more HS products</p>

                            </div>

                          </div>

                        </a>

                      </div>

                      <!-- End Body -->



                      <!-- Footer -->

                      <a class="card-footer text-center" href="#">

                        View all apps <i class="bi-chevron-right"></i>

                      </a>

                      <!-- End Footer -->

                    </div>

                  </div>

                  <!-- End Apps -->

                </li>



                <li class="nav-item d-none d-sm-inline-block">

                  <!-- Activity -->

                  <button class="btn btn-ghost-secondary btn-icon rounded-circle" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasActivityStream" aria-controls="offcanvasActivityStream">

                    <i class="bi-x-diamond"></i>

                  </button>

                  <!-- Activity -->

                </li>



                <li class="nav-item">

                  <!-- Style Switcher -->

                  <div class="dropdown ">

                    <button type="button" class="btn btn-ghost-secondary btn-icon rounded-circle" id="selectThemeDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-dropdown-animation>



                    </button>



                    <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="selectThemeDropdown">

                      <a class="dropdown-item" href="#" data-icon="bi-moon-stars" data-value="auto">

                        <i class="bi-moon-stars me-2"></i>

                        <span class="text-truncate" title="Auto (system default)">Auto (system default)</span>

                      </a>

                      <a class="dropdown-item" href="#" data-icon="bi-brightness-high" data-value="default">

                        <i class="bi-brightness-high me-2"></i>

                        <span class="text-truncate" title="Default (light mode)">Default (light mode)</span>

                      </a>

                      <a class="dropdown-item active" href="#" data-icon="bi-moon" data-value="dark">

                        <i class="bi-moon me-2"></i>

                        <span class="text-truncate" title="Dark">Dark</span>

                      </a>

                    </div>

                  </div>



                  <!-- End Style Switcher -->

                </li>



                <li class="nav-item">

                  <!-- Account -->

                  <div class="dropdown">

                    <a class="navbar-dropdown-account-wrapper" href="javascript:;" id="accountNavbarDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside" data-bs-dropdown-animation>

                      <div class="avatar avatar-sm avatar-circle">

                        <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img6.jpg" alt="Image Description">

                        <span class="avatar-status avatar-sm-status avatar-status-success"></span>

                      </div>

                    </a>



                    <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless navbar-dropdown-account" aria-labelledby="accountNavbarDropdown" style="width: 16rem;">

                      <div class="dropdown-item-text">

                        <div class="d-flex align-items-center">

                          <div class="avatar avatar-sm avatar-circle">

                            <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img6.jpg" alt="Image Description">

                          </div>

                          <div class="flex-grow-1 ms-3">

                            <h5 class="mb-0">Mark Williams</h5>

                            <p class="card-text text-body">mark@site.com</p>

                          </div>

                        </div>

                      </div>



                      <div class="dropdown-divider"></div>



                      <!-- Dropdown -->

                      <div class="dropdown">

                        <a class="navbar-dropdown-submenu-item dropdown-item dropdown-toggle" href="javascript:;" id="navSubmenuPagesAccountDropdown1" data-bs-toggle="dropdown" aria-expanded="false">Set status</a>



                        <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless navbar-dropdown-sub-menu" aria-labelledby="navSubmenuPagesAccountDropdown1">

                          <a class="dropdown-item" href="#">

                            <span class="legend-indicator bg-success me-1"></span> Available

                          </a>

                          <a class="dropdown-item" href="#">

                            <span class="legend-indicator bg-danger me-1"></span> Busy

                          </a>

                          <a class="dropdown-item" href="#">

                            <span class="legend-indicator bg-warning me-1"></span> Away

                          </a>

                          <div class="dropdown-divider"></div>

                          <a class="dropdown-item" href="#"> Reset status

                          </a>

                        </div>

                      </div>

                      <!-- End Dropdown -->



                      <a class="dropdown-item" href="#">Profile &amp; account</a>

                      <a class="dropdown-item" href="#">Settings</a>



                      <div class="dropdown-divider"></div>



                      <a class="dropdown-item" href="#">

                        <div class="d-flex align-items-center">

                          <div class="flex-shrink-0">

                            <div class="avatar avatar-sm avatar-dark avatar-circle">

                              <span class="avatar-initials">HS</span>

                            </div>

                          </div>

                          <div class="flex-grow-1 ms-2">

                            <h5 class="mb-0">Htmlstream <span class="badge bg-primary rounded-pill text-uppercase ms-1">PRO</span></h5>

                            <span class="card-text">hs.example.com</span>

                          </div>

                        </div>

                      </a>



                      <div class="dropdown-divider"></div>



                      <!-- Dropdown -->

                      <div class="dropdown">

                        <a class="navbar-dropdown-submenu-item dropdown-item dropdown-toggle" href="javascript:;" id="navSubmenuPagesAccountDropdown2" data-bs-toggle="dropdown" aria-expanded="false">Customization</a>



                        <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless navbar-dropdown-sub-menu" aria-labelledby="navSubmenuPagesAccountDropdown2">

                          <a class="dropdown-item" href="#">

                            Invite people

                          </a>

                          <a class="dropdown-item" href="#">

                            Analytics

                            <i class="bi-box-arrow-in-up-right"></i>

                          </a>

                          <a class="dropdown-item" href="#">

                            Customize grown

                            <i class="bi-box-arrow-in-up-right"></i>

                          </a>

                        </div>

                      </div>

                      <!-- End Dropdown -->



                      <a class="dropdown-item" href="#">Manage team</a>



                      <div class="dropdown-divider"></div>



                      <a class="dropdown-item" href="#">Sign out</a>

                    </div>

                  </div>

                  <!-- End Account -->

                </li>

              </ul>

              <!-- End Navbar -->

            </div>

            <!-- End Secondary Content -->



            <!-- Toggler -->

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContainerNavDropdown" aria-controls="navbarContainerNavDropdown" aria-expanded="false" aria-label="Toggle navigation">

              <span class="navbar-toggler-default">

                <i class="bi-list"></i>

              </span>

              <span class="navbar-toggler-toggled">

                <i class="bi-x"></i>

              </span>

            </button>

            <!-- End Toggler -->



            <!-- Collapse -->

            <div class="collapse navbar-collapse" id="navbarContainerNavDropdown">

              <ul class="navbar-nav">

                <!-- Dashboards -->

                <li class="hs-has-sub-menu nav-item">

                  <a id="dashboardsMegaMenu" class="hs-mega-menu-invoker nav-link dropdown-toggle active" href="#" role="button"><i class="bi-house-door dropdown-item-icon"></i> Dashboards</a>



                  <!-- Mega Menu -->

                  <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="dashboardsMegaMenu" style="min-width: 14rem;">

                    <a class="dropdown-item active" href="index.html">Default</a>

                    <a class="dropdown-item " href="dashboard-alternative.html">Alternative</a>

                  </div>

                  <!-- End Mega Menu -->

                </li>

                <!-- End Dashboards -->



                <!-- Pages -->

                <li class="hs-has-sub-menu nav-item">

                  <a id="pagesMegaMenu" class="hs-mega-menu-invoker nav-link dropdown-toggle " href="#" role="button"><i class="bi-files-alt dropdown-item-icon"></i> Pages</a>



                  <!-- Mega Menu -->

                  <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="pagesMegaMenu" style="min-width: 14rem;">

                    <!-- Users -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="usersMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Users</a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="usersMegaMenu" style="min-width: 14rem;">

                        <a class="dropdown-item " href="users.html">Overview</a>

                        <a class="dropdown-item " href="users-leaderboard.html">Leaderboard</a>

                        <a class="dropdown-item " href="users-add-user.html">Add User <span class="badge bg-info rounded-pill ms-1">Hot</span></a>

                      </div>

                    </div>

                    <!-- End Users -->



                    <!-- User Profile -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="userProfileMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">User Profile <span class="badge bg-primary rounded-pill ms-1">5</span></a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="userProfileMegaMenu" style="min-width: 14rem;">

                        <a class="dropdown-item " href="user-profile.html">Profile</a>

                        <a class="dropdown-item " href="user-profile-teams.html">Teams</a>

                        <a class="dropdown-item " href="user-profile-projects.html">Projects</a>

                        <a class="dropdown-item " href="user-profile-connections.html">Connections</a>

                        <a class="dropdown-item " href="user-profile-my-profile.html">My Profile</a>

                      </div>

                    </div>

                    <!-- End User Profile -->



                    <!-- Account -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="accountMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Account</a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="accountMegaMenu" style="min-width: 14rem;">

                        <a class="dropdown-item " href="account-settings.html">Settings</a>

                        <a class="dropdown-item " href="account-billing.html">Billing</a>

                        <a class="dropdown-item " href="account-invoice.html">Invoice</a>

                      </div>

                    </div>

                    <!-- End Account -->



                    <!-- E-commerce -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="ecommerceMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">E-commerce</a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="ecommerceMegaMenu" style="min-width: 14rem;">

                        <a class="dropdown-item " href="ecommerce.html">Overview</a>



                        <!-- Products -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="productsMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Products</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="productsMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="ecommerce-products.html">Products</a>

                            <a class="dropdown-item " href="ecommerce-product-details.html">Product Details</a>

                            <a class="dropdown-item " href="ecommerce-add-product.html">Add Product</a>

                          </div>

                        </div>

                        <!-- End Products -->



                        <!-- Products -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="ordersMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Orders</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="ordersMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="ecommerce-orders.html">Orders</a>

                            <a class="dropdown-item " href="ecommerce-order-details.html">Order Details</a>

                          </div>

                        </div>

                        <!-- End Products -->



                        <!-- Customers -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="customersMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Customers</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="customersMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="ecommerce-customers.html">Customers</a>

                            <a class="dropdown-item " href="ecommerce-customer-details.html">Customer Details</a>

                            <a class="dropdown-item " href="ecommerce-add-customers.html">Add Customers</a>

                          </div>

                        </div>

                        <!-- End Customers -->



                        <a class="dropdown-item " href="ecommerce-referrals.html">Referrals</a>

                        <a class="dropdown-item " href="ecommerce-manage-reviews.html">Manage Reviews</a>

                        <a class="dropdown-item " href="ecommerce-checkout.html">Checkout</a>

                      </div>

                    </div>

                    <!-- End E-commerce -->



                    <!-- Projects -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="projectsMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Projects</a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="projectsMegaMenu" style="min-width: 14rem;">

                        <a class="dropdown-item " href="projects.html">Overview</a>

                        <a class="dropdown-item " href="projects-timeline.html">Timeline</a>

                      </div>

                    </div>

                    <!-- End Projects -->



                    <!-- Project -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="projectMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Project</a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="projectMegaMenu" style="min-width: 14rem;">

                        <a class="dropdown-item " href="project.html">Overview</a>

                        <a class="dropdown-item " href="project-files.html">Files</a>

                        <a class="dropdown-item " href="project-activity.html">Activity</a>

                        <a class="dropdown-item " href="project-teams.html">Teams</a>

                        <a class="dropdown-item " href="project-settings.html">Settings</a>

                      </div>

                    </div>

                    <!-- End Project -->



                    <!-- Authentication -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="authenticationMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Authentication</a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="authenticationMegaMenu" style="min-width: 14rem;">

                        <!-- Log In -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="loginMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Log In</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="loginMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="authentication-login-basic.html">Basic</a>

                            <a class="dropdown-item " href="authentication-login-cover.html">Cover</a>

                          </div>

                        </div>

                        <!-- End Log In -->



                        <!-- Sign Up -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="signupMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Sign Up</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="signupMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="authentication-signup-basic.html">Basic</a>

                            <a class="dropdown-item " href="authentication-signup-cover.html">Cover</a>

                          </div>

                        </div>

                        <!-- End Sign Up -->



                        <!-- Reset Password -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="resetPasswordMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Reset Password</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="resetPasswordMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="authentication-reset-password-basic.html">Basic</a>

                            <a class="dropdown-item " href="authentication-reset-password-cover.html">Cover</a>

                          </div>

                        </div>

                        <!-- End Reset Password -->



                        <!-- Email Verification -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="emailVerificationMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Email Verification</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="emailVerificationMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="authentication-email-verification-basic.html">Basic</a>

                            <a class="dropdown-item " href="authentication-email-verification-cover.html">Cover</a>

                          </div>

                        </div>

                        <!-- End Email Verification -->



                        <!-- 2-step Verification -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="2stepVerificationMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">2-step Verification</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="2stepVerificationMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="authentication-2-step-verification-basic.html">Basic</a>

                            <a class="dropdown-item " href="authentication-2-step-verification-cover.html">Cover</a>

                          </div>

                        </div>

                        <!-- End 2-step Verification -->



                        <a class="dropdown-item" href="javascript:;" data-bs-toggle="modal" data-bs-target="#welcomeMessageModal">Welcome Message</a>

                        <a class="dropdown-item " href="error-404.html">Error 404</a>

                        <a class="dropdown-item " href="error-500.html">Error 500</a>

                      </div>

                    </div>

                    <!-- End Authentication -->



                    <a class="dropdown-item " href="api-keys.html" data-placement="left">API Keys</a>

                    <a class="dropdown-item " href="welcome-page.html" data-placement="left">Welcome Page</a>

                    <a class="dropdown-item " href="landing.html" data-placement="left">Landing Page <span class="badge bg-info rounded-pill ms-1">New</span></a>

                  </div>

                  <!-- End Mega Menu -->

                </li>

                <!-- End Pages -->



                <!-- Apps -->

                <li class="hs-has-sub-menu nav-item">

                  <a id="appsMegaMenu" class="hs-mega-menu-invoker nav-link dropdown-toggle " href="#" role="button"><i class="bi-app-indicator dropdown-item-icon"></i> Apps</a>



                  <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="appsMegaMenu" style="min-width: 14rem;">

                    <a class="dropdown-item " href="apps-kanban.html">Kanban</a>

                    <a class="dropdown-item " href="apps-calendar.html">Calendar</a>

                    <a class="dropdown-item " href="apps-invoice-generator.html">Invoice Generator</a>

                    <a class="dropdown-item " href="apps-file-manager.html">File Manager</a>

                  </div>

                </li>

                <!-- End Apps -->



                <li class="nav-item">

                  <a class="nav-link " href="layouts/index.html">

                    <i class="bi-grid-1x2 dropdown-item-icon"></i> Layouts

                  </a>

                </li>



                <li class="nav-item">

                  <a class="nav-link " href="documentation/index.html" data-placement="left">

                    <i class="bi-book dropdown-item-icon"></i> Docs

                  </a>

                </li>

              </ul>



            </div>

            <!-- End Collapse -->

          </nav>

        </div>

      </header>



      <!-- End Single Header -->

    </div>

    <div class="js-build-layout-header-double">

      <!-- Double Header -->

      <header id="header" class="navbar navbar-expand-lg navbar-bordered navbar-spacer-y-0 flex-lg-column">

        <div class="navbar-dark w-100 bg-dark py-2">

          <div class="container">

            <div class="navbar-nav-wrap">

              <!-- Logo -->

              <a class="navbar-brand" href="index.html" aria-label="grown">

                <img class="navbar-brand-logo" src="http://grown.technoart.org/dashboard/assets/svg/logos/logo-white.svg" alt="Logo">

              </a>

              <!-- End Logo -->



              <!-- Content Start -->

              <div class="navbar-nav-wrap-content-start">

                <!-- Search Form -->

                <div class="d-none d-lg-block">

                  <div class="dropdown ms-2">

                    <!-- Input Group -->

                    <div class="d-none d-lg-block">

                      <div class="input-group input-group-merge input-group-borderless input-group-hover-light navbar-input-group">

                        <div class="input-group-prepend input-group-text">

                          <i class="bi-search"></i>

                        </div>



                        <input type="search" class="js-form-search form-control" placeholder="Search in Grown" aria-label="Search in grown" data-hs-form-search-options='{

                               "clearIcon": "#clearSearchResultsIcon",

                               "dropMenuElement": "#searchDropdownMenu",

                               "dropMenuOffset": 20,

                               "toggleIconOnFocus": true,

                               "activeClass": "focus"

                             }'>

                        <a class="input-group-append input-group-text" href="javascript:;">

                          <i id="clearSearchResultsIcon" class="bi-x-lg" style="display: none;"></i>

                        </a>

                      </div>

                    </div>



                    <button class="js-form-search js-form-search-mobile-toggle btn btn-ghost-secondary btn-icon rounded-circle d-lg-none" type="button" data-hs-form-search-options='{

                               "clearIcon": "#clearSearchResultsIcon",

                               "dropMenuElement": "#searchDropdownMenu",

                               "dropMenuOffset": 20,

                               "toggleIconOnFocus": true,

                               "activeClass": "focus"

                             }'>

                      <i class="bi-search"></i>

                    </button>

                    <!-- End Input Group -->



                    <!-- Card Search Content -->

                    <div id="searchDropdownMenu" class="hs-form-search-menu-content dropdown-menu dropdown-menu-form-search navbar-dropdown-menu-borderless">

                      <!-- Body -->

                      <div class="card-body-height">

                        <div class="d-lg-none">

                          <div class="input-group input-group-merge navbar-input-group mb-5">

                            <div class="input-group-prepend input-group-text">

                              <i class="bi-search"></i>

                            </div>



                            <input type="search" class="form-control" placeholder="Search in Grown" aria-label="Search in grown">

                            <a class="input-group-append input-group-text" href="javascript:;">

                              <i class="bi-x-lg"></i>

                            </a>

                          </div>

                        </div>



                        <span class="dropdown-header">Recent searches</span>



                        <div class="dropdown-item bg-transparent text-wrap">

                          <a class="btn btn-soft-dark btn-xs rounded-pill" href="index.html">

                            Gulp <i class="bi-search ms-1"></i>

                          </a>

                          <a class="btn btn-soft-dark btn-xs rounded-pill" href="index.html">

                            Notification panel <i class="bi-search ms-1"></i>

                          </a>

                        </div>



                        <div class="dropdown-divider"></div>



                        <span class="dropdown-header">Tutorials</span>



                        <a class="dropdown-item" href="index.html">

                          <div class="d-flex align-items-center">

                            <div class="flex-shrink-0">

                              <span class="icon icon-soft-dark icon-xs icon-circle">

                                <i class="bi-sliders"></i>

                              </span>

                            </div>



                            <div class="flex-grow-1 text-truncate ms-2">

                              <span>How to set up Gulp?</span>

                            </div>

                          </div>

                        </a>



                        <a class="dropdown-item" href="index.html">

                          <div class="d-flex align-items-center">

                            <div class="flex-shrink-0">

                              <span class="icon icon-soft-dark icon-xs icon-circle">

                                <i class="bi-paint-bucket"></i>

                              </span>

                            </div>



                            <div class="flex-grow-1 text-truncate ms-2">

                              <span>How to change theme color?</span>

                            </div>

                          </div>

                        </a>



                        <div class="dropdown-divider"></div>



                        <span class="dropdown-header">Members</span>



                        <a class="dropdown-item" href="index.html">

                          <div class="d-flex align-items-center">

                            <div class="flex-shrink-0">

                              <img class="avatar avatar-xs avatar-circle" src="http://grown.technoart.org/dashboard/assets/img/160x160/img10.jpg" alt="Image Description">

                            </div>

                            <div class="flex-grow-1 text-truncate ms-2">

                              <span>Amanda Harvey <i class="tio-verified text-primary" data-toggle="tooltip" data-placement="top" title="Top endorsed"></i></span>

                            </div>

                          </div>

                        </a>



                        <a class="dropdown-item" href="index.html">

                          <div class="d-flex align-items-center">

                            <div class="flex-shrink-0">

                              <img class="avatar avatar-xs avatar-circle" src="http://grown.technoart.org/dashboard/assets/img/160x160/img3.jpg" alt="Image Description">

                            </div>

                            <div class="flex-grow-1 text-truncate ms-2">

                              <span>David Harrison</span>

                            </div>

                          </div>

                        </a>



                        <a class="dropdown-item" href="index.html">

                          <div class="d-flex align-items-center">

                            <div class="flex-shrink-0">

                              <div class="avatar avatar-xs avatar-soft-info avatar-circle">

                                <span class="avatar-initials">A</span>

                              </div>

                            </div>

                            <div class="flex-grow-1 text-truncate ms-2">

                              <span>Anne Richard</span>

                            </div>

                          </div>

                        </a>

                      </div>

                      <!-- End Body -->



                      <!-- Footer -->

                      <a class="card-footer text-center" href="index.html">

                        See all results <i class="bi-chevron-right small"></i>

                      </a>

                      <!-- End Footer -->

                    </div>

                    <!-- End Card Search Content -->



                  </div>



                </div>

                <!-- End Search Form -->

              </div>

              <!-- End Content Start -->



              <!-- Content End -->

              <div class="navbar-nav-wrap-content-end">

                <!-- Navbar -->

                <ul class="navbar-nav">

                  <li class="nav-item d-none d-md-inline-block">

                    <!-- Notification -->

                    <div class="dropdown">

                      <button type="button" class="btn btn-ghost-light btn-icon rounded-circle" id="navbarNotificationsDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside" data-bs-dropdown-animation>

                        <i class="bi-bell"></i>

                        <span class="btn-status btn-sm-status btn-status-danger"></span>

                      </button>



                      <div class="dropdown-menu dropdown-menu-end dropdown-card navbar-dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="navbarNotificationsDropdown" style="width: 25rem;">

                        <!-- Header -->

                        <div class="card-header card-header-content-between">

                          <h4 class="card-title mb-0">Notifications</h4>



                          <!-- Unfold -->

                          <div class="dropdown">

                            <button type="button" class="btn btn-icon btn-sm btn-ghost-secondary rounded-circle" id="navbarNotificationsDropdownSettings" data-bs-toggle="dropdown" aria-expanded="false">

                              <i class="bi-three-dots-vertical"></i>

                            </button>



                            <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu-borderless" aria-labelledby="navbarNotificationsDropdownSettings">

                              <span class="dropdown-header">Settings</span>

                              <a class="dropdown-item" href="#">

                                <i class="bi-archive dropdown-item-icon"></i> Archive all

                              </a>

                              <a class="dropdown-item" href="#">

                                <i class="bi-check2-all dropdown-item-icon"></i> Mark all as read

                              </a>

                              <a class="dropdown-item" href="#">

                                <i class="bi-toggle-off dropdown-item-icon"></i> Disable notifications

                              </a>

                              <a class="dropdown-item" href="#">

                                <i class="bi-gift dropdown-item-icon"></i> What's new?

                              </a>

                              <div class="dropdown-divider"></div>

                              <span class="dropdown-header">Feedback</span>

                              <a class="dropdown-item" href="#">

                                <i class="bi-chat-left-dots dropdown-item-icon"></i> Report

                              </a>

                            </div>

                          </div>

                          <!-- End Unfold -->

                        </div>

                        <!-- End Header -->



                        <!-- Nav -->

                        <ul class="nav nav-tabs nav-justified" id="notificationTab" role="tablist">

                          <li class="nav-item">

                            <a class="nav-link active" href="#notificationNavOne" id="notificationNavOne-tab" data-bs-toggle="tab" data-bs-target="#notificationNavOne" role="tab" aria-controls="notificationNavOne" aria-selected="true">Messages (3)</a>

                          </li>

                          <li class="nav-item">

                            <a class="nav-link" href="#notificationNavTwo" id="notificationNavTwo-tab" data-bs-toggle="tab" data-bs-target="#notificationNavTwo" role="tab" aria-controls="notificationNavTwo" aria-selected="false">Archived</a>

                          </li>

                        </ul>

                        <!-- End Nav -->



                        <!-- Body -->

                        <div class="card-body-height">

                          <!-- Tab Content -->

                          <div class="tab-content" id="notificationTabContent">

                            <div class="tab-pane fade show active" id="notificationNavOne" role="tabpanel" aria-labelledby="notificationNavOne-tab">

                              <!-- List Group -->

                              <ul class="list-group list-group-flush navbar-card-list-group">

                                <!-- Item -->

                                <li class="list-group-item form-check-select">

                                  <div class="row">

                                    <div class="col-auto">

                                      <div class="d-flex align-items-center">

                                        <div class="form-check">

                                          <input class="form-check-input" type="checkbox" value="" id="notificationCheck1" checked>

                                          <label class="form-check-label" for="notificationCheck1"></label>

                                          <span class="form-check-stretched-bg"></span>

                                        </div>

                                        <img class="avatar avatar-sm avatar-circle" src="http://grown.technoart.org/dashboard/assets/img/160x160/img3.jpg" alt="Image Description">

                                      </div>

                                    </div>

                                    <!-- End Col -->



                                    <div class="col ms-n2">

                                      <h5 class="mb-1">Brian Warner</h5>

                                      <p class="text-body fs-5">changed an issue from "In Progress" to <span class="badge bg-success">Review</span></p>

                                    </div>

                                    <!-- End Col -->



                                    <small class="col-auto text-muted text-cap">2hr</small>

                                    <!-- End Col -->

                                  </div>

                                  <!-- End Row -->



                                  <a class="stretched-link" href="#"></a>

                                </li>

                                <!-- End Item -->



                                <!-- Item -->

                                <li class="list-group-item form-check-select">

                                  <div class="row">

                                    <div class="col-auto">

                                      <div class="d-flex align-items-center">

                                        <div class="form-check">

                                          <input class="form-check-input" type="checkbox" value="" id="notificationCheck2" checked>

                                          <label class="form-check-label" for="notificationCheck2"></label>

                                          <span class="form-check-stretched-bg"></span>

                                        </div>

                                        <div class="avatar avatar-sm avatar-soft-dark avatar-circle">

                                          <span class="avatar-initials">K</span>

                                        </div>

                                      </div>

                                    </div>

                                    <!-- End Col -->



                                    <div class="col ms-n2">

                                      <h5 class="mb-1">Klara Hampton</h5>

                                      <p class="text-body fs-5">mentioned you in a comment</p>

                                      <blockquote class="blockquote blockquote-sm">

                                        Nice work, love! You really nailed it. Keep it up!

                                      </blockquote>

                                    </div>

                                    <!-- End Col -->



                                    <small class="col-auto text-muted text-cap">10hr</small>

                                    <!-- End Col -->

                                  </div>

                                  <!-- End Row -->



                                  <a class="stretched-link" href="#"></a>

                                </li>

                                <!-- End Item -->



                                <!-- Item -->

                                <li class="list-group-item form-check-select">

                                  <div class="row">

                                    <div class="col-auto">

                                      <div class="d-flex align-items-center">

                                        <div class="form-check">

                                          <input class="form-check-input" type="checkbox" value="" id="notificationCheck3" checked>

                                          <label class="form-check-label" for="notificationCheck3"></label>

                                          <span class="form-check-stretched-bg"></span>

                                        </div>

                                        <div class="avatar avatar-sm avatar-circle">

                                          <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img10.jpg" alt="Image Description">

                                        </div>

                                      </div>

                                    </div>

                                    <!-- End Col -->



                                    <div class="col ms-n2">

                                      <h5 class="mb-1">Ruby Walter</h5>

                                      <p class="text-body fs-5">joined the Slack group HS Team</p>

                                    </div>

                                    <!-- End Col -->



                                    <small class="col-auto text-muted text-cap">3dy</small>

                                    <!-- End Col -->

                                  </div>

                                  <!-- End Row -->



                                  <a class="stretched-link" href="#"></a>

                                </li>

                                <!-- End Item -->



                                <!-- Item -->

                                <li class="list-group-item form-check-select">

                                  <div class="row">

                                    <div class="col-auto">

                                      <div class="d-flex align-items-center">

                                        <div class="form-check">

                                          <input class="form-check-input" type="checkbox" value="" id="notificationCheck4">

                                          <label class="form-check-label" for="notificationCheck4"></label>

                                          <span class="form-check-stretched-bg"></span>

                                        </div>

                                        <div class="avatar avatar-sm avatar-circle">

                                          <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/svg/brands/google-icon.svg" alt="Image Description">

                                        </div>

                                      </div>

                                    </div>

                                    <!-- End Col -->



                                    <div class="col ms-n2">

                                      <h5 class="mb-1">from Google</h5>

                                      <p class="text-body fs-5">Start using forms to capture the information of prospects visiting your Google website</p>

                                    </div>

                                    <!-- End Col -->



                                    <small class="col-auto text-muted text-cap">17dy</small>

                                    <!-- End Col -->

                                  </div>

                                  <!-- End Row -->



                                  <a class="stretched-link" href="#"></a>

                                </li>

                                <!-- End Item -->



                                <!-- Item -->

                                <li class="list-group-item form-check-select">

                                  <div class="row">

                                    <div class="col-auto">

                                      <div class="d-flex align-items-center">

                                        <div class="form-check">

                                          <input class="form-check-input" type="checkbox" value="" id="notificationCheck5">

                                          <label class="form-check-label" for="notificationCheck5"></label>

                                          <span class="form-check-stretched-bg"></span>

                                        </div>

                                        <div class="avatar avatar-sm avatar-circle">

                                          <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img7.jpg" alt="Image Description">

                                        </div>

                                      </div>

                                    </div>

                                    <!-- End Col -->



                                    <div class="col ms-n2">

                                      <h5 class="mb-1">Sara Villar</h5>

                                      <p class="text-body fs-5">completed <i class="bi-journal-bookmark-fill text-primary"></i> FD-7 task</p>

                                    </div>

                                    <!-- End Col -->



                                    <small class="col-auto text-muted text-cap">2mn</small>

                                    <!-- End Col -->

                                  </div>

                                  <!-- End Row -->



                                  <a class="stretched-link" href="#"></a>

                                </li>

                                <!-- End Item -->

                              </ul>

                              <!-- End List Group -->

                            </div>



                            <div class="tab-pane fade" id="notificationNavTwo" role="tabpanel" aria-labelledby="notificationNavTwo-tab">

                              <!-- List Group -->

                              <ul class="list-group list-group-flush navbar-card-list-group">

                                <!-- Item -->

                                <li class="list-group-item form-check-select">

                                  <div class="row">

                                    <div class="col-auto">

                                      <div class="d-flex align-items-center">

                                        <div class="form-check">

                                          <input class="form-check-input" type="checkbox" value="" id="notificationCheck6">

                                          <label class="form-check-label" for="notificationCheck6"></label>

                                          <span class="form-check-stretched-bg"></span>

                                        </div>

                                        <div class="avatar avatar-sm avatar-soft-dark avatar-circle">

                                          <span class="avatar-initials">A</span>

                                        </div>

                                      </div>

                                    </div>

                                    <!-- End Col -->



                                    <div class="col ms-n2">

                                      <h5 class="mb-1">Anne Richard</h5>

                                      <p class="text-body fs-5">accepted your invitation to join Notion</p>

                                    </div>

                                    <!-- End Col -->



                                    <small class="col-auto text-muted text-cap">1dy</small>

                                    <!-- End Col -->

                                  </div>

                                  <!-- End Row -->



                                  <a class="stretched-link" href="#"></a>

                                </li>

                                <!-- End Item -->



                                <!-- Item -->

                                <li class="list-group-item form-check-select">

                                  <div class="row">

                                    <div class="col-auto">

                                      <div class="d-flex align-items-center">

                                        <div class="form-check">

                                          <input class="form-check-input" type="checkbox" value="" id="notificationCheck7">

                                          <label class="form-check-label" for="notificationCheck7"></label>

                                          <span class="form-check-stretched-bg"></span>

                                        </div>

                                        <div class="avatar avatar-sm avatar-circle">

                                          <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img5.jpg" alt="Image Description">

                                        </div>

                                      </div>

                                    </div>

                                    <!-- End Col -->



                                    <div class="col ms-n2">

                                      <h5 class="mb-1">Finch Hoot</h5>

                                      <p class="text-body fs-5">left Slack group HS projects</p>

                                    </div>

                                    <!-- End Col -->



                                    <small class="col-auto text-muted text-cap">1dy</small>

                                    <!-- End Col -->

                                  </div>

                                  <!-- End Row -->



                                  <a class="stretched-link" href="#"></a>

                                </li>

                                <!-- End Item -->



                                <!-- Item -->

                                <li class="list-group-item form-check-select">

                                  <div class="row">

                                    <div class="col-auto">

                                      <div class="d-flex align-items-center">

                                        <div class="form-check">

                                          <input class="form-check-input" type="checkbox" value="" id="notificationCheck8">

                                          <label class="form-check-label" for="notificationCheck8"></label>

                                          <span class="form-check-stretched-bg"></span>

                                        </div>

                                        <div class="avatar avatar-sm avatar-dark avatar-circle">

                                          <span class="avatar-initials">HS</span>

                                        </div>

                                      </div>

                                    </div>

                                    <!-- End Col -->



                                    <div class="col ms-n2">

                                      <h5 class="mb-1">Htmlstream</h5>

                                      <p class="text-body fs-5">you earned a "Top endorsed" <i class="bi-patch-check-fill text-primary"></i> badge</p>

                                    </div>

                                    <!-- End Col -->



                                    <small class="col-auto text-muted text-cap">6dy</small>

                                    <!-- End Col -->

                                  </div>

                                  <!-- End Row -->



                                  <a class="stretched-link" href="#"></a>

                                </li>

                                <!-- End Item -->



                                <!-- Item -->

                                <li class="list-group-item form-check-select">

                                  <div class="row">

                                    <div class="col-auto">

                                      <div class="d-flex align-items-center">

                                        <div class="form-check">

                                          <input class="form-check-input" type="checkbox" value="" id="notificationCheck9">

                                          <label class="form-check-label" for="notificationCheck9"></label>

                                          <span class="form-check-stretched-bg"></span>

                                        </div>

                                        <div class="avatar avatar-sm avatar-circle">

                                          <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img8.jpg" alt="Image Description">

                                        </div>

                                      </div>

                                    </div>

                                    <!-- End Col -->



                                    <div class="col ms-n2">

                                      <h5 class="mb-1">Linda Bates</h5>

                                      <p class="text-body fs-5">Accepted your connection</p>

                                    </div>

                                    <!-- End Col -->



                                    <small class="col-auto text-muted text-cap">17dy</small>

                                    <!-- End Col -->

                                  </div>

                                  <!-- End Row -->



                                  <a class="stretched-link" href="#"></a>

                                </li>

                                <!-- End Item -->



                                <!-- Item -->

                                <li class="list-group-item form-check-select">

                                  <div class="row">

                                    <div class="col-auto">

                                      <div class="d-flex align-items-center">

                                        <div class="form-check">

                                          <input class="form-check-input" type="checkbox" value="" id="notificationCheck10">

                                          <label class="form-check-label" for="notificationCheck10"></label>

                                          <span class="form-check-stretched-bg"></span>

                                        </div>

                                        <div class="avatar avatar-sm avatar-soft-dark avatar-circle">

                                          <span class="avatar-initials">L</span>

                                        </div>

                                      </div>

                                    </div>

                                    <!-- End Col -->



                                    <div class="col ms-n2">

                                      <h5 class="mb-1">Lewis Clarke</h5>

                                      <p class="text-body fs-5">completed <i class="bi-journal-bookmark-fill text-primary"></i> FD-134 task</p>

                                    </div>

                                    <!-- End Col -->



                                    <small class="col-auto text-muted text-cap">2mts</small>

                                    <!-- End Col -->

                                  </div>

                                  <!-- End Row -->



                                  <a class="stretched-link" href="#"></a>

                                </li>

                                <!-- End Item -->

                              </ul>

                              <!-- End List Group -->

                            </div>

                          </div>

                          <!-- End Tab Content -->

                        </div>

                        <!-- End Body -->



                        <!-- Card Footer -->

                        <a class="card-footer text-center" href="#">

                          View all notifications <i class="bi-chevron-right"></i>

                        </a>

                        <!-- End Card Footer -->

                      </div>

                    </div>

                    <!-- End Notification -->

                  </li>



                  <li class="nav-item d-none d-sm-inline-block">

                    <!-- Apps -->

                    <div class="dropdown">

                      <button type="button" class="btn btn-icon btn-ghost-light rounded-circle" id="navbarAppsDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-dropdown-animation>

                        <i class="bi-app-indicator"></i>

                      </button>



                      <div class="dropdown-menu dropdown-menu-end dropdown-card navbar-dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="navbarAppsDropdown" style="width: 25rem;">

                        <!-- Header -->

                        <div class="card-header">

                          <h4 class="card-title">Web apps &amp; services</h4>

                        </div>

                        <!-- End Header -->



                        <!-- Body -->

                        <div class="card-body card-body-height">

                          <a class="dropdown-item" href="#">

                            <div class="d-flex align-items-center">

                              <div class="flex-shrink-0">

                                <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/brands/atlassian-icon.svg" alt="Image Description">

                              </div>

                              <div class="flex-grow-1 text-truncate ms-3">

                                <h5 class="mb-0">Atlassian</h5>

                                <p class="card-text text-body">Security and control across Cloud</p>

                              </div>

                            </div>

                          </a>



                          <a class="dropdown-item" href="#">

                            <div class="d-flex align-items-center">

                              <div class="flex-shrink-0">

                                <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/brands/slack-icon.svg" alt="Image Description">

                              </div>

                              <div class="flex-grow-1 text-truncate ms-3">

                                <h5 class="mb-0">Slack <span class="badge bg-primary rounded-pill text-uppercase ms-1">Try</span></h5>

                                <p class="card-text text-body">Email collaboration software</p>

                              </div>

                            </div>

                          </a>



                          <a class="dropdown-item" href="#">

                            <div class="d-flex align-items-center">

                              <div class="flex-shrink-0">

                                <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/brands/google-webdev-icon.svg" alt="Image Description">

                              </div>

                              <div class="flex-grow-1 text-truncate ms-3">

                                <h5 class="mb-0">Google webdev</h5>

                                <p class="card-text text-body">Work involved in developing a website</p>

                              </div>

                            </div>

                          </a>



                          <a class="dropdown-item" href="#">

                            <div class="d-flex align-items-center">

                              <div class="flex-shrink-0">

                                <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/brands/grownapp-icon.svg" alt="Image Description">

                              </div>

                              <div class="flex-grow-1 text-truncate ms-3">

                                <h5 class="mb-0">grownapp</h5>

                                <p class="card-text text-body">The inbox for teams</p>

                              </div>

                            </div>

                          </a>



                          <a class="dropdown-item" href="#">

                            <div class="d-flex align-items-center">

                              <div class="flex-shrink-0">

                                <img class="avatar avatar-xs avatar-4x3" src="http://grown.technoart.org/dashboard/assets/svg/illustrations/review-rating-shield.svg" alt="Image Description">

                              </div>

                              <div class="flex-grow-1 text-truncate ms-3">

                                <h5 class="mb-0">HS Support</h5>

                                <p class="card-text text-body">Customer service and support</p>

                              </div>

                            </div>

                          </a>



                          <a class="dropdown-item" href="#">

                            <div class="d-flex align-items-center">

                              <div class="flex-shrink-0">

                                <div class="avatar avatar-sm avatar-soft-dark">

                                  <span class="avatar-initials"><i class="bi-grid"></i></span>

                                </div>

                              </div>

                              <div class="flex-grow-1 text-truncate ms-3">

                                <h5 class="mb-0">More grown products</h5>

                                <p class="card-text text-body">Check out more HS products</p>

                              </div>

                            </div>

                          </a>

                        </div>

                        <!-- End Body -->



                        <!-- Footer -->

                        <a class="card-footer text-center" href="#">

                          View all apps <i class="bi-chevron-right"></i>

                        </a>

                        <!-- End Footer -->

                      </div>

                    </div>

                    <!-- End Apps -->

                  </li>



                  <li class="nav-item d-none d-sm-inline-block">

                    <!-- Activity -->

                    <button class="btn btn-ghost-light btn-icon rounded-circle" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasActivityStream" aria-controls="offcanvasActivityStream">

                      <i class="bi-x-diamond"></i>

                    </button>

                    <!-- Activity -->

                  </li>



                  <li class="nav-item">

                    <!-- Style Switcher -->

                    <div class="dropdown ">

                      <button type="button" class="btn btn-ghost-light btn-icon rounded-circle" id="selectThemeDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-dropdown-animation>



                      </button>



                      <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="selectThemeDropdown">

                        <a class="dropdown-item" href="#" data-icon="bi-moon-stars" data-value="auto">

                          <i class="bi-moon-stars me-2"></i>

                          <span class="text-truncate" title="Auto (system default)">Auto (system default)</span>

                        </a>

                        <a class="dropdown-item" href="#" data-icon="bi-brightness-high" data-value="default">

                          <i class="bi-brightness-high me-2"></i>

                          <span class="text-truncate" title="Default (light mode)">Default (light mode)</span>

                        </a>

                        <a class="dropdown-item active" href="#" data-icon="bi-moon" data-value="dark">

                          <i class="bi-moon me-2"></i>

                          <span class="text-truncate" title="Dark">Dark</span>

                        </a>

                      </div>

                    </div>



                    <!-- End Style Switcher -->

                  </li>



                  <li class="nav-item">

                    <!-- Account -->

                    <div class="dropdown">

                      <a class="navbar-dropdown-account-wrapper" href="javascript:;" id="accountNavbarDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside" data-bs-dropdown-animation>

                        <div class="avatar avatar-sm avatar-circle">

                          <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img6.jpg" alt="Image Description">

                          <span class="avatar-status avatar-sm-status avatar-status-success"></span>

                        </div>

                      </a>



                      <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless navbar-dropdown-account" aria-labelledby="accountNavbarDropdown" style="width: 16rem;">

                        <div class="dropdown-item-text">

                          <div class="d-flex align-items-center">

                            <div class="avatar avatar-sm avatar-circle">

                              <img class="avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img6.jpg" alt="Image Description">

                            </div>

                            <div class="flex-grow-1 ms-3">

                              <h5 class="mb-0">Mark Williams</h5>

                              <p class="card-text text-body">mark@site.com</p>

                            </div>

                          </div>

                        </div>



                        <div class="dropdown-divider"></div>



                        <!-- Dropdown -->

                        <div class="dropdown">

                          <a class="navbar-dropdown-submenu-item dropdown-item dropdown-toggle" href="javascript:;" id="navSubmenuPagesAccountDropdown1" data-bs-toggle="dropdown" aria-expanded="false">Set status</a>



                          <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless navbar-dropdown-sub-menu" aria-labelledby="navSubmenuPagesAccountDropdown1">

                            <a class="dropdown-item" href="#">

                              <span class="legend-indicator bg-success me-1"></span> Available

                            </a>

                            <a class="dropdown-item" href="#">

                              <span class="legend-indicator bg-danger me-1"></span> Busy

                            </a>

                            <a class="dropdown-item" href="#">

                              <span class="legend-indicator bg-warning me-1"></span> Away

                            </a>

                            <div class="dropdown-divider"></div>

                            <a class="dropdown-item" href="#"> Reset status

                            </a>

                          </div>

                        </div>

                        <!-- End Dropdown -->



                        <a class="dropdown-item" href="#">Profile &amp; account</a>

                        <a class="dropdown-item" href="#">Settings</a>



                        <div class="dropdown-divider"></div>



                        <a class="dropdown-item" href="#">

                          <div class="d-flex align-items-center">

                            <div class="flex-shrink-0">

                              <div class="avatar avatar-sm avatar-dark avatar-circle">

                                <span class="avatar-initials">HS</span>

                              </div>

                            </div>

                            <div class="flex-grow-1 ms-2">

                              <h5 class="mb-0">Htmlstream <span class="badge bg-primary rounded-pill text-uppercase ms-1">PRO</span></h5>

                              <span class="card-text">hs.example.com</span>

                            </div>

                          </div>

                        </a>



                        <div class="dropdown-divider"></div>



                        <!-- Dropdown -->

                        <div class="dropdown">

                          <a class="navbar-dropdown-submenu-item dropdown-item dropdown-toggle" href="javascript:;" id="navSubmenuPagesAccountDropdown2" data-bs-toggle="dropdown" aria-expanded="false">Customization</a>



                          <div class="dropdown-menu dropdown-menu-end navbar-dropdown-menu navbar-dropdown-menu-borderless navbar-dropdown-sub-menu" aria-labelledby="navSubmenuPagesAccountDropdown2">

                            <a class="dropdown-item" href="#">

                              Invite people

                            </a>

                            <a class="dropdown-item" href="#">

                              Analytics

                              <i class="bi-box-arrow-in-up-right"></i>

                            </a>

                            <a class="dropdown-item" href="#">

                              Customize grown

                              <i class="bi-box-arrow-in-up-right"></i>

                            </a>

                          </div>

                        </div>

                        <!-- End Dropdown -->



                        <a class="dropdown-item" href="#">Manage team</a>



                        <div class="dropdown-divider"></div>



                        <a class="dropdown-item" href="#">Sign out</a>

                      </div>

                    </div>

                    <!-- End Account -->

                  </li>



                  <li class="nav-item">

                    <!-- Toggler -->

                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarDoubleLineContainerNavDropdown" aria-controls="navbarDoubleLineContainerNavDropdown" aria-expanded="false" aria-label="Toggle navigation">

                      <span class="navbar-toggler-default">

                        <i class="bi-list"></i>

                      </span>

                      <span class="navbar-toggler-toggled">

                        <i class="bi-x"></i>

                      </span>

                    </button>

                    <!-- End Toggler -->

                  </li>

                </ul>

                <!-- End Navbar -->

              </div>

              <!-- End Content End -->

            </div>

          </div>

        </div>



        <div class="container">

          <nav class="js-mega-menu flex-grow-1">

            <!-- Collapse -->

            <div class="collapse navbar-collapse" id="navbarDoubleLineContainerNavDropdown">

              <ul class="navbar-nav">

                <!-- Dashboards -->

                <li class="hs-has-sub-menu nav-item">

                  <a id="dashboardsMegaMenu" class="hs-mega-menu-invoker nav-link dropdown-toggle active" href="#" role="button"><i class="bi-house-door dropdown-item-icon"></i> Dashboards</a>



                  <!-- Mega Menu -->

                  <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="dashboardsMegaMenu" style="min-width: 14rem;">

                    <a class="dropdown-item active" href="index.html">Default</a>

                    <a class="dropdown-item " href="dashboard-alternative.html">Alternative</a>

                  </div>

                  <!-- End Mega Menu -->

                </li>

                <!-- End Dashboards -->



                <!-- Pages -->

                <li class="hs-has-sub-menu nav-item">

                  <a id="pagesMegaMenu" class="hs-mega-menu-invoker nav-link dropdown-toggle " href="#" role="button"><i class="bi-files-alt dropdown-item-icon"></i> Pages</a>



                  <!-- Mega Menu -->

                  <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="pagesMegaMenu" style="min-width: 14rem;">

                    <!-- Users -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="usersMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Users</a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="usersMegaMenu" style="min-width: 14rem;">

                        <a class="dropdown-item " href="users.html">Overview</a>

                        <a class="dropdown-item " href="users-leaderboard.html">Leaderboard</a>

                        <a class="dropdown-item " href="users-add-user.html">Add User <span class="badge bg-info rounded-pill ms-1">Hot</span></a>

                      </div>

                    </div>

                    <!-- End Users -->



                    <!-- User Profile -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="userProfileMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">User Profile <span class="badge bg-primary rounded-pill ms-1">5</span></a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="userProfileMegaMenu" style="min-width: 14rem;">

                        <a class="dropdown-item " href="user-profile.html">Profile</a>

                        <a class="dropdown-item " href="user-profile-teams.html">Teams</a>

                        <a class="dropdown-item " href="user-profile-projects.html">Projects</a>

                        <a class="dropdown-item " href="user-profile-connections.html">Connections</a>

                        <a class="dropdown-item " href="user-profile-my-profile.html">My Profile</a>

                      </div>

                    </div>

                    <!-- End User Profile -->



                    <!-- Account -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="accountMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Account</a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="accountMegaMenu" style="min-width: 14rem;">

                        <a class="dropdown-item " href="account-settings.html">Settings</a>

                        <a class="dropdown-item " href="account-billing.html">Billing</a>

                        <a class="dropdown-item " href="account-invoice.html">Invoice</a>

                      </div>

                    </div>

                    <!-- End Account -->



                    <!-- E-commerce -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="ecommerceMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">E-commerce</a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="ecommerceMegaMenu" style="min-width: 14rem;">

                        <a class="dropdown-item " href="ecommerce.html">Overview</a>



                        <!-- Products -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="productsMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Products</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="productsMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="ecommerce-products.html">Products</a>

                            <a class="dropdown-item " href="ecommerce-product-details.html">Product Details</a>

                            <a class="dropdown-item " href="ecommerce-add-product.html">Add Product</a>

                          </div>

                        </div>

                        <!-- End Products -->



                        <!-- Products -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="ordersMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Orders</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="ordersMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="ecommerce-orders.html">Orders</a>

                            <a class="dropdown-item " href="ecommerce-order-details.html">Order Details</a>

                          </div>

                        </div>

                        <!-- End Products -->



                        <!-- Customers -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="customersMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Customers</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="customersMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="ecommerce-customers.html">Customers</a>

                            <a class="dropdown-item " href="ecommerce-customer-details.html">Customer Details</a>

                            <a class="dropdown-item " href="ecommerce-add-customers.html">Add Customers</a>

                          </div>

                        </div>

                        <!-- End Customers -->



                        <a class="dropdown-item " href="ecommerce-referrals.html">Referrals</a>

                        <a class="dropdown-item " href="ecommerce-manage-reviews.html">Manage Reviews</a>

                        <a class="dropdown-item " href="ecommerce-checkout.html">Checkout</a>

                      </div>

                    </div>

                    <!-- End E-commerce -->



                    <!-- Projects -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="projectsMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Projects</a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="projectsMegaMenu" style="min-width: 14rem;">

                        <a class="dropdown-item " href="projects.html">Overview</a>

                        <a class="dropdown-item " href="projects-timeline.html">Timeline</a>

                      </div>

                    </div>

                    <!-- End Projects -->



                    <!-- Project -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="projectMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Project</a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="projectMegaMenu" style="min-width: 14rem;">

                        <a class="dropdown-item " href="project.html">Overview</a>

                        <a class="dropdown-item " href="project-files.html">Files</a>

                        <a class="dropdown-item " href="project-activity.html">Activity</a>

                        <a class="dropdown-item " href="project-teams.html">Teams</a>

                        <a class="dropdown-item " href="project-settings.html">Settings</a>

                      </div>

                    </div>

                    <!-- End Project -->



                    <!-- Authentication -->

                    <div class="hs-has-sub-menu nav-item">

                      <a id="authenticationMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Authentication</a>



                      <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="authenticationMegaMenu" style="min-width: 14rem;">

                        <!-- Log In -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="loginMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Log In</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="loginMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="authentication-login-basic.html">Basic</a>

                            <a class="dropdown-item " href="authentication-login-cover.html">Cover</a>

                          </div>

                        </div>

                        <!-- End Log In -->



                        <!-- Sign Up -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="signupMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Sign Up</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="signupMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="authentication-signup-basic.html">Basic</a>

                            <a class="dropdown-item " href="authentication-signup-cover.html">Cover</a>

                          </div>

                        </div>

                        <!-- End Sign Up -->



                        <!-- Reset Password -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="resetPasswordMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Reset Password</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="resetPasswordMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="authentication-reset-password-basic.html">Basic</a>

                            <a class="dropdown-item " href="authentication-reset-password-cover.html">Cover</a>

                          </div>

                        </div>

                        <!-- End Reset Password -->



                        <!-- Email Verification -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="emailVerificationMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">Email Verification</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="emailVerificationMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="authentication-email-verification-basic.html">Basic</a>

                            <a class="dropdown-item " href="authentication-email-verification-cover.html">Cover</a>

                          </div>

                        </div>

                        <!-- End Email Verification -->



                        <!-- 2-step Verification -->

                        <div class="hs-has-sub-menu nav-item">

                          <a id="2stepVerificationMegaMenu" class="hs-mega-menu-invoker dropdown-item dropdown-toggle " href="#" role="button">2-step Verification</a>



                          <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="2stepVerificationMegaMenu" style="min-width: 14rem;">

                            <a class="dropdown-item " href="authentication-2-step-verification-basic.html">Basic</a>

                            <a class="dropdown-item " href="authentication-2-step-verification-cover.html">Cover</a>

                          </div>

                        </div>

                        <!-- End 2-step Verification -->



                        <a class="dropdown-item" href="javascript:;" data-bs-toggle="modal" data-bs-target="#welcomeMessageModal">Welcome Message</a>

                        <a class="dropdown-item " href="error-404.html">Error 404</a>

                        <a class="dropdown-item " href="error-500.html">Error 500</a>

                      </div>

                    </div>

                    <!-- End Authentication -->



                    <a class="dropdown-item " href="api-keys.html" data-placement="left">API Keys</a>

                    <a class="dropdown-item " href="welcome-page.html" data-placement="left">Welcome Page</a>

                    <a class="dropdown-item " href="landing.html" data-placement="left">Landing Page <span class="badge bg-info rounded-pill ms-1">New</span></a>

                  </div>

                  <!-- End Mega Menu -->

                </li>

                <!-- End Pages -->



                <!-- Apps -->

                <li class="hs-has-sub-menu nav-item">

                  <a id="appsMegaMenu" class="hs-mega-menu-invoker nav-link dropdown-toggle " href="#" role="button"><i class="bi-app-indicator dropdown-item-icon"></i> Apps</a>



                  <div class="hs-sub-menu dropdown-menu navbar-dropdown-menu-borderless" aria-labelledby="appsMegaMenu" style="min-width: 14rem;">

                    <a class="dropdown-item " href="apps-kanban.html">Kanban</a>

                    <a class="dropdown-item " href="apps-calendar.html">Calendar</a>

                    <a class="dropdown-item " href="apps-invoice-generator.html">Invoice Generator</a>

                    <a class="dropdown-item " href="apps-file-manager.html">File Manager</a>

                  </div>

                </li>

                <!-- End Apps -->



                <li class="nav-item">

                  <a class="nav-link " href="layouts/index.html">

                    <i class="bi-grid-1x2 dropdown-item-icon"></i> Layouts

                  </a>

                </li>



                <li class="nav-item">

                  <a class="nav-link " href="documentation/index.html" data-placement="left">

                    <i class="bi-book dropdown-item-icon"></i> Docs

                  </a>

                </li>

              </ul>



            </div>

            <!-- End Collapse -->

          </nav>

        </div>

      </header>

      <!-- End Double Header -->

    </div>

  </div>



  <script src="http://grown.technoart.org/dashboard/assets/js/demo.js"></script>



  <!-- END ONLY DEV -->



  <!-- ========== SECONDARY CONTENTS ========== -->

  <!-- Keyboard Shortcuts -->

  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasKeyboardShortcuts" aria-labelledby="offcanvasKeyboardShortcutsLabel">

    <div class="offcanvas-header">

      <h4 id="offcanvasKeyboardShortcutsLabel" class="mb-0">Keyboard shortcuts</h4>

      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>

    </div>

    <div class="offcanvas-body">

      <div class="list-group list-group-sm list-group-flush list-group-no-gutters mb-5">

        <div class="list-group-item">

          <h5 class="mb-1">Formatting</h5>

        </div>

        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span class="fw-semi-bold">Bold</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">b</kbd>

            </div>

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <em>italic</em>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">i</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <u>Underline</u>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">u</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <s>Strikethrough</s>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">Alt</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">s</kbd>

              <!-- End Col -->

            </div>

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span class="small">Small text</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">s</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <mark>Highlight</mark>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">e</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



      </div>



      <div class="list-group list-group-sm list-group-flush list-group-no-gutters mb-5">

        <div class="list-group-item">

          <h5 class="mb-1">Insert</h5>

        </div>

        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Mention person <a href="#">(@Brian)</a></span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">@</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Link to doc <a href="#">(+Meeting notes)</a></span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">+</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <a href="#">#hashtag</a>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">#hashtag</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Date</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">/date</kbd>

              <kbd class="d-inline-block mb-1">Space</kbd>

              <kbd class="d-inline-block mb-1">/datetime</kbd>

              <kbd class="d-inline-block mb-1">/datetime</kbd>

              <kbd class="d-inline-block mb-1">Space</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Time</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">/time</kbd>

              <kbd class="d-inline-block mb-1">Space</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Note box</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">/note</kbd>

              <kbd class="d-inline-block mb-1">Enter</kbd>

              <kbd class="d-inline-block mb-1">/note red</kbd>

              <kbd class="d-inline-block mb-1">/note red</kbd>

              <kbd class="d-inline-block mb-1">Enter</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



      </div>



      <div class="list-group list-group-sm list-group-flush list-group-no-gutters mb-5">

        <div class="list-group-item">

          <h5 class="mb-1">Editing</h5>

        </div>

        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Find and replace</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">r</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Find next</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">n</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Find previous</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">p</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Indent</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Tab</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Un-indent</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Shift</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">Tab</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Move line up</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">Shift</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1"><i class="bi-arrow-up-short"></i></kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Move line down</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">Shift</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1"><i class="bi-arrow-down-short fs-5"></i></kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Add a comment</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">Alt</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">m</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Undo</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">z</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Redo</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">y</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



      </div>



      <div class="list-group list-group-sm list-group-flush list-group-no-gutters">

        <div class="list-group-item">

          <h5 class="mb-1">Application</h5>

        </div>

        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Create new doc</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">Alt</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">n</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Present</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">Shift</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">p</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Share</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">Shift</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">s</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Search docs</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">Shift</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">o</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



        <div class="list-group-item">

          <div class="row align-items-center">

            <div class="col-5">

              <span>Keyboard shortcuts</span>

            </div>

            <!-- End Col -->



            <div class="col-7 text-end">

              <kbd class="d-inline-block mb-1">Ctrl</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">Shift</kbd> <span class="text-muted small">+</span> <kbd class="d-inline-block mb-1">/</kbd>

            </div>

            <!-- End Col -->

          </div>

          <!-- End Row -->

        </div>



      </div>

    </div>

  </div>

  <!-- End Keyboard Shortcuts -->



  <!-- Activity -->

  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasActivityStream" aria-labelledby="offcanvasActivityStreamLabel">

    <div class="offcanvas-header">

      <h4 id="offcanvasActivityStreamLabel" class="mb-0">Activity stream</h4>

      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>

    </div>

    <div class="offcanvas-body">

      <!-- Step -->

      <ul class="step step-icon-sm step-avatar-sm">

        <!-- Step Item -->

        <li class="step-item">

          <div class="step-content-wrapper">

            <div class="step-avatar">

              <img class="step-avatar" src="http://grown.technoart.org/dashboard/assets/img/160x160/img9.jpg" alt="Image Description">

            </div>



            <div class="step-content">

              <h5 class="mb-1">Iana Robinson</h5>



              <p class="fs-5 mb-1">Added 2 files to task <a class="text-uppercase" href="#"><i class="bi-journal-bookmark-fill"></i> Fd-7</a></p>



              <ul class="list-group list-group-sm">

                <!-- List Item -->

                <li class="list-group-item list-group-item-light">

                  <div class="row gx-1">

                    <div class="col-6">

                      <!-- Media -->

                      <div class="d-flex">

                        <div class="flex-shrink-0">

                          <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/brands/excel-icon.svg" alt="Image Description">

                        </div>

                        <div class="flex-grow-1 text-truncate ms-2">

                          <span class="d-block fs-6 text-dark text-truncate" title="weekly-reports.xls">weekly-reports.xls</span>

                          <span class="d-block small text-muted">12kb</span>

                        </div>

                      </div>

                      <!-- End Media -->

                    </div>

                    <!-- End Col -->



                    <div class="col-6">

                      <!-- Media -->

                      <div class="d-flex">

                        <div class="flex-shrink-0">

                          <img class="avatar avatar-xs" src="http://grown.technoart.org/dashboard/assets/svg/brands/word-icon.svg" alt="Image Description">

                        </div>

                        <div class="flex-grow-1 text-truncate ms-2">

                          <span class="d-block fs-6 text-dark text-truncate" title="weekly-reports.xls">weekly-reports.xls</span>

                          <span class="d-block small text-muted">4kb</span>

                        </div>

                      </div>

                      <!-- End Media -->

                    </div>

                    <!-- End Col -->

                  </div>

                  <!-- End Row -->

                </li>

                <!-- End List Item -->

              </ul>



              <span class="small text-muted text-uppercase">Now</span>

            </div>

          </div>

        </li>

        <!-- End Step Item -->



        <!-- Step Item -->

        <li class="step-item">

          <div class="step-content-wrapper">

            <span class="step-icon step-icon-soft-dark">B</span>



            <div class="step-content">

              <h5 class="mb-1">Bob Dean</h5>



              <p class="fs-5 mb-1">Marked <a class="text-uppercase" href="#"><i class="bi-journal-bookmark-fill"></i> Fr-6</a> as <span class="badge bg-soft-success text-success rounded-pill"><span class="legend-indicator bg-success"></span>"Completed"</span></p>



              <span class="small text-muted text-uppercase">Today</span>

            </div>

          </div>

        </li>

        <!-- End Step Item -->



        <!-- Step Item -->

        <li class="step-item">

          <div class="step-content-wrapper">

            <div class="step-avatar">

              <img class="step-avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img3.jpg" alt="Image Description">

            </div>



            <div class="step-content">

              <h5 class="h5 mb-1">Crane</h5>



              <p class="fs-5 mb-1">Added 5 card to <a href="#">Payments</a></p>



              <ul class="list-group list-group-sm">

                <li class="list-group-item list-group-item-light">

                  <div class="row gx-1">

                    <div class="col">

                      <img class="img-fluid rounded" src="http://grown.technoart.org/dashboard/assets/svg/components/card-1.svg" alt="Image Description">

                    </div>

                    <div class="col">

                      <img class="img-fluid rounded" src="http://grown.technoart.org/dashboard/assets/svg/components/card-2.svg" alt="Image Description">

                    </div>

                    <div class="col">

                      <img class="img-fluid rounded" src="http://grown.technoart.org/dashboard/assets/svg/components/card-3.svg" alt="Image Description">

                    </div>

                    <div class="col-auto align-self-center">

                      <div class="text-center">

                        <a href="#">+2</a>

                      </div>

                    </div>

                  </div>

                </li>

              </ul>



              <span class="small text-muted text-uppercase">May 12</span>

            </div>

          </div>

        </li>

        <!-- End Step Item -->



        <!-- Step Item -->

        <li class="step-item">

          <div class="step-content-wrapper">

            <span class="step-icon step-icon-soft-info">D</span>



            <div class="step-content">

              <h5 class="mb-1">David Lidell</h5>



              <p class="fs-5 mb-1">Added a new member to grown Dashboard</p>



              <span class="small text-muted text-uppercase">May 15</span>

            </div>

          </div>

        </li>

        <!-- End Step Item -->



        <!-- Step Item -->

        <li class="step-item">

          <div class="step-content-wrapper">

            <div class="step-avatar">

              <img class="step-avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img7.jpg" alt="Image Description">

            </div>



            <div class="step-content">

              <h5 class="mb-1">Rachel King</h5>



              <p class="fs-5 mb-1">Marked <a class="text-uppercase" href="#"><i class="bi-journal-bookmark-fill"></i> Fr-3</a> as <span class="badge bg-soft-success text-success rounded-pill"><span class="legend-indicator bg-success"></span>"Completed"</span></p>



              <span class="small text-muted text-uppercase">Apr 29</span>

            </div>

          </div>

        </li>

        <!-- End Step Item -->



        <!-- Step Item -->

        <li class="step-item">

          <div class="step-content-wrapper">

            <div class="step-avatar">

              <img class="step-avatar-img" src="http://grown.technoart.org/dashboard/assets/img/160x160/img5.jpg" alt="Image Description">

            </div>



            <div class="step-content">

              <h5 class="mb-1">Finch Hoot</h5>



              <p class="fs-5 mb-1">Earned a "Top endorsed" <i class="bi-patch-check-fill text-primary"></i> badge</p>



              <span class="small text-muted text-uppercase">Apr 06</span>

            </div>

          </div>

        </li>

        <!-- End Step Item -->



        <!-- Step Item -->

        <li class="step-item">

          <div class="step-content-wrapper">

            <span class="step-icon step-icon-soft-primary">

              <i class="bi-person-fill"></i>

            </span>



            <div class="step-content">

              <h5 class="mb-1">Project status updated</h5>



              <p class="fs-5 mb-1">Marked <a class="text-uppercase" href="#"><i class="bi-journal-bookmark-fill"></i> Fr-3</a> as <span class="badge bg-soft-primary text-primary rounded-pill"><span class="legend-indicator bg-primary"></span>"In progress"</span></p>



              <span class="small text-muted text-uppercase">Feb 10</span>

            </div>

          </div>

        </li>

        <!-- End Step Item -->

      </ul>

      <!-- End Step -->



      <div class="d-grid">

        <a class="btn btn-white" href="javascript:;">View all <i class="bi-chevron-right"></i></a>

      </div>

    </div>

  </div>

  <!-- End Activity -->



  <!-- Welcome Message Modal -->

  <div class="modal fade" id="welcomeMessageModal" tabindex="-1" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">

      <div class="modal-content">

        <!-- Header -->

        <div class="modal-close">

          <button type="button" class="btn btn-ghost-secondary btn-icon btn-sm" data-bs-dismiss="modal" aria-label="Close">

            <i class="bi-x-lg"></i>

          </button>

        </div>

        <!-- End Header -->



        <!-- Body -->

        <div class="modal-body p-sm-5">

          <div class="text-center">

            <div class="w-75 w-sm-50 mx-auto mb-4">

              <img class="img-fluid" src="http://grown.technoart.org/dashboard/assets/svg/illustrations/oc-collaboration.svg" alt="Image Description" data-hs-theme-appearance="default">

              <img class="img-fluid" src="http://grown.technoart.org/dashboard/assets/svg/illustrations-light/oc-collaboration.svg" alt="Image Description" data-hs-theme-appearance="dark">

            </div>



            <h4 class="h1">Welcome to grown</h4>



            <p>We're happy to see you in our community.</p>

          </div>

        </div>

        <!-- End Body -->



        <!-- Footer -->

        <div class="modal-footer d-block text-center py-sm-5">

          <small class="text-cap text-muted">Trusted by the world's best teams</small>



          <div class="w-85 mx-auto">

            <div class="row justify-content-between">

              <div class="col">

                <img class="img-fluid" src="http://grown.technoart.org/dashboard/assets/svg/brands/gitlab-gray.svg" alt="Image Description">

              </div>

              <div class="col">

                <img class="img-fluid" src="http://grown.technoart.org/dashboard/assets/svg/brands/fitbit-gray.svg" alt="Image Description">

              </div>

              <div class="col">

                <img class="img-fluid" src="http://grown.technoart.org/dashboard/assets/svg/brands/flow-xo-gray.svg" alt="Image Description">

              </div>

              <div class="col">

                <img class="img-fluid" src="http://grown.technoart.org/dashboard/assets/svg/brands/layar-gray.svg" alt="Image Description">

              </div>

            </div>

          </div>

        </div>

        <!-- End Footer -->

      </div>

    </div>

  </div>



  <!-- End Welcome Message Modal -->

  <!-- ========== END SECONDARY CONTENTS ========== -->



  <!-- JS Implementing Plugins -->

  <script src="http://grown.technoart.org/dashboard/assets/js/vendor.min.js"></script>



  <!-- JS grown -->

  <script src="http://grown.technoart.org/dashboard/assets/js/theme.min.js"></script>



  <!-- JS Plugins Init. -->

  <script>

    (function() {

      window.onload = function () {

        



        // INITIALIZATION OF NAVBAR VERTICAL ASIDE

        // =======================================================

        new HSSideNav('.js-navbar-vertical-aside').init()





        // INITIALIZATION OF FORM SEARCH

        // =======================================================

        new HSFormSearch('.js-form-search')





        // INITIALIZATION OF BOOTSTRAP DROPDOWN

        // =======================================================

        HSBsDropdown.init()





        // INITIALIZATION OF SELECT

        // =======================================================

        HSCore.components.HSTomSelect.init('.js-select')





        // INITIALIZATION OF INPUT MASK

        // =======================================================

        HSCore.components.HSMask.init('.js-input-mask')





        // INITIALIZATION OF FILE ATTACHMENT

        // =======================================================

        new HSFileAttach('.js-file-attach')





        // INITIALIZATION OF STICKY BLOCKS

        // =======================================================

        new HSStickyBlock('.js-sticky-block', {

          targetSelector: document.getElementById('header').classList.contains('navbar-fixed') ? '#header' : null

        })





        // SCROLLSPY

        // =======================================================

        new bootstrap.ScrollSpy(document.body, {

          target: '#navbarSettings',

          offset: 100

        })



        new HSScrollspy('#navbarVerticalNavMenu', {

          breakpoint: 'lg',

          scrollOffset: -20

        })

      }

    })()

  </script>



  <!-- Style Switcher JS -->



  <script>

      (function () {

        // STYLE SWITCHER

        // =======================================================

        const $dropdownBtn = document.getElementById('selectThemeDropdown') // Dropdowon trigger

        const $variants = document.querySelectorAll(`[aria-labelledby="selectThemeDropdown"] [data-icon]`) // All items of the dropdown



        // Function to set active style in the dorpdown menu and set icon for dropdown trigger

        const setActiveStyle = function () {

          $variants.forEach($item => {

            if ($item.getAttribute('data-value') === HSThemeAppearance.getOriginalAppearance()) {

              $dropdownBtn.innerHTML = `<i class="${$item.getAttribute('data-icon')}" />`

              return $item.classList.add('active')

            }



            $item.classList.remove('active')

          })

        }



        // Add a click event to all items of the dropdown to set the style

        $variants.forEach(function ($item) {

          $item.addEventListener('click', function () {

            HSThemeAppearance.setAppearance($item.getAttribute('data-value'))

          })

        })



        // Call the setActiveStyle on load page

        setActiveStyle()



        // Add event listener on change style to call the setActiveStyle function

        window.addEventListener('on-hs-appearance-change', function () {

          setActiveStyle()

        })

      })()

    </script>



  <!-- End Style Switcher JS -->

</body>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
		<script>
				// Wait for the DOM to be ready
$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
  
  //basic form start
  $("form[name='basic_information']").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      firstName: "required",
      lastName: "required",
      selina_id: "required",
      organization: "required",
      department: "required",
      userAccountTypeRadio: "required",
      country: "required",
      city: "required",
      state: "required",
      addressLine1: "required",
      zipCode: "required",
      email: {
        required: true,
        // Specify that email should be validated
        // by the built-in "email" rule
        email: true
      }
    },
    // Specify validation error messages
    messages: {
      firstname: "Please enter your firstname",
      lastname: "Please enter your lastname",
     email: "Please enter a valid email address",
     selina_id: "Please enter Selina id",
     organization: "Please enter Organization",
     department: "Please enter Department",
     userAccountTypeRadio: "Please select Account type",
     country: "Please select country",
     city: "Please enter city",
     state: "Please enter state",
     addressLine1: "Please enter address",
     zipCode: "Please enter zip code",
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
		var form = $("form[name='basic_information']");
            $("#loader1").show();
            $.ajax({
                type: "POST",
               url: "<?php echo admin_url('admin-ajax.php'); ?>",
                data: form.serialize(),
                success: function(data) {
                     $("#loader1").hide();
					 var res = jQuery.trim(data);
					 if(res == 2)
					 {
						 $("#baisc_form_alert").html('<p style="color:red;">Email already exist.</p>');
					 }
					 else
					 {
						 $("#baisc_form_alert").html('<p style="color:green;">All deatils submitted successfully.</p>');
						 $("#pre_email").val($("#email").val());
						 
					 }
                   setTimeout(function () {
                     $('#baisc_form_alert').html('');
                 }, 2000);
                },
                error: function(data) {
                      
                   $("#baisc_form_alert").html('<p style="color:red;">Something went wrong. Please try again later.</p>');
				    setTimeout(function () {
                     $('#baisc_form_alert').html('');
                 }, 2000);
                }
            });
    }
  });
  //basic form end
  
  //email from start
  $("form[name='email_form']").validate({
    // Specify validation rules
    rules: {
     
      email2: {
        required: true,
        // Specify that email should be validated
        // by the built-in "email" rule
        email: true
      }
    },
    // Specify validation error messages
    messages: {
     email2: "Please enter a valid email address",
     
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
		var form = $("form[name='email_form']");
            $("#loader2").show();
            $.ajax({
                type: "POST",
               url: "<?php echo admin_url('admin-ajax.php'); ?>",
                data: form.serialize(),
                success: function(data) {
                     $("#loader2").hide();
					 var res = jQuery.trim(data);
					 if(res == 2)
					 {
						 $("#email_form_alert").html('<p style="color:red;">Email already exist.</p>');
					 }
					 else
					 {
						 $("#email_form_alert").html('<p style="color:green;">Email updated successfully.</p>');
						 $("#pre_email2").val($("#email").val());
						 
					 }
                   setTimeout(function () {
                     $('#email_form_alert').html('');
                 }, 2000);
                },
                error: function(data) {
                      
                   $("#email_form_alert").html('<p style="color:red;">Something went wrong. Please try again later.</p>');
				    setTimeout(function () {
                     $('#email_form_alert').html('');
                 }, 2000);
                }
            });
    }
  });
  //email from end
  
  
  $.validator.addMethod("checklower", function(value) {
  return /[a-z]/.test(value);
});
$.validator.addMethod("checkupper", function(value) {
  return /[A-Z]/.test(value);
});
$.validator.addMethod("checkdigit", function(value) {
  return /[0-9]/.test(value);
});
$.validator.addMethod("pwcheck", function(value) {
  return /^[A-Za-z0-9\d=!\-@._*]*$/.test(value) && /[a-z]/.test(value) && /\d/.test(value) && /[A-Z]/.test(value);
});


  //email from start
  $("form[name='change_password_form']").validate({
    // Specify validation rules
    rules: {
     
	 currentPassword: "required",
	 newPassword: {
      minlength: 8,
      maxlength: 30,
      required: true,
      //pwcheck: true,
      checklower: true,
      checkupper: true,
      checkdigit: true
    },
    confirmNewPassword: {
      equalTo: "#newPassword",
    },
    },
    // Specify validation error messages
    messages: {
		newPassword: {
      //pwcheck: "Password is not strong enough",
      required: "Please enter new password",
      checklower: "Need atleast 1 lowercase alphabet",
      checkupper: "Need atleast 1 uppercase alphabet",
      checkdigit: "Need atleast 1 digit"
    },
     currentPassword: "Please enter current password",
     
     confirmNewPassword: "Confirm new password should be equal to new password",
     
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
		var form = $("form[name='change_password_form']");
            $("#loader3").show();
            $.ajax({
                type: "POST",
               url: "<?php echo admin_url('admin-ajax.php'); ?>",
                data: form.serialize(),
                success: function(data) {
                     $("#loader3").hide();
					 var res = jQuery.trim(data);
					 
					 if(res == 1)
					 {
						 $("#change_password_form_alert").html('<p style="color:green;">The password has been updated successfully</p>');
						 $('#currentPassword').val('');
						 $('#newPassword').val('');
						 $('#confirmNewPassword').val('');
					 }
					 if(res == 2)
					 {
						 $("#change_password_form_alert").html('<p style="color:red;">Sorry! Failed to update your account details.</p>');
					 }
					 if(res == 3)
					 {
						 $("#change_password_form_alert").html('<p style="color:red;">Old Password does not match the existing password</p>');
					 }
					 
                   setTimeout(function () {
                     $('#change_password_form_alert').html('');
                 }, 2000);
                },
                error: function(data) {
                      
                   $("#change_password_form_alert").html('<p style="color:red;">Something went wrong. Please try again later.</p>');
				    setTimeout(function () {
                     $('#change_password_form_alert').html('');
                 }, 2000);
                }
            });
    }
  });
  //email from end
  
  
  //preferencesSection start
 
  $("form[name='preferences_form']").validate({
    
    submitHandler: function(form) {
		var form = $("form[name='preferences_form']");
            $("#loader4").show();
            $.ajax({
                type: "POST",
               url: "<?php echo admin_url('admin-ajax.php'); ?>",
                data: form.serialize(),
                success: function(data) {
                     $("#loader4").hide();
					 var res = jQuery.trim(data);
					 
					 $("#pre_form_alert").html('<p style="color:green;">All details updated successfully.</p>');
						
					 
					 
					 
                   setTimeout(function () {
                     $('#pre_form_alert').html('');
                 }, 2000);
                },
                error: function(data) {
                      
                   $("#pre_form_alert").html('<p style="color:red;">Something went wrong. Please try again later.</p>');
				    setTimeout(function () {
                     $('#pre_form_alert').html('');
                 }, 2000);
                }
            });
    }
  });
  //preferencesSection end
  
  //notifications_form start
  
  $("form[name='notifications_form']").validate({
    
    submitHandler: function(form) {
		var form = $("form[name='notifications_form']");
            $("#loader5").show();
            $.ajax({
                type: "POST",
               url: "<?php echo admin_url('admin-ajax.php'); ?>",
                data: form.serialize(),
                success: function(data) {
                     $("#loader5").hide();
					 var res = jQuery.trim(data);
					 
					 $("#notifications_form_alert").html('<p style="color:green;">All details updated successfully.</p>');
						
					 
					 
					 
                   setTimeout(function () {
                     $('#notifications_form_alert').html('');
                 }, 2000);
                },
                error: function(data) {
                      
                   $("#notifications_form_alert").html('<p style="color:red;">Something went wrong. Please try again later.</p>');
				    setTimeout(function () {
                     $('#notifications_form_alert').html('');
                 }, 2000);
                }
            });
    }
  });
  //notifications_form end
  
  //delete_account start
  
  $("form[name='delete_account_form']").validate({
      rules: {
     
	 deleteAccountCheckbox: "required",
	 
    },
    // Specify validation error messages
    messages: {
	deleteAccountCheckbox: "Confirm that you want to delete your account.",
     
    },
    submitHandler: function(form) {
		var form = $("form[name='delete_account_form']");
            $("#loader6").show();
            $.ajax({
                type: "POST",
               url: "<?php echo admin_url('admin-ajax.php'); ?>",
                data: form.serialize(),
                success: function(data) {
                     $("#loader6").hide();
					 
					 
					 
                },
                error: function(data) {
                      
                   $("#delete_account_form_alert").html('<p style="color:red;">Something went wrong. Please try again later.</p>');
				    setTimeout(function () {
                     $('#delete_account_form_alert').html('');
                 }, 2000);
                }
            });
    }
  });
  //delete_account end
  
  
});

function member_type()
{
	var member_type = $("#member_type").val();
	
	$.ajax({
	 type: "POST",
	 url: "<?php echo admin_url('admin-ajax.php'); ?>",
	 data: {member_type:member_type,action:"member_type"},
	 success: function(data){
	 
	 },
	 error: function(xhr, status, error){
	 alert('Something went wrong. Please try later.');
	 }
	});
}
function term_change()
{
	var res = 'No';
	if ($('#terms').is(':checked')) {
		var res = 'Yes';
	}
	$.ajax({
	 type: "POST",
	 url: "<?php echo admin_url('admin-ajax.php'); ?>",
	 data: {response:res,action:"term_change"},
	 success: function(data){
	 
	 },
	 error: function(xhr, status, error){
	 alert('Something went wrong. Please try later.');
	 }
	});
}
function run_connected(account_id)
{
	var res = 'No';
	if ($('#'+account_id).is(':checked')) {
		var res = 'Yes';
	}
	$.ajax({
	 type: "POST",
	 url: "<?php echo admin_url('admin-ajax.php'); ?>",
	 data: {response:res,name: account_id,action:"run_connected"},
	 success: function(data){
	 
	 },
	 error: function(xhr, status, error){
	 alert('Something went wrong. Please try later.');
	 }
	});
}
				</script>

        <script>
function previewFile(input){
        var file = $("input[name=profile_pic]").get(0).files[0];
 
        if(file){
            var reader = new FileReader();
 
            reader.onload = function(){
                $("#profile_pic_img").attr("src", reader.result);
				var formData = new FormData();
				formData.append('file', $('input[name=profile_pic]')[0].files[0]);
				formData.append('action', "profile_pic_action");

				$.ajax({
					   url : '<?php echo admin_url("admin-ajax.php"); ?>',
					   type : 'POST',
					   data : formData,
					   processData: false,  // tell jQuery not to process the data
					   contentType: false,  // tell jQuery not to set contentType
					   success : function(data) {
						   
					   }
				});
            }
 
            reader.readAsDataURL(file);
        }
    }
	function previewFile1(input){
        var file = $("input[name=header_pic]").get(0).files[0];
 
        if(file){
            var reader = new FileReader();
 
            reader.onload = function(){
                $("#profileCoverImg").attr("src", reader.result);
				var formData = new FormData();
				formData.append('file', $('input[name=header_pic]')[0].files[0]);
				formData.append('action', "header_pic_action");

				$.ajax({
					   url : '<?php echo admin_url("admin-ajax.php"); ?>',
					   type : 'POST',
					   data : formData,
					   processData: false,  // tell jQuery not to process the data
					   contentType: false,  // tell jQuery not to set contentType
					   success : function(data) {
						   
					   }
				});
            }
 
            reader.readAsDataURL(file);
        }
    }
				function open_file(id){
					$("#"+id).click();
				}
				</script>


</html>

